/*!
 * Mera — ตะกร้าหลายสินค้า + ซื้อเลย สำหรับเว็บ Mera Catalog
 * ------------------------------------------------------------
 * ใส่ในหน้าเว็บ (ก่อน </body>):
 *
 *   <script>
 *     window.MERA_CHECKOUT = {
 *       api: 'https://script.google.com/macros/s/xxxx/exec',   // Web app /exec ของโปรเจกต์ Inventory + GB (ตัวเดียวกับ webhook LINE)
 *       lineOaId: '@652glcdn',
 *       // getIdToken: () => liff.getIDToken()   // ค่าเริ่มต้นใช้ LIFF ที่หน้าเว็บเปิดไว้แล้ว
 *     };
 *   </script>
 *   <script src="mera-checkout.js" defer></script>
 *
 * ผูกปุ่ม "เพิ่มลงตะกร้า" ของแต่ละสินค้า:
 *   MeraCheckout.add({ sku: 'MRA040', qty: 1, name: '1984 club t-shirt', brand: 'Komé', color: 'สีดำ', size: 'M', img: 'https://…' })
 * เปิดตะกร้าเดิม: MeraCheckout.openCart()
 * ซื้อสินค้าเดียวทันที (รองรับโค้ดเก่า): MeraCheckout.open({ sku: 'MRA040', qty: 1 })
 * หน้า "ออเดอร์ของฉัน":  MeraCheckout.openOrders()
 * ลิงก์ในการ์ด LINE (?order=MO-0001) เปิดหน้าสถานะออเดอร์ให้เอง
 */
(function () {
  'use strict';
  var CFG = Object.assign({
    api: '',
    lineOaId: '@652glcdn',
    addressDb: 'https://cdn.jsdelivr.net/gh/earthchie/jquery.Thailand.js@master/jquery.Thailand.js/database/raw_database/raw_database.json',
    getIdToken: function () { try { return window.liff && window.liff.getIDToken ? window.liff.getIDToken() : ''; } catch (e) { return ''; } },
    testUserId: '',
    privacyUrl: 'privacy.html',   // หน้านโยบายความเป็นส่วนตัว
  }, window.MERA_CHECKOUT || {});

  /* ---------------- styles ---------------- */
  var CSS = [
    '.mc-ov{position:fixed;inset:0;z-index:9990;background:rgba(42,16,23,.45);display:flex;justify-content:center;align-items:flex-end}',
    '.mc-ov[hidden]{display:none}',
    '.mc-sh{width:100%;max-width:460px;height:100%;max-height:100dvh;background:#FFFBED;color:#3a0716;font-family:Poppins,Prompt,system-ui,sans-serif;display:flex;flex-direction:column;overflow:hidden;-webkit-font-smoothing:antialiased}',
    '@media(min-width:600px){.mc-ov{align-items:center}.mc-sh{height:92vh;border-radius:22px}}',
    '.mc-sh *{box-sizing:border-box}',
    '.mc-hd{display:flex;align-items:center;gap:8px;padding:12px 12px 8px;flex:none}',
    '.mc-hd h2{margin:0;font-size:18px;font-weight:700;flex:1}.mc-step{font-size:12px;color:#8a5a66}',
    '.mc-ib{width:44px;height:44px;border-radius:50%;background:#fff;border:1px solid #f3e3d6;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:none;padding:0;color:#3a0716}',
    '.mc-bd{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:8px 16px 24px;display:flex;flex-direction:column;gap:16px}',
    '.mc-card{background:#fff;border:1px solid #f3e3d6;border-radius:18px;padding:14px 16px}',
    '.mc-prod{display:flex;gap:12px;padding:12px}.mc-prod img,.mc-ph{width:84px;height:84px;border-radius:12px;object-fit:cover;flex:none;background:#F3EBE1}',
    '.mc-prod .mc-col{display:flex;flex-direction:column;gap:3px;min-width:0}',
    '.mc-prodlist{display:flex;flex-direction:column;gap:10px}',
    '.mc-prodline{position:relative;display:grid;grid-template-columns:72px minmax(0,1fr);gap:12px;background:#fff;border:1px solid #f3e3d6;border-radius:18px;padding:12px}',
    '.mc-prodline img,.mc-prodline .mc-ph{width:72px;height:72px;border-radius:12px;object-fit:cover;background:#F3EBE1}',
    '.mc-prodline .mc-col{display:flex;flex-direction:column;gap:3px;min-width:0}',
    '.mc-linefoot{grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;gap:10px;padding-top:4px}',
    '.mc-qty{display:flex;align-items:center;gap:5px;border:1px solid #ead6cb;border-radius:999px;padding:3px}',
    '.mc-qty button{width:34px;height:34px;border:0;border-radius:50%;background:#FCE4E8;color:#841132;font:inherit;font-size:19px;line-height:1;cursor:pointer}',
    '.mc-qty b{min-width:24px;text-align:center;font-size:14px}',
    '.mc-remove{border:0;background:none;color:#8a5a66;font:inherit;font-size:12px;text-decoration:underline;cursor:pointer;padding:8px}',
    '.mc-cartfab{position:fixed;right:16px;bottom:calc(18px + env(safe-area-inset-bottom));z-index:9989;border:0;border-radius:999px;background:#841132;color:#FFFBED;box-shadow:0 8px 24px rgba(58,7,22,.28);font:600 14px Poppins,Prompt,system-ui,sans-serif;padding:12px 18px;min-height:48px;cursor:pointer}',
    '.mc-cartfab[hidden]{display:none}',
    '.mc-brand{font-size:12px;color:#841132;font-weight:600}.mc-name{font-size:15px;font-weight:700;line-height:1.25}',
    '.mc-sub{font-size:13px;color:#5e2a37}.mc-sku{font-family:ui-monospace,Menlo,monospace;font-size:11px;color:#8a5a66}',
    '.mc-chip{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #f3e3d6;border-radius:999px;padding:6px 14px 6px 6px;font-size:13px}',
    '.mc-chip i{width:32px;height:32px;border-radius:50%;background:#06C755;display:flex;align-items:center;justify-content:center;flex:none}',
    '.mc-eta{display:flex;align-items:center;gap:12px}.mc-eta i{width:40px;height:40px;border-radius:12px;background:#FCE4E8;display:flex;align-items:center;justify-content:center;flex:none}',
    '.mc-eta small{display:block;font-size:12px;color:#5e2a37}.mc-eta b{display:block;font-size:15px}.mc-eta em{display:block;font-style:normal;font-size:11px;color:#8a5a66}',
    '.mc-row{display:flex;justify-content:space-between;gap:8px;font-size:14px;padding:3px 0}.mc-row span:first-child{color:#5e2a37}',
    '.mc-hr{height:1px;background:#f3e3d6;margin:6px 0}',
    '.mc-total{display:flex;justify-content:space-between;align-items:baseline}.mc-total b{font-size:24px;font-weight:800;color:#841132}',
    '.mc-free{color:#841132;font-weight:700}',
    '.mc-sec{display:flex;flex-direction:column;gap:12px}.mc-sec h3{margin:0;font-size:16px;font-weight:700;display:flex;justify-content:space-between;align-items:center}',
    '.mc-tag{font-size:11px;font-weight:400;color:#5e2a37;background:#FCE4E8;padding:3px 9px;border-radius:999px}',
    '.mc-f{display:flex;flex-direction:column;gap:6px;font-size:13px;color:#5e2a37}',
    '.mc-f input,.mc-f select{font:inherit;font-size:16px;color:#3a0716;background:#fff;border:1.5px solid #ead6cb;border-radius:12px;padding:11px 12px;min-height:46px;width:100%;appearance:none;-webkit-appearance:none}',
    '.mc-f select{background-image:linear-gradient(45deg,transparent 50%,#8a5a66 50%),linear-gradient(135deg,#8a5a66 50%,transparent 50%);background-position:calc(100% - 18px) 20px,calc(100% - 13px) 20px;background-size:5px 5px;background-repeat:no-repeat;padding-right:30px}',
    '.mc-f input:focus,.mc-f select:focus{outline:2px solid #841132;outline-offset:1px;border-color:#841132}',
    '.mc-f.bad input,.mc-f.bad select{border-color:#b3261e}',
    '.mc-g2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}',
    '.mc-hint{font-size:11px;color:#8a5a66}',
    '.mc-chk{display:flex;align-items:center;gap:10px;font-size:13px;min-height:44px;color:#3a0716}.mc-chk input{width:20px;height:20px;accent-color:#841132}',
    '.mc-btn{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;background:#841132;color:#FFFBED;border:0;font:inherit;font-weight:700;font-size:16px;padding:14px 16px;border-radius:999px;min-height:52px;cursor:pointer;text-decoration:none}',
    '.mc-btn[disabled]{opacity:.4;cursor:not-allowed}',
    '.mc-btn2{display:flex;align-items:center;justify-content:center;width:100%;background:none;border:0;font:inherit;font-size:14px;font-weight:600;color:#841132;min-height:44px;cursor:pointer;text-decoration:none}',
    '.mc-out{font:inherit;font-size:13px;font-weight:600;color:#841132;background:#fff;border:1.5px solid #841132;border-radius:999px;padding:8px 16px;min-height:44px;cursor:pointer}',
    '.mc-pay{display:flex;flex-direction:column;align-items:center;gap:12px;background:#fff;border:1px solid #f3e3d6;border-radius:22px;padding:20px 16px;text-align:center}',
    '.mc-pay .mc-amt{font-size:34px;font-weight:800;color:#841132;line-height:1}',
    '.mc-bd>*{flex-shrink:0}',
    '.mc-rcv{display:flex;flex-direction:column;gap:10px}.mc-rcv h4{margin:0;font-size:15px;color:#841132}',
    '.mc-rb{display:flex;flex-direction:column;gap:8px;border-top:1px solid #f1e3da;padding-top:10px}.mc-rb:first-of-type{border-top:0;padding-top:0}',
    '.mc-rb .mc-row b{font-size:13px}.mc-rok{color:#17652F;font-weight:600;font-size:13px}.mc-rwarn{color:#842029;font-size:13px}',
    '.mc-rb textarea{font:inherit;font-size:16px;color:#3a0716;background:#fff;border:1.5px solid #ead6cb;border-radius:12px;padding:10px 12px;min-height:84px;width:100%;box-sizing:border-box;resize:vertical}',
    '.mc-rb textarea:focus{outline:2px solid #841132;outline-offset:1px;border-color:#841132}',
    '.mc-qrcard{background:#fff;border:1px solid #f3e3d6;border-radius:22px;overflow:hidden;text-align:center}',
    '.mc-qrhead{background:#113566;color:#fff;font-weight:700;font-size:14px;letter-spacing:.06em;padding:12px 16px;display:flex;justify-content:center;gap:8px;align-items:baseline}.mc-qrhead span{font-weight:500;font-size:12px;letter-spacing:0;opacity:.85}',
    '.mc-qrimg{padding:18px 16px 6px;display:flex;justify-content:center}.mc-qrimg img,.mc-qrimg canvas{width:min(240px,64vw);height:auto;max-height:340px;object-fit:contain;display:block;-webkit-touch-callout:default}',
    '.mc-qrbody{padding:6px 16px 18px;display:flex;flex-direction:column;align-items:center;gap:8px}.mc-qrlab{font-size:13px;color:#5e2a37}',
    '.mc-amt{font-size:32px;font-weight:800;color:#841132;line-height:1.1}.mc-amt small{font-size:16px;font-weight:700}',
    '.mc-acct{font-size:12px;color:#5e2a37;white-space:pre-line;line-height:1.5}',
    '.mc-copies{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}',
    '.mc-how b{font-size:14px}.mc-how ol{margin:8px 0 0;padding-left:20px;display:flex;flex-direction:column;gap:6px;font-size:13px;color:#3a0716;line-height:1.5}',
    '.mc-left{font-size:12px;font-weight:600;color:#5e2a37}.mc-left.low{color:#b3261e}',
    '.mc-pref .mc-q{display:flex;flex-direction:column;gap:8px}.mc-q b{font-size:14px;font-weight:600}.mc-q small{font-weight:400;color:#8a5a66}',
    '.mc-cps{display:flex;gap:8px;flex-wrap:wrap}.mc-cp{font:inherit;font-size:13px;min-height:40px;padding:7px 14px;border-radius:999px;border:1.5px solid #ead6cb;background:#fff;color:#3a0716;cursor:pointer}',
    '.mc-cp.on{background:#841132;border-color:#841132;color:#FFFBED}',
    /* Membership: gate / โปรไฟล์ / ต้อนรับ */
    '.mc-gate{display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center;padding:8px 4px 0}',
    '.mc-gate i{width:64px;height:64px;border-radius:50%;background:#841132;display:flex;align-items:center;justify-content:center}',
    '.mc-gate h3{margin:0;font-size:22px;font-weight:800;color:#841132}.mc-gate p{margin:0;font-size:14px;line-height:1.6;color:#5e2a37;max-width:300px}',
    '.mc-perks{display:flex;flex-direction:column;gap:10px;background:#fff;border-radius:18px;padding:14px 16px;box-shadow:inset 0 -1px 5px rgba(0,0,0,.25)}',
    '.mc-perks div{display:flex;gap:10px;align-items:center;font-size:14px}.mc-perks span{flex:none;width:22px;height:22px;border-radius:50%;background:#841132;display:flex;align-items:center;justify-content:center}',
    '.mc-btnline{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:54px;border-radius:999px;border:0;background:#06C755;color:#fff;font:inherit;font-weight:700;font-size:16px;cursor:pointer}',
    '.mc-how2{text-align:center;font-size:12px;line-height:1.6;color:#8a5a66;white-space:pre-line}',
    '.mc-ok{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#17652F}.mc-ok span{width:22px;height:22px;border-radius:50%;background:#06C755;display:flex;align-items:center;justify-content:center}',
    '.mc-phead{background:#841132;color:#FFFBED;border-radius:22px;padding:20px;display:flex;flex-direction:column;gap:10px}',
    '.mc-phead h3{margin:0;font-size:24px;font-weight:800}.mc-phead p{margin:0;font-size:14px;line-height:1.6;color:#FEBFC7}.mc-phead small{font-size:12px;color:#FEBFC7}',
    '.mc-bars{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px}.mc-bars span{height:6px;border-radius:999px;background:rgba(255,255,255,.3)}.mc-bars span.on{background:#FEBFC7}',
    '.mc-fs{margin:0;border:0;background:#fff;border-radius:18px;padding:14px;display:flex;flex-direction:column;gap:10px;min-width:0;box-shadow:inset 0 -1px 5px rgba(0,0,0,.25)}',
    '.mc-fs legend{padding:0;font-size:15px;font-weight:700;float:left;width:100%}',
    '.mc-ck{display:flex;gap:12px;align-items:flex-start;text-align:left;font:inherit;font-size:14px;line-height:1.5;background:#fff;border:0;border-radius:16px;padding:14px;cursor:pointer;color:#3a0716;box-shadow:inset 0 -1px 5px rgba(0,0,0,.25);width:100%}',
    '.mc-ck b{flex:none;width:24px;height:24px;border-radius:7px;border:1.5px solid #841132;background:#fff;display:flex;align-items:center;justify-content:center;color:#FFFBED;font-size:14px}.mc-ck.on b{background:#841132}',
    '.mc-ck a{color:#841132;font-weight:600}',
    '.mc-perk{display:flex;gap:12px;align-items:center;background:#fff;border-radius:18px;padding:14px 16px;box-shadow:inset 0 -1px 5px rgba(0,0,0,.25)}',
    '.mc-perk i{flex:none;width:44px;height:44px;border-radius:12px;background:#FCE4E8;display:flex;align-items:center;justify-content:center}',
    '.mc-perk b{display:block;font-size:15px;color:#841132}.mc-perk span{font-size:12px;color:#5e2a37}',
    '.mc-pp{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#1b3a6b}',
    '.mc-up{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:120px;border:1.5px dashed #841132;border-radius:18px;background:#fff;color:#841132;cursor:pointer;font:inherit;width:100%;padding:12px}',
    '.mc-up b{font-size:14px}.mc-up small{font-size:11px;color:#8a5a66}',
    '.mc-slip{display:flex;align-items:center;gap:12px;background:#fff;border:1.5px solid #841132;border-radius:18px;padding:12px}',
    '.mc-slip img{width:52px;height:68px;border-radius:8px;object-fit:cover;flex:none;background:#FCE4E8}',
    '.mc-note{font-size:12px;line-height:1.6;color:#5e2a37;text-align:center;margin:0}',
    '.mc-hero{display:flex;flex-direction:column;align-items:center;gap:8px;background:#841132;color:#FFFBED;border-radius:22px;padding:26px 20px;text-align:center}',
    '.mc-hero i{width:56px;height:56px;border-radius:50%;background:#FEBFC7;display:flex;align-items:center;justify-content:center}',
    '.mc-hero h3{margin:0;font-size:22px;font-weight:800}.mc-hero small{font-size:12px;color:#FEBFC7;letter-spacing:.1em}',
    '.mc-hero .mc-id{font-family:ui-monospace,Menlo,monospace;font-size:26px;font-weight:700;letter-spacing:.04em}',
    '.mc-hero.warn{background:#fff;color:#3a0716;border:1.5px solid #b3261e}.mc-hero.warn i{background:#F8D7DA}.mc-hero.warn small{color:#8a5a66}',
    '.mc-band{display:flex;justify-content:space-between;align-items:center;gap:10px;background:#FCE4E8;border-radius:14px;padding:12px 16px;font-size:13px;color:#5e2a37}.mc-band b{font-size:15px;color:#841132}',
    '.mc-tl h4{margin:0 0 12px;font-size:15px}.mc-st{display:flex;gap:12px}.mc-st>div:first-child{display:flex;flex-direction:column;align-items:center}',
    '.mc-dot{width:14px;height:14px;border-radius:50%;background:#ead6cb;flex:none}.mc-dot.done{background:#841132}.mc-dot.now{background:#fff;border:3px solid #841132}',
    '.mc-line{width:2px;flex:1;background:#ead6cb}.mc-line.done{background:#841132}',
    '.mc-st>div:last-child{display:flex;flex-direction:column;gap:2px;padding-bottom:14px;font-size:14px;color:#5e2a37}.mc-st b{color:#3a0716;font-weight:600}.mc-st .now b{color:#841132}.mc-st small{font-size:12px}',
    '.mc-trk{display:flex;justify-content:space-between;align-items:center;gap:8px;background:#FCE4E8;border-radius:12px;padding:12px 14px;margin-top:4px}.mc-trk b{font-size:18px;color:#841132;word-break:break-all}',
    '.mc-ol{display:flex;flex-direction:column;gap:12px}.mc-oi{display:flex;gap:12px;background:#fff;border:1px solid #f3e3d6;border-radius:18px;padding:12px;text-align:left;font:inherit;color:inherit;cursor:pointer;width:100%}',
    '.mc-oi .mc-ph{width:64px;height:64px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#8a5a66}',
    '.mc-oi .mc-col{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.mc-oi .mc-top{display:flex;justify-content:space-between;gap:8px;font-family:ui-monospace,Menlo,monospace;font-size:12px;color:#8a5a66}',
    '.mc-pill{font-family:Poppins,Prompt,sans-serif;font-size:11px;font-weight:600;color:#841132;background:#FCE4E8;padding:2px 8px;border-radius:999px;white-space:nowrap}',
    '.mc-pill.ok{background:#D7F0DC;color:#17652F}.mc-pill.bad{background:#F8D7DA;color:#842029}.mc-pill.off{background:#ead6cb;color:#3a0716}',
    '.mc-err{background:#F8D7DA;color:#842029;border-radius:12px;padding:10px 14px;font-size:13px;line-height:1.5}',
    '.mc-load{display:flex;align-items:center;justify-content:center;gap:10px;padding:40px 0;color:#8a5a66;font-size:14px}',
    '.mc-spin{width:20px;height:20px;border:2.5px solid #ead6cb;border-top-color:#841132;border-radius:50%;animation:mcs 0.8s linear infinite}',
    '@keyframes mcs{to{transform:rotate(360deg)}}',
    '.mc-empty{text-align:center;color:#8a5a66;padding:40px 0;font-size:14px}',
    '.mc-sh button:focus-visible,.mc-sh a:focus-visible{outline:2px solid #841132;outline-offset:2px}',
  ].join('');

  var ICON = {
    back: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
    close: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    truck: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg>',
    line: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M12 4C7 4 3 7.2 3 11.2c0 3.6 3.2 6.6 7.5 7.1-.2.8-.6 2.1-.7 2.4 0 0 0 .4.4.3.4-.1 3.6-2.4 5.1-3.6 3.4-1 5.7-3.4 5.7-6.2C21 7.2 17 4 12 4z"/></svg>',
    up: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg>',
    check: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2.6" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>',
    down: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>',
    warn: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#842029" stroke-width="2.4" aria-hidden="true"><path d="M12 8v5M12 17h.01"/><circle cx="12" cy="12" r="9"/></svg>',
  };

  /* ---------------- helpers ---------------- */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function baht(n) { return Number(n || 0).toLocaleString('th-TH', { maximumFractionDigits: 2 }) + ' บาท'; }
  function $(sel) { return S.root ? S.root.querySelector(sel) : null; }
  function variant(o) { return [o.color, o.size ? 'ไซซ์ ' + o.size : '', (o.qty || 1) + ' ชิ้น'].filter(Boolean).join(' · '); }
  function uuid() { return 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  var TH_M = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  function thDate(ms) { if (!ms) return ''; var d = new Date(ms); return d.getDate() + ' ' + TH_M[d.getMonth()] + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }

  function api(action, data) {
    if (!CFG.api) return Promise.reject(new Error('ยังไม่ได้ตั้งค่า MERA_CHECKOUT.api'));
    var body = Object.assign({ action: action }, data || {});
    var needAuth = ['config', 'quote'].indexOf(action) < 0;
    var optAuth = action === 'quote';   // ค่าส่งขึ้นกับลำดับสมาชิก → ส่ง token ถ้ามี ไม่มีก็ยังดูราคาได้
    var auth = !needAuth && !optAuth ? Promise.resolve() : CFG.testUserId ? Promise.resolve().then(function () { body.testUserId = CFG.testUserId; })
      : getToken().then(function (tok) { if (tok) body.idToken = tok; else if (needAuth) throw new Error(authHint()); });
    return auth.then(function () { return send(body); });
    function send(body) {
    if (typeof CFG.mockApi === 'function') return Promise.resolve(CFG.mockApi(body)).then(check);
    return fetch(CFG.api, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) })
      .catch(function () { throw new Error('เชื่อมต่อระบบสั่งซื้อไม่ได้ ตรวจอินเทอร์เน็ต หรือแจ้งทีม Mera (ลิงก์ api ไม่ถูกต้อง)'); })
      .then(function (r) { return r.text(); })
      .then(function (t) {
        var j; try { j = JSON.parse(t); } catch (e) { console.warn('mera-checkout: หลังบ้านตอบว่า', String(t).slice(0, 300)); throw new Error(diagnose(t)); }
        return j;
      }).then(check);
    }
    function check(j) { if (!j || !j.ok) { var e = new Error((j && j.error) || 'ระบบขัดข้อง ลองใหม่อีกครั้ง'); e.code = j && j.code; throw e; } return j; }
  }

  /** ขอ ID token จาก LINE (รอ LIFF เริ่มทำงานเสร็จก่อน สูงสุด 5 วินาที) */
  function getToken() {
    var t = CFG.getIdToken();
    if (t) return Promise.resolve(t);
    var l = window.liff;
    if (!l || !l.ready) return Promise.resolve('');
    return Promise.race([l.ready, new Promise(function (r) { setTimeout(r, 5000); })]).then(function () { return CFG.getIdToken(); }, function () { return ''; });
  }
  function authHint() {
    var l = window.liff;
    if (!l) return 'หน้าเว็บยังไม่ได้เชื่อม LINE (ไม่พบ LIFF) — กรุณาเปิดผ่านลิงก์ใน LINE ของ Mera';
    try {
      if (l.isLoggedIn && !l.isLoggedIn()) { l.login({ redirectUri: location.href }); return 'กำลังพาไปเข้าสู่ระบบ LINE…'; }
    } catch (e) {}
    return 'ยืนยันตัวตน LINE ไม่ได้: แอป LIFF ต้องเปิดสิทธิ์ (Scope) "openid" — แจ้งทีม Mera';
  }

  /** หลังบ้านตอบกลับไม่ใช่ JSON → บอกสาเหตุที่น่าจะเป็น (ให้ทีมแก้ได้ทันที) */
  function diagnose(t) {
    t = String(t || '').trim();
    var pre = 'ระบบสั่งซื้อยังไม่พร้อม: ';
    if (t === 'OK' || t === 'ERROR') return pre + 'Apps Script ยังไม่รับออเดอร์เว็บ — เพิ่ม 5 บรรทัด webHandlePost_ ใน doPost แล้ว Deploy → Manage deployments → New version';
    if (/accounts\.google\.com|ServiceLogin|Sign in/i.test(t)) return pre + 'ลิงก์ api ต้องตั้ง Who has access = Anyone';
    if (/Script function not found|ไม่พบฟังก์ชันสคริปต์|doPost/i.test(t)) return pre + 'ลิงก์ api ไม่ใช่ /exec ของโปรเจกต์ Inventory + GB';
    if (/<html/i.test(t)) return pre + 'Apps Script ตอบกลับเป็นหน้าเว็บ (ตรวจว่าใช้ลิงก์ /exec ไม่ใช่ /dev และ Deploy เวอร์ชันล่าสุดแล้ว)';
    return pre + 'หลังบ้านตอบกลับไม่ถูกต้อง (' + t.slice(0, 60) + ')';
  }

  /* ---------------- state + shell ---------------- */
  var CART_KEY = 'mera_cart_v1';
  var S = { root: null, view: '', item: null, items: [], cartMode: false, quote: null, config: null, addr: null, profileName: '', slip: null, busy: false, order: null, orders: null, stack: [] };

  function mount() {
    if (S.root) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    var ov = document.createElement('div'); ov.className = 'mc-ov'; ov.hidden = true;
    ov.innerHTML = '<div class="mc-sh" role="dialog" aria-modal="true" aria-labelledby="mc-title"></div>';
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    document.body.appendChild(ov);
    var fab = document.createElement('button'); fab.type = 'button'; fab.className = 'mc-cartfab'; fab.hidden = true;
    fab.addEventListener('click', function () { MeraCheckout.openCart(); });
    document.body.appendChild(fab);
    S.ov = ov; S.root = ov.firstChild; S.fab = fab; updateCartFab();
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !S.ov.hidden) back(); });
    window.addEventListener('popstate', function () { if (!S.ov.hidden) { S.popping = true; back(); S.popping = false; } });
  }
  function show() {
    mount();
    if (S.ov.hidden) {
      S.ov.hidden = false; S.prevOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
      try { history.pushState({ mc: 1 }, ''); } catch (e) {}
    }
  }
  function close() {
    if (!S.ov || S.ov.hidden) return;
    S.ov.hidden = true; document.body.style.overflow = S.prevOverflow || ''; S.stack = [];
    if (!S.popping) { try { if (history.state && history.state.mc) history.back(); } catch (e) {} }
  }
  function back() { var prev = S.stack.pop(); if (prev) go(prev, true); else close(); }
  function go(view, isBack) {
    if (!isBack && S.view && S.view !== view && S.view !== 'done') S.stack.push(S.view);
    if (view === 'done') S.stack = [];
    S.view = view; render();
    var bd = $('.mc-bd'); if (bd) bd.scrollTop = 0;
    var t = $('#mc-title'); if (t) { t.tabIndex = -1; t.focus({ preventScroll: true }); }
  }
  function header(title, step, canBack) {
    return '<div class="mc-hd">' + (canBack ? '<button class="mc-ib" data-a="back" aria-label="ย้อนกลับ">' + ICON.back + '</button>' : '') +
      '<h2 id="mc-title">' + esc(title) + '</h2>' + (step ? '<span class="mc-step">' + esc(step) + '</span>' : '') +
      '<button class="mc-ib" data-a="close" aria-label="ปิด">' + ICON.close + '</button></div>';
  }
  function loading(t) { return '<div class="mc-load"><span class="mc-spin"></span>' + esc(t || 'กำลังโหลด…') + '</div>'; }
  function errBox(msg) { return msg ? '<div class="mc-err" role="alert">' + esc(msg) + '</div>' : ''; }

  function cleanItem(item) {
    item = item || {};
    return { sku: String(item.sku || '').trim().toUpperCase(), qty: Math.max(1, Math.floor(Number(item.qty) || 1)),
      name: item.name || '', brand: item.brand || '', color: item.color || '', size: item.size || '', img: item.img || '' };
  }
  function readCart() {
    try { var a = JSON.parse(localStorage.getItem(CART_KEY) || '[]'); return Array.isArray(a) ? a.map(cleanItem).filter(function (x) { return x.sku; }) : []; }
    catch (e) { return []; }
  }
  function writeCart(items) {
    items = (items || []).map(cleanItem).filter(function (x) { return x.sku; });
    try { localStorage.setItem(CART_KEY, JSON.stringify(items)); } catch (e) {}
    updateCartFab(items);
  }
  function updateCartFab(items) {
    if (!S.fab) return;
    items = items || readCart();
    var n = items.reduce(function (sum, x) { return sum + (Number(x.qty) || 0); }, 0);
    S.fab.hidden = !n; S.fab.textContent = 'ตะกร้า · ' + n + ' ชิ้น';
  }
  function mergeCartItem(item) {
    var next = readCart(), x = cleanItem(item), old = next.find(function (it) { return it.sku === x.sku; });
    if (old) {
      old.qty = Math.min(5, old.qty + x.qty);
      // เติมข้อมูลแสดงผลใหม่ให้สินค้าที่เคยค้างอยู่ในตะกร้าเวอร์ชันเก่า
      ['name', 'brand', 'color', 'size', 'img'].forEach(function (k) { if (x[k]) old[k] = x[k]; });
    } else next.push(x);
    writeCart(next); return next;
  }

  function render() {
    var v = S.view, html = '';
    if (v === 'checkout') html = viewCheckout();
    else if (v === 'pay') html = viewPay();
    else if (v === 'done') html = viewOrder(S.order, true);
    else if (v === 'order') html = viewOrder(S.order, false);
    else if (v === 'orders') html = viewOrders();
    else if (v === 'gate') html = viewGate();
    else if (v === 'profile') html = viewProfile();
    else if (v === 'welcome') html = viewWelcome();
    // คงตำแหน่งเลื่อน + ช่องที่กำลังพิมพ์ไว้ (ไม่ให้เด้งกลับขึ้นบนตอนเลือกที่อยู่ / ข้อมูลโหลดเสร็จ)
    var bd0 = S.root.querySelector('.mc-bd'), keep = bd0 && v === S.lastView ? bd0.scrollTop : 0;
    var fa = document.activeElement, fid = fa && S.root.contains(fa) && fa.id ? fa.id : '', caret = null;
    try { caret = fid && fa.selectionStart != null ? fa.selectionStart : null; } catch (e) {}
    S.root.innerHTML = html;
    bind();
    var bd = S.root.querySelector('.mc-bd'); if (bd && keep) bd.scrollTop = keep;
    if (fid && v === S.lastView) {
      var el = document.getElementById(fid);
      if (el) { try { el.focus({ preventScroll: true }); if (caret != null && el.setSelectionRange) el.setSelectionRange(caret, caret); } catch (e) {} }
    }
    S.lastView = v;
  }

  /* ---------------- Membership: gate → รู้จักคุณอีกนิด → ต้อนรับ ---------------- */
  var PROFILE_Q = [
    { key: 'age', label: 'ช่วงอายุ', options: ['ต่ำกว่า 18', '18–23', '24–29', '30–39', '40+'] },
    { key: 'job', label: 'อาชีพ', options: ['นักเรียน / นักศึกษา', 'พนักงานบริษัท', 'Freelance', 'เจ้าของธุรกิจ', 'ข้าราชการ / รัฐวิสาหกิจ', 'อื่น ๆ', 'ไม่สะดวกตอบ'] },
    { key: 'income', label: 'รายได้โดยประมาณต่อเดือน (บาท)', options: ['ต่ำกว่า 10,000', '10,001–20,000', '20,001–30,000', '30,001–50,000', '50,001+', 'ไม่สะดวกตอบ'] },
    { key: 'area', label: 'พื้นที่อาศัยหลัก', options: ['กรุงเทพฯ', 'ปริมณฑล', 'ต่างจังหวัดเมืองใหญ่', 'ต่างจังหวัดอื่น ๆ'] },
    { key: 'fashionBudget', label: 'งบประมาณเสื้อผ้าต่อเดือน (บาท)', options: ['ต่ำกว่า 500', '500–1,000', '1,001–3,000', '3,000+'] },
  ];
  function memberQs() { return (S.mem && S.mem.profileOptions && S.mem.profileOptions.length) ? S.mem.profileOptions : PROFILE_Q; }
  var TICK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#FFFBED" stroke-width="3" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>';
  var LINE_G = '<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M12 3C6.5 3 2 6.6 2 11c0 3.9 3.5 7.2 8.3 7.9.3.1.8.2.9.5.1.3.1.7 0 1l-.1.9c0 .3-.2 1 .9.5 1.1-.5 5.9-3.5 8.1-6C21.4 14.1 22 12.6 22 11c0-4.4-4.5-8-10-8z"/></svg>';
  var TRUCK_P = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#FEBFC7" stroke-width="1.8" aria-hidden="true"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg>';
  var TRUCK_R = TRUCK_P.replace('#FEBFC7', '#841132').replace('width="32" height="32"', 'width="24" height="24"');

  function viewGate() {
    var sh = (S.mem && S.mem.shipping) || {};
    var perks = [sh.perk || 'ส่งฟรี* ตามเงื่อนไขของ Mera', 'ซื้อ จองดีล และเข้าร่วม Group Buy ได้', 'ดู Wishlist และออเดอร์ได้ทุกเครื่อง'];
    var h = header('สมัคร Mera Member', '', false) + '<div class="mc-bd">';
    h += '<section class="mc-gate"><i>' + TRUCK_P + '</i><h3>สมัคร Mera Member รับส่งฟรี</h3>' +
      '<p>สมัครผ่าน LINE ใช้เวลาไม่ถึง 1 นาที พร้อมรับสิทธิ์ส่งฟรีสำหรับคำสั่งซื้อกับ Mera*</p></section>';
    h += '<div class="mc-perks">' + perks.map(function (p) { return '<div><span>' + TICK + '</span>' + esc(p) + '</div>'; }).join('') + '</div>';
    h += errBox(S.gateErr);
    h += '<button class="mc-btnline" data-a="gateGo">' + LINE_G + (S.loggedIn ? 'สมัครด้วย LINE' : 'เข้าสู่ระบบด้วย LINE') + '</button>';
    h += '<span class="mc-how2">มือถือ: กด "อนุญาต" ในแอป LINE · คอม: สแกน QR ด้วยแอป LINE\nไม่ต้องตั้งรหัสผ่าน · *ตามเงื่อนไขของ Mera</span>';
    return h + '</div>';
  }

  function viewProfile() {
    var a = S.profAns || {}, qs = memberQs();
    var n = qs.filter(function (q) { return a[q.key]; }).length;
    var ready = n === qs.length && S.profPolicy;
    var h = header('รู้จักคุณอีกนิด', '', true) + '<div class="mc-bd">';
    h += '<span class="mc-ok"><span>' + TICK + '</span>เชื่อมต่อ LINE แล้ว' + (S.profileName ? ' · ' + esc(S.profileName) : '') + '</span>';
    h += '<section class="mc-phead"><h3>รู้จักคุณอีกนิด</h3><p>ใช้เวลาไม่ถึง 1 นาที เพื่อช่วยให้ Mera เข้าใจลูกค้าและแนะนำดีลที่เหมาะกับคุณมากขึ้น</p>' +
      '<div class="mc-bars" aria-hidden="true">' + qs.map(function (q) { return '<span' + (a[q.key] ? ' class="on"' : '') + '></span>'; }).join('') + '</div>' +
      '<small>ตอบแล้ว ' + n + ' จาก ' + qs.length + ' ข้อ</small></section>';
    qs.forEach(function (q) {
      h += '<fieldset class="mc-fs"><legend>' + esc(q.label) + '</legend><div class="mc-cps">' + q.options.map(function (o) {
        var on = a[q.key] === o;
        return '<button type="button" class="mc-cp' + (on ? ' on' : '') + '" data-a="prof" data-g="' + esc(q.key) + '" data-v="' + esc(o) + '" aria-pressed="' + on + '">' + esc(o) + '</button>';
      }).join('') + '</div></fieldset>';
    });
    var pol = CFG.privacyUrl ? '<a href="' + esc(CFG.privacyUrl) + '" target="_blank" rel="noopener">นโยบายความเป็นส่วนตัว</a>' : 'นโยบายความเป็นส่วนตัว';
    h += '<button type="button" class="mc-ck' + (S.profPolicy ? ' on' : '') + '" data-a="profPolicy" role="checkbox" aria-checked="' + !!S.profPolicy + '"><b>' + (S.profPolicy ? '✓' : '') + '</b><span>ฉันยอมรับ ' + pol + '</span></button>';
    h += '<button type="button" class="mc-ck' + (S.profMkt ? ' on' : '') + '" data-a="profMkt" role="checkbox" aria-checked="' + !!S.profMkt + '"><b>' + (S.profMkt ? '✓' : '') + '</b><span>รับข่าวสารและโปรโมชั่นจาก Mera ผ่าน LINE <span style="color:#8a5a66">(ไม่บังคับ)</span></span></button>';
    h += errBox(S.profErr);
    h += '<button class="mc-btn" data-a="profSave"' + (ready && !S.busy ? '' : ' disabled') + '>' + (S.busy ? 'กำลังบันทึก…' : 'สมัครและไปต่อ') + '</button>';
    if (!ready) h += '<span class="mc-hint" style="text-align:center;color:#B4321F">ตอบให้ครบ ' + qs.length + ' ข้อ และยอมรับนโยบายก่อนไปต่อ</span>';
    h += '<span class="mc-hint" style="text-align:center">ถามครั้งเดียว · แก้ไขได้ที่ "บัญชีของฉัน"</span>';
    return h + '</div>';
  }

  function viewWelcome() {
    var m = (S.mem && S.mem.member) || {}, sh = (S.mem && S.mem.shipping) || {};
    var it = S.items[0] || {}, more = S.items.length - 1;
    var h = header('ยินดีต้อนรับ', '', false) + '<div class="mc-bd">';
    h += '<section class="mc-hero"><i>' + ICON.check + '</i><h3>ยินดีต้อนรับค่ะ' + (S.profileName ? ' คุณ ' + esc(S.profileName) : '') + '</h3>' +
      '<span style="font-size:14px;color:#FEBFC7">คุณเป็น Mera Member แล้ว</span>' +
      (m.customerId ? '<small>รหัสสมาชิก</small><span class="mc-id">' + esc(m.customerId) + '</span>' : '') + '</section>';
    h += '<div class="mc-perk"><i>' + TRUCK_R + '</i><div><b>' + (sh.free ? 'ส่งฟรีออเดอร์นี้*' : 'ค่าส่ง ' + baht(sh.fee || 0) + '/ออเดอร์') + '</b>' +
      '<span>' + esc(sh.free ? 'ใช้สิทธิ์ให้อัตโนมัติตอนชำระเงิน · *ตามเงื่อนไขของ Mera' : (sh.policy || '')) + '</span></div></div>';
    if (it.sku) h += orderProductCard(Object.assign({}, it, { unit: 0 })).replace(/<b style="color:#841132">[^<]*<\/b>/, more > 0 ? '<b style="color:#841132">+ อีก ' + more + ' รายการ</b>' : '');
    h += '<button class="mc-btn" data-a="welcomeGo">ไปชำระเงิน</button><button class="mc-btn2" data-a="close">ดูสินค้าต่อ</button>';
    return h + '</div>';
  }

  /** เช็กสมาชิกก่อนซื้อ: ยังไม่ล็อกอิน / ยังกรอกไม่ครบ → หน้า gate */
  function checkMember() {
    S.gateErr = '';
    return Promise.all([loadConfig(), api('memberGet').then(function (j) { S.loggedIn = true; return j; }, function (err) {
      if (err.code === 'AUTH' || /LINE/.test(err.message)) { S.loggedIn = false; return null; }
      return { error: err };
    })]).then(function (r) {
      var cfg = r[0] || {}, j = r[1];
      if (j && j.error) return true;                       // ระบบสมาชิกขัดข้อง → ไม่ขวางการซื้อ หลังบ้านตรวจซ้ำอยู่แล้ว
      if (j) { S.mem = j; if (j.name) S.profileName = S.profileName || j.name; }
      if (cfg.requireProfile !== true) return true;          // หลังบ้านยังไม่เปิดบังคับสมัคร (หรือยังเป็นเวอร์ชันเก่า) → ซื้อได้ตามเดิม
      S.needGate = !j || !j.profileComplete;
      return !S.needGate;
    });
  }
  function openGate() {
    var m = (S.mem && S.mem.member) || {}, qs = memberQs();
    S.profAns = {}; qs.forEach(function (q) { var v = m[q.key]; if (v && q.options.indexOf(v) >= 0) S.profAns[q.key] = v; });
    S.profPolicy = false; S.profMkt = !!m.marketing; S.profErr = '';
    S.stack = []; S.view = ''; go('gate');
  }
  function saveProfile() {
    if (S.busy) return;
    S.busy = true; S.profErr = ''; render();
    var ans = Object.assign({}, S.profAns, { acceptPolicy: true, marketing: !!S.profMkt,
      policyVersion: (S.mem && S.mem.policyVersion) || (S.config && S.config.policyVersion) || '' });
    api('memberSave', { answers: ans }).then(function (j) {
      S.busy = false;
      S.mem = Object.assign({}, S.mem || {}, { member: j.member, profileComplete: j.profileComplete, missing: j.missing, shipping: j.shipping });
      if (!j.profileComplete) { S.profErr = 'ยังตอบไม่ครบ กรุณาตรวจอีกครั้ง'; return render(); }
      S.needGate = false; S.stack = []; S.view = ''; go('welcome');
      try { document.dispatchEvent(new CustomEvent('mera:member', { detail: j.member })); } catch (er) {}
    }).catch(function (err) { S.busy = false; S.profErr = err.message; render(); });
  }
  function lineLogin() {
    var l = window.liff;
    if (l && l.login) {
      try { sessionStorage.setItem('mc_resume', JSON.stringify({ cart: S.cartMode, items: S.items })); } catch (e) {}   // กลับมาซื้อต่อหลังล็อกอิน
      try { l.login({ redirectUri: location.href }); return; } catch (e) { try { sessionStorage.removeItem('mc_resume'); } catch (er) {} }
    }
    S.gateErr = 'เปิดหน้านี้ผ่าน LINE (แตะลิงก์ Mera ในแชท LINE) แล้วกดอีกครั้ง'; render();
  }

  /* ---------------- view: สรุปออเดอร์ ---------------- */
  function productCard(o) {
    var left = o.available;
    return '<section class="mc-card mc-prod">' + (o.img ? '<img src="' + esc(o.img) + '" alt="' + esc(o.name) + '" onerror="this.outerHTML=\'<span class=&quot;mc-ph&quot;></span>\'">' : '<span class="mc-ph"></span>') +
      '<div class="mc-col"><span class="mc-brand">' + esc(o.brand) + '</span><span class="mc-name">' + esc(o.name) + '</span>' +
      '<span class="mc-sub">' + esc(variant(o)) + '</span>' +
      (left != null ? '<span class="mc-left' + (left <= 3 ? ' low' : '') + '">' + (left > 0 ? (left <= 3 ? 'เหลือแค่ ' : 'เหลือ ') + left + ' ชิ้น' : 'สินค้าหมด') + '</span>' : '') +
      (o.sku ? '<span class="mc-sku">SKU ' + esc(o.sku) + '</span>' : '') + '</div></section>';
  }
  function cartProductCard(o) {
    var left = o.available, bad = left != null && left < o.qty;
    return '<section class="mc-prodline">' + (o.img ? '<img src="' + esc(o.img) + '" alt="' + esc(o.name) + '" onerror="this.outerHTML=\'<span class=&quot;mc-ph&quot;></span>\'">' : '<span class="mc-ph"></span>') +
      '<div class="mc-col"><span class="mc-brand">' + esc(o.brand) + '</span><span class="mc-name">' + esc(o.name) + '</span>' +
      '<span class="mc-sub">' + esc([o.color, o.size ? 'ไซซ์ ' + o.size : ''].filter(Boolean).join(' · ')) + '</span>' +
      '<span class="mc-sku">SKU ' + esc(o.sku) + '</span>' +
      (left != null ? '<span class="mc-left' + (left <= 3 || bad ? ' low' : '') + '">' + (left > 0 ? (left <= 3 ? 'เหลือแค่ ' : 'เหลือ ') + left + ' ชิ้น' : 'สินค้าหมด') + '</span>' : '') + '</div>' +
      '<div class="mc-linefoot"><b style="color:#841132">' + baht((o.unit || 0) * o.qty) + '</b><span class="mc-qty">' +
      '<button type="button" data-a="cartDec" data-sku="' + esc(o.sku) + '" aria-label="ลดจำนวน">−</button><b>' + o.qty + '</b>' +
      '<button type="button" data-a="cartInc" data-sku="' + esc(o.sku) + '" aria-label="เพิ่มจำนวน"' + (left != null && o.qty >= left ? ' disabled' : '') + '>+</button></span>' +
      '<button type="button" class="mc-remove" data-a="cartRemove" data-sku="' + esc(o.sku) + '">นำออก</button></div></section>';
  }
  /* คำถามเชิงลึกของสมาชิก (ถามเฉพาะข้อที่ยังไม่เคยตอบ · ไม่บังคับ) */
  var BUDGET_TH = { '<300': 'ต่ำกว่า 300', '300-500': '300–500', '501-700': '501–700', '701+': '700 ขึ้นไป' };
  function prefsForm() {
    if (!CFG.askPrefs) return '';   // Membership V1: หมวด/งบ/ไซซ์ ย้ายไปถามใน Waiting List · เปิดกลับได้ด้วย MERA_CHECKOUT.askPrefs
    var miss = S.prefMissing || [], o = S.prefOptions, a = S.prefAns;
    if (!miss.length || !o) return '';
    var chip = function (group, val, label, on) { return '<button type="button" class="mc-cp' + (on ? ' on' : '') + '" data-a="pref" data-g="' + group + '" data-v="' + esc(val) + '" aria-pressed="' + on + '">' + esc(label) + '</button>'; };
    var h = '<section class="mc-sec mc-pref"><h3>ช่วยบอก Mera อีกนิด<span class="mc-tag">ตอบครั้งเดียว</span></h3><span class="mc-hint" style="margin-top:-6px">ใช้เลือกดีลและสินค้าที่ตรงกับคุณ ข้ามได้</span>';
    if (miss.indexOf('category') >= 0) h += '<div class="mc-q"><b>สนใจหมวดไหน <small>(เลือกได้หลายข้อ)</small></b><div class="mc-cps">' + o.categories.map(function (c) { return chip('category', c, c, a.category.indexOf(c) >= 0); }).join('') + '</div></div>';
    if (miss.indexOf('budget') >= 0) h += '<div class="mc-q"><b>งบต่อชิ้น (บาท)</b><div class="mc-cps">' + o.budgets.map(function (c) { return chip('budget', c, BUDGET_TH[c] || c, a.budget === c); }).join('') + '</div></div>';
    if (miss.indexOf('size') >= 0) h += '<div class="mc-q"><b>ไซซ์เสื้อผ้าที่ใส่ประจำ</b><div class="mc-cps">' + o.sizes.map(function (c) { return chip('size', c, c, a.size === c); }).join('') + '</div></div>';
    return h + '</section>';
  }
  function etaCard(eta, note) {
    if (!eta) return '';
    return '<section class="mc-card mc-eta"><i>' + ICON.truck + '</i><div><small>คาดว่าจะได้รับ</small><b>' + esc(eta.label) + '</b>' +
      (note ? '<em>' + esc(note) + '</em>' : '') + '</div></section>';
  }
  function viewCheckout() {
    var it = S.item, q = S.quote, cart = S.cartMode;
    var h = header(cart ? 'ตะกร้าสินค้า' : 'สรุปออเดอร์', 'ขั้นตอน 1/2', false) + '<div class="mc-bd">';
    h += '<div class="mc-chip"><i>' + ICON.line + '</i><span>เข้าสู่ระบบด้วย LINE' + (S.profileName ? ' · <b>' + esc(S.profileName) + '</b>' : '') + '</span></div>';
    if (S.loadErr) return h + errBox(S.loadErr) + '<button class="mc-btn2" data-a="close">ปิด</button></div>';
    if (!q) return h + loading('กำลังเช็กราคาและสต็อก…') + '</div>';
    if (cart) {
      var quoted = {}, problemBySku = {};
      (q.items || []).forEach(function (x) { quoted[x.sku] = x; });
      (q.problems || []).forEach(function (x) { problemBySku[x.sku] = x; });
      var cards = S.items.map(function (local) {
        var remote = quoted[local.sku] || {}, problem = problemBySku[local.sku] || {};
        return Object.assign({}, local, remote, { img: local.img || remote.img, available: remote.available != null ? remote.available : problem.available });
      });
      h += '<div class="mc-prodlist">' + cards.map(cartProductCard).join('') + '</div>';
      h += '<button class="mc-btn2" data-a="shopMore">+ เลือกสินค้าเพิ่ม</button>';
    } else {
      h += productCard(Object.assign({}, it, { brand: it.brand || q.product.brand, name: it.name || q.product.name, color: q.product.color, size: q.product.size, sku: q.product.sku,
        img: it.img || q.product.img, available: q.available }));
    }
    h += etaCard(q.eta, 'แบรนด์จัดส่งภายใน 2 วันหลังตรวจสลิป');
    var p = q.price;
    h += '<section class="mc-card"><div class="mc-row"><span>' + (cart ? 'ราคาสินค้า (' + p.qty + ' ชิ้น)' : 'ราคาสินค้า (' + p.unit + ' × ' + p.qty + ')') + '</span><span>' + baht(p.subtotal) + '</span></div>' +
      '<div class="mc-row"><span>ค่าส่ง</span><span>' + (p.shipping ? baht(p.shipping) : '<span class="mc-free">' + esc(p.shipLabel || 'ฟรี') + '</span>') + '</span></div>' +
      (p.saved ? '<div class="mc-row"><span>ประหยัดไป</span><span class="mc-free">' + baht(p.saved) + '</span></div>' : '') +
      '<div class="mc-hr"></div><div class="mc-total"><span style="font-size:14px;font-weight:600">ยอดที่ต้องโอน</span><b>' + baht(p.total) + '</b></div>' +
      (p.shipPolicy ? '<span class="mc-hint" style="display:block;margin-top:8px">' + esc(p.shipPolicy) + '</span>' : '') + '</section>';
    var problems = cart ? (q.problems || []) : (q.available < q.qty ? [{ error: q.available ? 'สินค้าเหลือ ' + q.available + ' ชิ้น ลดจำนวนก่อนสั่งซื้อ' : 'สินค้าหมดแล้ว' }] : []);
    if (problems.length) h += errBox('กรุณาแก้ตะกร้า: ' + problems.map(function (x) { return (x.sku ? x.sku + ' ' : '') + x.error; }).join(' · '));
    h += addressForm();
    h += prefsForm();
    h += errBox(S.formErr);
    h += '<button class="mc-btn" data-a="toPay"' + (problems.length ? ' disabled' : '') + '>ยืนยันออเดอร์ · ไปชำระ ' + baht(p.total) + '</button>';
    return h + '</div>';
  }
  function addressForm() {
    var a = S.addr || {}, db = ADDR.ready;
    var f = function (id, label, input) { return '<label class="mc-f" id="mcf-' + id + '">' + label + input + '</label>'; };
    var inp = function (id, val, attrs) { return '<input id="mc-' + id + '" value="' + esc(val) + '" ' + (attrs || '') + '>'; };
    var sel = function (id, list, val, ph) {
      return '<select id="mc-' + id + '"><option value="">' + esc(ph) + '</option>' + list.map(function (x) { return '<option' + (x === val ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('') + '</select>';
    };
    var h = '<section class="mc-sec"><h3>ที่อยู่จัดส่ง' + (S.addrPrefilled ? '<span class="mc-tag">ค่าเริ่มต้น</span>' : '') + '</h3>';
    h += f('name', 'ชื่อ-นามสกุลผู้รับ', inp('name', a.name, 'autocomplete="name"'));
    h += f('phone', 'เบอร์โทร', inp('phone', a.phone, 'type="tel" inputmode="tel" autocomplete="tel" placeholder="08X-XXX-XXXX"'));
    h += f('line', 'บ้านเลขที่ / หมู่บ้าน / ซอย / ถนน', inp('line', a.line, 'autocomplete="address-line1" placeholder="เช่น 99/1 หมู่บ้าน… ซอย… ถนน…"'));
    h += '<div class="mc-g2">';
    h += f('postcode', 'รหัสไปรษณีย์', inp('postcode', a.postcode, 'inputmode="numeric" maxlength="5" autocomplete="postal-code"'));
    if (db) {
      h += f('province', 'จังหวัด', sel('province', ADDR.provinces(a.postcode), a.province, 'เลือกจังหวัด'));
      h += f('district', 'เขต / อำเภอ', sel('district', ADDR.districts(a.province, a.postcode), a.district, 'เลือก'));
      h += f('subdistrict', 'แขวง / ตำบล', sel('subdistrict', ADDR.subdistricts(a.province, a.district, a.postcode), a.subdistrict, 'เลือก'));
    } else {
      h += f('province', 'จังหวัด', inp('province', a.province, 'autocomplete="address-level1"'));
      h += f('district', 'เขต / อำเภอ', inp('district', a.district, 'autocomplete="address-level2"'));
      h += f('subdistrict', 'แขวง / ตำบล', inp('subdistrict', a.subdistrict, 'autocomplete="address-level3"'));
    }
    h += '</div>' + (db ? '<span class="mc-hint">พิมพ์รหัสไปรษณีย์ แล้วเลือกจังหวัด เขต แขวงจากรายการ</span>' : '');
    h += '<label class="mc-chk"><input type="checkbox" id="mc-save"' + (S.saveAddr !== false ? ' checked' : '') + '>จำที่อยู่นี้ไว้ใช้ครั้งต่อไป</label></section>';
    return h;
  }
  function readAddr() {
    var g = function (id) { var el = $('#mc-' + id); return el ? el.value.trim() : ''; };
    if (!$('#mc-name')) return;
    S.addr = { name: g('name'), phone: g('phone'), line: g('line'), postcode: g('postcode'), province: g('province'), district: g('district'), subdistrict: g('subdistrict') };
    var s = $('#mc-save'); if (s) S.saveAddr = s.checked;
  }
  function validAddr() {
    var a = S.addr, bad = [];
    if (!a.name) bad.push(['name', 'กรอกชื่อผู้รับ']);
    if (!/^0\d{8,9}$/.test(a.phone.replace(/\D/g, ''))) bad.push(['phone', 'เบอร์โทรไม่ถูกต้อง']);
    if (!a.line) bad.push(['line', 'กรอกบ้านเลขที่ / ถนน']);
    if (!/^\d{5}$/.test(a.postcode)) bad.push(['postcode', 'รหัสไปรษณีย์ 5 หลัก']);
    if (!a.province) bad.push(['province', 'เลือกจังหวัด']);
    if (!a.district) bad.push(['district', 'เลือกเขต/อำเภอ']);
    if (!a.subdistrict) bad.push(['subdistrict', 'เลือกแขวง/ตำบล']);
    return bad;
  }

  /* ---------------- view: โอนจ่าย ---------------- */
  function viewPay() {
    var p = S.quote.price, pay = (S.config && S.config.payment) || {};
    var h = header(S.reupload ? 'แนบสลิปใหม่' : 'ชำระเงิน', S.reupload ? '' : 'ขั้นตอน 2/2', true) + '<div class="mc-bd">';
    var amt = Number(p.total).toLocaleString('th-TH', { minimumFractionDigits: 2 });
    var acct = (String(pay.text || '').match(/\d{3}-?\d-?\d{5}-?\d/) || [])[0] || '';
    var hasQr = pay.promptpayId || pay.qrUrl;
    // การ์ด QR แบบหน้าชำระเงินของแอปช้อปปิ้ง: หัว Thai QR · รูป QR พอดีกรอบ · ยอด · ปุ่มบันทึก QR
    h += '<section class="mc-qrcard">' +
      (hasQr ? '<div class="mc-qrhead">THAI QR PAYMENT<span>พร้อมเพย์</span></div>' : '') +
      (pay.promptpayId ? '<div class="mc-qrimg" id="mc-qr" role="img" aria-label="QR พร้อมเพย์ ' + amt + ' บาท"></div>'
        : pay.qrUrl ? '<div class="mc-qrimg"><img id="mc-qrpic" src="' + esc(pay.qrUrl) + '" alt="QR พร้อมเพย์สำหรับโอนเงิน"></div>' : '') +
      '<div class="mc-qrbody"><span class="mc-qrlab">ยอดชำระ</span><span class="mc-amt">' + amt + ' <small>บาท</small></span>' +
      (pay.accountName ? '<b style="font-size:14px">' + esc(pay.accountName) + '</b>' : '') +
      (pay.text ? '<span class="mc-acct">' + esc(pay.text) + '</span>' : '') +
      (hasQr ? '<button class="mc-btn" data-a="saveQr">' + ICON.down + 'บันทึกรูป QR</button><span class="mc-hint">ถ้ากดแล้วไม่บันทึก ให้กดค้างที่รูป QR แล้วเลือก "บันทึกรูปภาพ"</span>' : '') +
      '<div class="mc-copies"><button class="mc-out" data-a="copy" data-v="' + esc(String(p.total)) + '">คัดลอกยอด</button>' +
      (acct ? '<button class="mc-out" data-a="copy" data-v="' + esc(acct.replace(/-/g, '')) + '">คัดลอกเลขบัญชี</button>' : '') + '</div></div></section>';
    h += '<section class="mc-card mc-how"><b>วิธีชำระ</b><ol>' +
      (hasQr ? '<li>บันทึกรูป QR ลงเครื่อง</li><li>เปิดแอปธนาคาร → สแกน → เลือกรูป QR จากอัลบั้ม</li>' : '<li>โอนเข้าบัญชีด้านบน</li>') +
      '<li>โอนยอด <b>' + amt + ' บาท</b> แล้วบันทึกสลิป</li><li>กลับมาหน้านี้ แนบสลิปด้านล่าง</li></ol></section>';
    h += '<section class="mc-sec"><h3>แนบสลิป</h3>';
    if (S.slip) h += '<div class="mc-slip"><img src="' + S.slip.preview + '" alt="สลิปที่แนบ"><div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:2px"><b style="font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(S.slip.name) + '</b><span style="font-size:12px;color:#5e2a37">แนบแล้ว</span></div><button class="mc-btn2" style="width:auto;padding:0 8px" data-a="pickSlip">เปลี่ยนรูป</button></div>';
    else h += '<button class="mc-up" data-a="pickSlip">' + ICON.up + '<b>แตะเพื่อเลือกรูปสลิป</b><small>รูปจากแอปธนาคาร</small></button>';
    h += '<input type="file" id="mc-file" accept="image/*" hidden></section>';
    h += errBox(S.payErr);
    h += '<button class="mc-btn" data-a="submit"' + (!S.slip || S.busy ? ' disabled' : '') + '>' + (S.busy ? '<span class="mc-spin" style="border-color:rgba(255,251,237,.4);border-top-color:#FFFBED"></span>กำลังส่ง…' : 'ยืนยันการชำระเงิน') + '</button>';
    h += '<p class="mc-note">ทีม Mera ตรวจสลิปภายใน 1 ชม. แล้วแจ้งผลทาง LINE</p>';
    return h + '</div>';
  }

  /* ---------------- view: สถานะออเดอร์ / สำเร็จ ---------------- */
  var STEPS = [['Pending Slip', 'ได้รับออเดอร์ + สลิป'], ['Checking', 'ตรวจสลิป'], ['Confirmed', 'แบรนด์แพ็กของ'], ['Shipped', 'จัดส่ง · แจ้งเลขพัสดุทาง LINE'], ['Received', 'ได้รับสินค้า']];
  function timeline(o) {
    var at = o.received ? 5 : ({ 'Pending Slip': 1, 'Error': 1, 'Confirmed': 2, 'Partially Shipped': 3, 'Shipped': 4 }[o.status] || 1);
    var recAt = (o.receipt || []).reduce(function (m, x) { return Math.max(m, x.receivedAt || 0); }, 0);
    var sub = [thDate(o.createdAt), at === 1 ? 'ภายใน 1 ชม.' : thDate(o.paidAt), '', o.shippedAt ? thDate(o.shippedAt) : '', o.received && recAt ? thDate(recAt) : 'กด "ได้รับของแล้ว" ด้านบนเมื่อได้รับครบ'];
    var END = STEPS.length;
    return '<section class="mc-card mc-tl"><h4>สถานะออเดอร์</h4>' + STEPS.map(function (s, i) {
      var done = i < at || (at === END), now = i === at && at < END, last = i === STEPS.length - 1;
      return '<div class="mc-st' + (now ? ' now' : '') + '"><div><span class="mc-dot' + (done ? ' done' : now ? ' now' : '') + '"></span>' +
        (last ? '' : '<span class="mc-line' + (i + 1 <= at ? ' done' : '') + '"></span>') + '</div>' +
        '<div' + (now ? ' class="now"' : '') + '><b' + (done || now ? '' : ' style="font-weight:400;color:#5e2a37"') + '>' + esc(s[1]) + '</b>' + (sub[i] && (done || now) ? '<small>' + esc(sub[i]) + '</small>' : '') + '</div></div>';
    }).join('') + '</section>';
  }
  function orderProductCard(o) {
    return '<section class="mc-card mc-prod" style="align-items:center">' +
      (o.img ? '<img src="' + esc(o.img) + '" alt="" style="width:64px;height:64px">' : '<span class="mc-ph" style="width:64px;height:64px"></span>') +
      '<div class="mc-col"><span class="mc-brand">' + esc(o.brand || '') + '</span><span class="mc-name" style="font-size:14px">' + esc(o.name || o.sku) + '</span>' +
      '<span class="mc-sub" style="font-size:12px">' + esc(variant(o)) + '</span><b style="color:#841132">' + baht((o.unit || 0) * (o.qty || 1)) + '</b></div></section>';
  }
  function viewOrder(o, fresh) {
    var h = header(fresh ? 'สั่งซื้อสำเร็จ' : 'ออเดอร์ ' + (o ? o.id : ''), '', !fresh) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '</div>';
    if (!o) return h + loading() + '</div>';
    if (o.status === 'Slip Rejected') {
      h += '<section class="mc-hero warn"><i>' + ICON.warn + '</i><h3>สลิปไม่ผ่าน</h3><span style="font-size:13px">' + esc(o.rejectReason || 'กรุณาแนบสลิปใหม่ หรือทักแอดมินทาง LINE') + '</span><small>เลขออเดอร์</small><span class="mc-id">' + esc(o.id) + '</span></section>';
    } else if (o.status === 'Cancelled') {
      h += '<section class="mc-hero warn"><i>' + ICON.warn + '</i><h3>ยกเลิกแล้ว</h3><small>เลขออเดอร์</small><span class="mc-id">' + esc(o.id) + '</span></section>';
    } else if (o.received && !fresh) {
      h += '<section class="mc-hero"><i>' + ICON.check + '</i><h3>ได้รับสินค้าแล้ว</h3><span style="font-size:13px">ขอบคุณที่ช้อปกับ Mera ค่ะ</span><small>เลขออเดอร์</small><span class="mc-id">' + esc(o.id) + '</span></section>';
    } else {
      var HERO = { 'Pending Slip': ['ได้รับออเดอร์แล้ว', 'ทีม Mera กำลังตรวจสลิป (ภายใน 1 ชม.)'], Confirmed: ['ยืนยันแล้ว', 'แบรนด์กำลังเตรียมจัดส่ง'], 'Partially Shipped': ['จัดส่งบางส่วนแล้ว', 'สินค้าจากบางแบรนด์กำลังเดินทาง'],
        Shipped: ['จัดส่งแล้ว', 'แจ้งเลขพัสดุทาง LINE แล้ว'], Error: ['ได้รับออเดอร์แล้ว', 'ทีม Mera กำลังตรวจสอบ'] }[o.status] || [o.statusLabel, ''];
      var sub = fresh ? 'ส่งใบสรุปออเดอร์ไปที่ LINE ของคุณแล้ว' : HERO[1];
      h += '<section class="mc-hero"><i>' + ICON.check + '</i><h3>' + esc(fresh ? 'ได้รับออเดอร์แล้ว' : HERO[0]) + '</h3>' +
        (sub ? '<span style="font-size:13px">' + esc(sub) + '</span>' : '') + '<small>เลขออเดอร์</small><span class="mc-id">' + esc(o.id) + '</span></section>';
    }
    var many = o.items && o.items.length > 1;
    if (many && !(fresh && S.orderedItems && S.orderedItems.length)) {
      var pic = {}; (S.orderedItems || []).forEach(function (x) { if (x.img) pic[x.sku] = x.img; });
      h += '<div class="mc-prodlist">' + o.items.map(function (x) { return orderProductCard(Object.assign({}, x, { img: x.img || pic[x.sku] || '' })); }).join('') + '</div>';
      h += '<section class="mc-card">' + (o.shipping ? '<div class="mc-row"><span>ค่าส่ง</span><span>' + baht(o.shipping) + '</span></div>' : '') +
        '<div class="mc-total"><span style="font-size:14px;font-weight:600">ยอดชำระรวม</span><b>' + baht(o.total) + '</b></div></section>';
    } else if (fresh && S.orderedItems && S.orderedItems.length) {
      h += '<div class="mc-prodlist">' + S.orderedItems.map(orderProductCard).join('') + '</div>';
      h += '<section class="mc-card"><div class="mc-total"><span style="font-size:14px;font-weight:600">ยอดชำระรวม</span><b>' + baht(o.total) + '</b></div></section>';
    } else {
      h += '<section class="mc-card mc-prod" style="align-items:center">' + (o.img ? '<img src="' + esc(o.img) + '" alt="" style="width:64px;height:64px">' : '') +
        '<div class="mc-col"><span class="mc-name" style="font-size:14px">' + esc(o.name) + '</span><span class="mc-sub" style="font-size:12px">' + esc(variant(o)) + '</span><b style="color:#841132">' + baht(o.total) + '</b></div></section>';
    }
    var brands = []; (o.items || []).forEach(function (x) { if (x.brand && brands.indexOf(x.brand) < 0) brands.push(x.brand); });
    if (brands.length > 1 && (o.shipments || []).length) {
      // หลายแบรนด์: เลขพัสดุแยกตามแบรนด์ แบรนด์ที่ยังไม่ส่งขึ้นว่ากำลังเตรียม
      h += '<section class="mc-card"><b style="font-size:14px">การจัดส่ง (' + o.shipments.length + '/' + brands.length + ' แบรนด์)</b>' + brands.map(function (bn) {
        var s = o.shipments.filter(function (x) { return x.brand === bn; })[0];
        return '<div class="mc-row" style="margin-top:10px"><span>' + esc(bn) + '</span><b>' + (s ? esc(s.company || '') : 'กำลังเตรียมจัดส่ง') + '</b></div>' +
          (s ? '<div class="mc-trk"><b>' + esc(s.tracking) + '</b><button class="mc-out" data-a="copyTrk" data-v="' + esc(s.tracking) + '">คัดลอก</button></div>' : '');
      }).join('') + '</section>';
    } else if (o.tracking) h += '<section class="mc-card"><div class="mc-row"><span>บริษัทขนส่ง</span><b>' + esc(o.shippingCompany || '-') + '</b></div><div class="mc-trk"><b>' + esc(o.tracking) + '</b><button class="mc-out" data-a="copyTrk">คัดลอก</button></div></section>';
    else if (o.eta && o.status !== 'Slip Rejected') h += '<div class="mc-band"><span>คาดว่าจะได้รับ</span><b>' + esc(o.eta.label) + '</b></div>';
    if (!fresh) h += receiptCard(o);
    if (o.status !== 'Slip Rejected' && o.status !== 'Cancelled') h += timeline(o);
    if (o.status === 'Slip Rejected') h += '<button class="mc-btn" data-a="reupload">แนบสลิปใหม่</button>';
    else h += '<a class="mc-btn" href="https://line.me/R/ti/p/' + encodeURIComponent(CFG.lineOaId) + '" target="_blank" rel="noopener">ดูออเดอร์ใน LINE</a>';
    h += '<button class="mc-btn2" data-a="' + (fresh ? 'close' : 'orders') + '">' + (fresh ? 'กลับไปช็อปต่อ' : 'ออเดอร์ทั้งหมด') + '</button>';
    return h + '</div>';
  }
  /** ได้รับของแล้ว / มีปัญหา (รายแบรนด์) */
  function receiptCard(o) {
    var rc = o.receipt || [];
    if (!rc.length || !rc.some(function (x) { return x.state !== 'preparing'; })) return '';
    var many = rc.length > 1, open = rc.some(function (x) { return x.state === 'shipped'; });
    var h = '<section class="mc-card mc-rcv"><h4>' + (open ? 'ได้รับสินค้าแล้วหรือยัง?' : 'การรับสินค้า') + '</h4>';
    if (open) h += '<span class="mc-sub" style="font-size:12px">กดยืนยันเมื่อได้รับของครบ ถ้ามีปัญหา (ของไม่ครบ / ชำรุด / ผิดแบบ) แจ้งได้ภายใน 3 วันหลังได้รับ</span>';
    rc.forEach(function (x) {
      var b = esc(x.brand || ''), title = many ? '<div class="mc-row"><span>' + b + '</span></div>' : '';
      h += '<div class="mc-rb">' + title;
      if (x.state === 'received') h += '<span class="mc-rok">✓ ได้รับแล้ว' + (x.receivedAt ? ' · ' + esc(thDate(x.receivedAt)) : '') + '</span>';
      else if (x.state === 'issue') h += '<span class="mc-rwarn">แจ้งปัญหาแล้ว ทีม Mera จะติดต่อกลับทาง LINE</span>';
      else if (x.state === 'refunded') h += '<span class="mc-rwarn">คืนเงินแล้ว</span>';
      else if (x.state === 'preparing') h += '<span class="mc-sub" style="font-size:13px">รอแบรนด์จัดส่ง</span>';
      else if (S.issueFor === (x.brand || '*')) {
        h += '<textarea id="mc-issue" maxlength="300" placeholder="เล่าปัญหาสั้นๆ เช่น ได้ของไม่ครบ / สินค้าชำรุด / ผิดสีหรือไซซ์">' + esc(S.issueText || '') + '</textarea>' +
          '<button class="mc-btn" data-a="issueSend" data-b="' + b + '"' + (S.rcvBusy ? ' disabled' : '') + '>' + (S.rcvBusy ? 'กำลังส่ง…' : 'ส่งเรื่องให้ทีม Mera') + '</button>' +
          '<button class="mc-btn2" data-a="issueCancel">ยกเลิก</button>';
      } else {
        h += '<button class="mc-btn" data-a="recv" data-b="' + b + '"' + (S.rcvBusy ? ' disabled' : '') + '>' + (S.rcvBusy === (x.brand || '*') ? 'กำลังบันทึก…' : 'ได้รับของแล้ว') + '</button>' +
          '<button class="mc-btn2" data-a="issueOpen" data-b="' + b + '">มีปัญหากับสินค้า</button>';
      }
      h += '</div>';
    });
    return h + errBox(S.rcvErr) + '</section>';
  }
  function receiptAct(kind, brand) {
    if (S.rcvBusy || !S.order) return;
    var note = '';
    if (kind === 'reportIssue') { var ta = $('#mc-issue'); note = ta ? ta.value.trim() : ''; S.issueText = note; if (!note) { S.rcvErr = 'เล่าปัญหาสั้นๆ ก่อนส่งนะคะ'; return render(); } }
    S.rcvBusy = brand || '*'; S.rcvErr = ''; render();
    var img = S.order.img;
    api(kind, { id: S.order.id, brand: brand || '', note: note }).then(function (j) {
      S.rcvBusy = ''; S.issueFor = ''; S.issueText = '';
      S.order = j.order; S.order.img = img; S.orders = null; render();
    }).catch(function (err) { S.rcvBusy = ''; S.rcvErr = err.message; render(); });
  }
  function viewOrders() {
    var h = header('ออเดอร์ของฉัน', '', false) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '</div>';
    if (!S.orders) return h + loading() + '</div>';
    if (!S.orders.length) return h + '<p class="mc-empty">ยังไม่มีออเดอร์</p></div>';
    var isFin = function (o) { return o.received || o.status === 'Cancelled' || (o.status === 'Shipped' && !(o.receipt || []).length); };
    var act = S.orders.filter(function (o) { return !isFin(o); });
    var fin = S.orders.filter(isFin);
    var item = function (o) {
      if (o.received) o = Object.assign({}, o, { status: 'Received' });
      var cls = { Received: 'off', Confirmed: 'ok', 'Partially Shipped': 'ok', Shipped: 'off', Cancelled: 'off', 'Slip Rejected': 'bad' }[o.status] || '';
      var pill = { 'Pending Slip': 'กำลังตรวจสลิป', Confirmed: 'ยืนยันแล้ว', 'Partially Shipped': 'จัดส่งบางส่วน', Shipped: 'จัดส่งแล้ว', 'Slip Rejected': 'สลิปไม่ผ่าน', Cancelled: 'ยกเลิก', Error: 'กำลังตรวจสอบ', Received: 'ได้รับแล้ว' }[o.status] || o.status;
      return '<button class="mc-oi" data-a="openOrder" data-id="' + esc(o.id) + '">' + (o.img ? '<img src="' + esc(o.img) + '" alt="" style="width:64px;height:64px;border-radius:12px;object-fit:cover">' : '<span class="mc-ph">' + esc((o.brand || '').slice(0, 10)) + '</span>') +
        '<span class="mc-col"><span class="mc-top"><span>' + esc(o.id) + '</span><span class="mc-pill ' + cls + '">' + esc(pill) + '</span></span>' +
        '<span class="mc-name" style="font-size:14px">' + esc(o.name) + '</span><span class="mc-sub" style="font-size:12px">' + baht(o.total) +
        (o.tracking ? ' · เลขพัสดุ ' + esc(o.tracking) : o.eta && o.status !== 'Cancelled' ? ' · คาดว่าได้รับ ' + esc(o.eta.label) : '') + '</span></span></button>';
    };
    if (act.length) h += '<span class="mc-sub" style="font-weight:600">กำลังดำเนินการ</span><div class="mc-ol">' + act.map(item).join('') + '</div>';
    if (fin.length) h += '<span class="mc-sub" style="font-weight:600;margin-top:8px">เสร็จสิ้น</span><div class="mc-ol">' + fin.map(item).join('') + '</div>';
    return h + '</div>';
  }

  /* ---------------- events ---------------- */
  function bind() {
    S.root.querySelectorAll('[data-a]').forEach(function (el) { el.addEventListener('click', onAction); });
    var file = $('#mc-file'); if (file) file.addEventListener('change', onSlip);
    var qr = $('#mc-qr'); if (qr && S.config && S.config.payment.promptpayId) drawQr(qr, S.config.payment.promptpayId, S.quote.price.total);
    if (S.view === 'checkout' && ADDR.ready) bindAddr();
  }
  function bindAddr() {
    var pc = $('#mc-postcode'), pv = $('#mc-province'), ds = $('#mc-district'), sd = $('#mc-subdistrict');
    if (!pc || !pv || !ds || !sd) return;   // ฟอร์มยังไม่ขึ้น (กำลังเช็กราคา / มี error) — ห้ามหยุดการเปิดหน้า
    var refresh = function () { readAddr(); render(); };
    pc.addEventListener('input', function () {
      pc.value = pc.value.replace(/\D/g, '').slice(0, 5);
      if (pc.value.length === 5) {
        readAddr();
        var hits = ADDR.byZip(pc.value), a = S.addr;
        if (hits.length) {
          var pick = function (k) { var u = uniq(hits.map(function (x) { return x[k]; })); return u.length === 1 ? u[0] : ''; };
          a.province = pick('province') || a.province; a.district = pick('amphoe') || (ADDR.districts(a.province, a.postcode).indexOf(a.district) >= 0 ? a.district : '');
          a.subdistrict = pick('district') || (ADDR.subdistricts(a.province, a.district, a.postcode).indexOf(a.subdistrict) >= 0 ? a.subdistrict : '');
        }
        render(); var f = hits.length && !S.addr.subdistrict ? $('#mc-subdistrict') : null; if (f) f.focus();
      }
    });
    pv.addEventListener('change', function () { readAddr(); S.addr.district = ''; S.addr.subdistrict = ''; if (S.addr.postcode && !ADDR.byZip(S.addr.postcode).some(function (x) { return x.province === S.addr.province; })) S.addr.postcode = ''; render(); });
    ds.addEventListener('change', function () { readAddr(); S.addr.subdistrict = ''; render(); });
    sd.addEventListener('change', function () {
      readAddr();
      var hit = ADDR.data.find(function (x) { return x.province === S.addr.province && x.amphoe === S.addr.district && x.district === S.addr.subdistrict; });
      if (hit) S.addr.postcode = String(hit.zipcode);
      render();
    });
    void refresh;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }

  function changeCart(sku, delta, remove) {
    readAddr();
    var next = S.items.map(cleanItem), i = next.findIndex(function (x) { return x.sku === sku; });
    if (i < 0) return;
    if (remove) next.splice(i, 1);
    else next[i].qty = Math.max(1, Math.min(5, next[i].qty + delta));
    S.items = next; writeCart(next); S.quote = null; S.loadErr = ''; S.formErr = '';
    if (!next.length) { close(); return; }
    render(); loadQuote();
  }

  function onAction(e) {
    var a = e.currentTarget.getAttribute('data-a');
    if (a === 'close') return close();
    if (a === 'back') return back();
    if (a === 'shopMore') return close();
    if (a === 'cartInc') return changeCart(e.currentTarget.getAttribute('data-sku'), 1, false);
    if (a === 'cartDec') return changeCart(e.currentTarget.getAttribute('data-sku'), -1, false);
    if (a === 'cartRemove') return changeCart(e.currentTarget.getAttribute('data-sku'), 0, true);
    if (a === 'toPay') {
      readAddr(); S.formErr = '';
      if (S.needGate) return openGate();
      var bad = validAddr();
      S.root.querySelectorAll('.mc-f').forEach(function (f) { f.classList.remove('bad'); });
      if (bad.length) {
        bad.forEach(function (b) { var f = $('#mcf-' + b[0]); if (f) f.classList.add('bad'); });
        S.formErr = 'กรุณาตรวจ: ' + bad.map(function (b) { return b[1]; }).join(', ');
        var box = S.root.querySelector('.mc-err'); if (box) box.textContent = S.formErr; else render();
        var first = $('#mc-' + bad[0][0]); if (first) first.focus();
        return;
      }
      S.reupload = false; S.payErr = ''; return go('pay');
    }
    if (a === 'pickSlip') { var f = $('#mc-file'); if (f) f.click(); return; }
    if (a === 'submit') return submit();
    if (a === 'saveQr') return saveQr();
    if (a === 'copy') {
      var btn = e.currentTarget, old = btn.textContent, done = function () { btn.textContent = 'คัดลอกแล้ว ✓'; setTimeout(function () { btn.textContent = old; }, 1500); };
      try { navigator.clipboard.writeText(btn.getAttribute('data-v')).then(done, done); } catch (er) { done(); }
      return;
    }
    if (a === 'gateGo') return S.loggedIn ? go('profile') : lineLogin();
    if (a === 'prof') { var pg = e.currentTarget.getAttribute('data-g'); S.profAns[pg] = e.currentTarget.getAttribute('data-v'); return render(); }
    if (a === 'profPolicy') { S.profPolicy = !S.profPolicy; return render(); }
    if (a === 'profMkt') { S.profMkt = !S.profMkt; return render(); }
    if (a === 'profSave') return saveProfile();
    if (a === 'welcomeGo') { S.stack = []; S.view = ''; S.quote = null; go('checkout'); loadQuote(); return; }
    if (a === 'pref') {
      readAddr();
      var g = e.currentTarget.getAttribute('data-g'), val = e.currentTarget.getAttribute('data-v'), ans = S.prefAns;
      if (g === 'category') { var i = ans.category.indexOf(val); if (i >= 0) ans.category.splice(i, 1); else ans.category.push(val); }
      else ans[g] = ans[g] === val ? '' : val;
      return render();
    }
    if (a === 'copyTrk') { try { navigator.clipboard.writeText(e.currentTarget.getAttribute('data-v') || S.order.tracking); e.currentTarget.textContent = 'คัดลอกแล้ว'; } catch (er) {} return; }
    if (a === 'recv') return receiptAct('confirmReceived', e.currentTarget.getAttribute('data-b'));
    if (a === 'issueOpen') { S.issueFor = e.currentTarget.getAttribute('data-b') || '*'; S.issueText = ''; S.rcvErr = ''; render(); var ta = $('#mc-issue'); if (ta) ta.focus(); return; }
    if (a === 'issueCancel') { S.issueFor = ''; S.rcvErr = ''; return render(); }
    if (a === 'issueSend') return receiptAct('reportIssue', e.currentTarget.getAttribute('data-b'));
    if (a === 'orders') return MeraCheckout.openOrders(true);
    if (a === 'openOrder') return MeraCheckout.openOrder(e.currentTarget.getAttribute('data-id'), true);
    if (a === 'reupload') {
      S.reupload = true; S.slip = null; S.payErr = '';
      S.quote = { price: { total: S.order.total } };
      return go('pay');
    }
  }

  function onSlip(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    S.payErr = '';
    compress(file).then(function (s) { S.slip = s; render(); }).catch(function () { S.payErr = 'อ่านรูปนี้ไม่ได้ ลองเลือกรูปใหม่ (JPG/PNG)'; render(); });
  }
  function compress(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var max = 1600, w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, max / Math.max(w, h));
        var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        var data = c.toDataURL('image/jpeg', 0.85);
        URL.revokeObjectURL(url);
        resolve({ name: file.name || 'slip.jpg', mime: 'image/jpeg', data: data.split(',')[1], preview: data });
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        if (file.size > 4.5 * 1024 * 1024) return reject(new Error('big'));
        var r = new FileReader();
        r.onload = function () { resolve({ name: file.name, mime: file.type || 'image/jpeg', data: String(r.result).split(',')[1], preview: String(r.result) }); };
        r.onerror = reject; r.readAsDataURL(file);
      };
      img.src = url;
    });
  }

  function submit() {
    if (!S.slip || S.busy) return;
    S.busy = true; S.payErr = ''; render();
    var slip = { mime: S.slip.mime, data: S.slip.data };
    var p = S.reupload
      ? api('reuploadSlip', { id: S.order.id, slip: slip })
      : S.cartMode
        ? api('createCartOrder', {
          items: S.items.map(function (x) { return { sku: x.sku, qty: x.qty }; }), expectedTotal: S.quote.price.total, clientRef: S.clientRef,
          customer: S.addr, saveAddress: S.saveAddr !== false, slip: slip, prefs: prefsPayload(),
        })
        : api('createOrder', {
          sku: S.item.sku, qty: S.quote.price.qty, expectedTotal: S.quote.price.total, clientRef: S.clientRef,
          customer: S.addr, saveAddress: S.saveAddr !== false, slip: slip, prefs: prefsPayload(),
        });
    p.then(function (j) {
      S.busy = false; S.slip = null;
      if (S.prefMissing && S.prefAns) S.prefMissing = S.prefMissing.filter(function (k) { return k === 'category' ? !S.prefAns.category.length : !S.prefAns[k]; });
      if (S.cartMode) {
        var local = {}; S.items.forEach(function (x) { local[x.sku] = x; });
        S.orderedItems = (S.quote.items || []).map(function (x) { return Object.assign({}, x, { img: (local[x.sku] || {}).img || x.img }); });
        writeCart([]);
      } else S.orderedItems = [];
      S.order = Object.assign({ img: S.cartMode ? ((S.orderedItems[0] || {}).img || '') : (S.item && S.item.img) || (S.order && S.order.img) }, j.order);
      remember(S.order);
      go('done');
      try { document.dispatchEvent(new CustomEvent('mera:order', { detail: S.order })); } catch (er) {}
    }).catch(function (err) {
      S.busy = false; S.payErr = err.message;
      if (err.code === 'PROFILE_REQUIRED') { S.needGate = true; return checkMember().then(function () { openGate(); }); }
      if (err.code === 'PRICE_CHANGED' || err.code === 'OUT_OF_STOCK' || err.code === 'CART_PROBLEM' || err.code === 'BAD_ADDRESS') {
        S.formErr = err.message; S.quote = null; go('checkout', true); S.stack = []; loadQuote();
      } else render();
    });
  }

  /* รูปสินค้าของออเดอร์ (เก็บในเครื่อง เพราะชีตไม่มีรูป) */
  function remember(o) { try { var m = JSON.parse(localStorage.getItem('mc_img') || '{}'); if (o.img) { m[o.id] = o.img; localStorage.setItem('mc_img', JSON.stringify(m)); } } catch (e) {} }
  function imgOf(id) { try { return JSON.parse(localStorage.getItem('mc_img') || '{}')[id] || ''; } catch (e) { return ''; } }

  /* ---------------- data loading ---------------- */
  function loadQuote() {
    S.loadErr = '';
    var req = S.cartMode
      ? api('quoteCart', { items: S.items.map(function (x) { return { sku: x.sku, qty: x.qty }; }) })
      : api('quote', { sku: S.item.sku, qty: S.item.qty || 1 });
    return req.then(function (q) {
      S.quote = q;
      if (!S.cartMode && !S.item.img && q.product && q.product.img) S.item.img = q.product.img;   // เว็บไม่ได้ส่งรูปมา → ใช้รูปจาก Product Database
      if (S.view === 'checkout') render();
    })
      .catch(function (err) { S.loadErr = err.message; if (S.view === 'checkout') render(); });
  }
  function loadConfig() {
    if (S.config) return Promise.resolve(S.config);
    return api('config').then(function (c) { S.config = c; return c; }).catch(function () { S.config = { payment: {} }; return S.config; });
  }
  function loadProfile() {
    if (S.addrLoaded) return Promise.resolve();
    return api('profile').then(function (j) {
      S.addrLoaded = true; S.profileName = j.name || '';
      readAddr();   // เก็บสิ่งที่ลูกค้าพิมพ์ไปแล้ว ไม่เขียนทับ
      var cur = S.addr || {}, src = j.address || { name: j.name || '' }, filled = false;
      Object.keys(src).forEach(function (k) { if (!cur[k] && src[k]) { cur[k] = String(src[k]); filled = true; } });
      S.addr = cur; if (j.address && filled) S.addrPrefilled = true;
      var pf = j.prefs || {};
      S.prefOptions = j.prefOptions || null;
      S.prefMissing = ['category', 'budget', 'size'].filter(function (k) { return !pf[k]; });
      if (S.view === 'checkout' && S.quote) render();
    }).catch(function (err) {
      if (/LINE/.test(err.message)) { S.loadErr = err.message; if (S.view === 'checkout') render(); }
    });
  }

  /* ---------------- Thai address database ---------------- */
  var ADDR = {
    ready: false, data: [], loading: null,
    load: function () {
      if (ADDR.loading) return ADDR.loading;
      ADDR.loading = fetch(CFG.addressDb).then(function (r) { return r.json(); }).then(function (rows) {
        ADDR.data = rows.map(function (x) { return { district: x.district, amphoe: x.amphoe, province: x.province, zipcode: String(x.zipcode) }; });
        ADDR.ready = ADDR.data.length > 100;
        if (S.view === 'checkout' && S.quote) { readAddr(); render(); }
      }).catch(function (e) { console.warn('mera-checkout: โหลดฐานข้อมูลที่อยู่ไม่ได้ ใช้ช่องพิมพ์แทน', e); });
      return ADDR.loading;
    },
    byZip: function (z) { return ADDR.data.filter(function (x) { return x.zipcode === z; }); },
    provinces: function (z) {
      var all = uniq(ADDR.data.map(function (x) { return x.province; })).sort(thSort);
      var bkk = 'กรุงเทพมหานคร'; all = [bkk].concat(all.filter(function (p) { return p !== bkk; }));
      void z; return all;
    },
    districts: function (p, z) {
      if (!p) return [];
      var rows = ADDR.data.filter(function (x) { return x.province === p; });
      var byZ = /^\d{5}$/.test(z || '') ? rows.filter(function (x) { return x.zipcode === z; }) : [];
      return uniq((byZ.length ? byZ : rows).map(function (x) { return x.amphoe; })).sort(thSort);
    },
    subdistricts: function (p, d, z) {
      if (!p || !d) return [];
      var rows = ADDR.data.filter(function (x) { return x.province === p && x.amphoe === d; });
      var byZ = /^\d{5}$/.test(z || '') ? rows.filter(function (x) { return x.zipcode === z; }) : [];
      return uniq((byZ.length ? byZ : rows).map(function (x) { return x.district; })).sort(thSort);
    },
  };
  function thSort(a, b) { return a.localeCompare(b, 'th'); }

  /* ---------------- PromptPay QR (EMVCo) ---------------- */
  function promptpayPayload(id, amount) {
    var f = function (tag, v) { return tag + String(v.length).padStart(2, '0') + v; };
    var t = String(id).replace(/\D/g, ''), acc;
    if (t.length >= 15) acc = f('03', t);
    else if (t.length >= 13) acc = f('02', t);
    else acc = f('01', ('0000000000000' + t.replace(/^0/, '66')).slice(-13));
    var s = f('00', '01') + f('01', amount ? '12' : '11') + f('29', f('00', 'A000000677010111') + acc) + f('53', '764') +
      (amount ? f('54', Number(amount).toFixed(2)) : '') + f('58', 'TH') + '6304';
    return s + crc16(s);
  }
  function crc16(s) {
    var crc = 0xFFFF;
    for (var i = 0; i < s.length; i++) { crc ^= s.charCodeAt(i) << 8; for (var j = 0; j < 8; j++) crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1; crc &= 0xFFFF; }
    return crc.toString(16).toUpperCase().padStart(4, '0');
  }
  function drawQr(el, id, amount) {
    var m = QR.make(promptpayPayload(id, amount)), n = m.length, q = 4, scale = 8;
    var c = document.createElement('canvas'); c.width = c.height = (n + q * 2) * scale;
    var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#000';
    for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (m[y][x]) g.fillRect((x + q) * scale, (y + q) * scale, scale, scale);
    el.innerHTML = ''; el.appendChild(c); S.qrCanvas = c;
  }
  function prefsPayload() {
    if (!CFG.askPrefs) return null;
    var a = S.prefAns || {}, o = {};
    if (a.category && a.category.length) o.category = a.category.join(', ');
    if (a.budget) o.budget = a.budget;
    if (a.size) o.size = a.size;
    return Object.keys(o).length ? o : null;
  }
  function saveQr() {
    var name = 'mera-qr-' + S.quote.price.total + '.png';
    var dl = function (href) { var a = document.createElement('a'); a.download = name; a.href = href; document.body.appendChild(a); a.click(); a.remove(); };
    if (S.qrCanvas) return dl(S.qrCanvas.toDataURL('image/png'));
    var pic = $('#mc-qrpic'); if (!pic) return;
    // รูป QR จากลิงก์ภายนอก: ลองดาวน์โหลด ถ้าเว็บต้นทางไม่ยอม → เปิดรูปให้กดค้างบันทึก
    fetch(pic.src, { mode: 'cors' }).then(function (r) { return r.blob(); })
      .then(function (b) { var u = URL.createObjectURL(b); dl(u); setTimeout(function () { URL.revokeObjectURL(u); }, 4000); })
      .catch(function () { window.open(pic.src, '_blank'); });
  }

  /* QR Code generator (byte mode, ECC M, version 1–10) */
  var QR = (function () {
    var EC = [0, [10, 1, 16, 0, 0], [16, 1, 28, 0, 0], [26, 1, 44, 0, 0], [18, 2, 32, 0, 0], [24, 2, 43, 0, 0], [16, 4, 27, 0, 0], [18, 4, 31, 0, 0], [22, 2, 38, 2, 39], [22, 3, 36, 2, 37], [26, 4, 43, 1, 44]];
    var ALIGN = [0, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
    function mul(x, y) { var z = 0; for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 0xFF; }
    function divisor(deg) { var r = []; for (var i = 0; i < deg - 1; i++) r.push(0); r.push(1); var root = 1; for (i = 0; i < deg; i++) { for (var j = 0; j < r.length; j++) { r[j] = mul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = mul(root, 2); } return r; }
    function remainder(data, div) { var r = div.map(function () { return 0; }); data.forEach(function (b) { var f = b ^ r.shift(); r.push(0); div.forEach(function (c, i) { r[i] ^= mul(c, f); }); }); return r; }
    function utf8(s) { var out = [], b = unescape(encodeURIComponent(s)); for (var i = 0; i < b.length; i++) out.push(b.charCodeAt(i)); return out; }
    function make(text) {
      var data = utf8(text), ver, e;
      for (ver = 1; ver <= 10; ver++) { e = EC[ver]; var cap = e[1] * e[2] + e[3] * e[4]; if (4 + (ver < 10 ? 8 : 16) + data.length * 8 <= cap * 8) break; }
      if (ver > 10) throw new Error('QR data too long');
      var cap8 = (e[1] * e[2] + e[3] * e[4]), bits = [];
      var push = function (v, n) { for (var i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); };
      push(4, 4); push(data.length, ver < 10 ? 8 : 16); data.forEach(function (b) { push(b, 8); });
      push(0, Math.min(4, cap8 * 8 - bits.length)); while (bits.length % 8) bits.push(0);
      var cw = []; for (var i = 0; i < bits.length; i += 8) cw.push(parseInt(bits.slice(i, i + 8).join(''), 2));
      for (var pad = 0xEC; cw.length < cap8; pad ^= 0xEC ^ 0x11) cw.push(pad);
      var blocks = [], ecb = [], k = 0, div = divisor(e[0]);
      for (i = 0; i < e[1] + e[3]; i++) { var len = i < e[1] ? e[2] : e[4]; var b = cw.slice(k, k + len); k += len; blocks.push(b); ecb.push(remainder(b, div)); }
      var all = [], maxLen = Math.max(e[2], e[4]);
      for (i = 0; i < maxLen; i++) blocks.forEach(function (b) { if (i < b.length) all.push(b[i]); });
      for (i = 0; i < e[0]; i++) ecb.forEach(function (b) { all.push(b[i]); });

      var n = ver * 4 + 17, mod = [], fn = [];
      for (i = 0; i < n; i++) { mod.push(new Array(n).fill(false)); fn.push(new Array(n).fill(false)); }
      var set = function (x, y, d) { mod[y][x] = !!d; fn[y][x] = true; };
      for (i = 0; i < n; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
      [[3, 3], [n - 4, 3], [3, n - 4]].forEach(function (c) {
        for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
          var x = c[0] + dx, y = c[1] + dy; if (x < 0 || y < 0 || x >= n || y >= n) continue;
          var d = Math.max(Math.abs(dx), Math.abs(dy)); set(x, y, d !== 2 && d !== 4);
        }
      });
      var al = ALIGN[ver];
      al.forEach(function (ax, ii) { al.forEach(function (ay, jj) {
        if ((ii === 0 && jj === 0) || (ii === 0 && jj === al.length - 1) || (ii === al.length - 1 && jj === 0)) return;
        for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      }); });
      var drawFormat = function (mask) {
        var d = (0 << 3) | mask, rem = d; for (var t = 0; t < 10; t++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        var fb = ((d << 10) | rem) ^ 0x5412, bit = function (t) { return (fb >>> t) & 1; };
        for (t = 0; t <= 5; t++) set(8, t, bit(t));
        set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8));
        for (t = 9; t < 15; t++) set(14 - t, 8, bit(t));
        for (t = 0; t < 8; t++) set(n - 1 - t, 8, bit(t));
        for (t = 8; t < 15; t++) set(8, n - 15 + t, bit(t));
        set(8, n - 8, true);
      };
      drawFormat(0);
      if (ver >= 7) {
        var rem = ver; for (i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
        var vb = (ver << 12) | rem;
        for (i = 0; i < 18; i++) { var bt = (vb >>> i) & 1, a = n - 11 + i % 3, bb = Math.floor(i / 3); set(a, bb, bt); set(bb, a, bt); }
      }
      var bi = 0;
      for (var right = n - 1; right >= 1; right -= 2) {
        if (right === 6) right = 5;
        for (var vert = 0; vert < n; vert++) for (var j = 0; j < 2; j++) {
          var x = right - j, up = ((right + 1) & 2) === 0, y = up ? n - 1 - vert : vert;
          if (!fn[y][x] && bi < all.length * 8) { mod[y][x] = ((all[bi >>> 3] >>> (7 - (bi & 7))) & 1) === 1; bi++; }
        }
      }
      var MASK = [function (x, y) { return (x + y) % 2 === 0; }, function (x, y) { return y % 2 === 0; }, function (x) { return x % 3 === 0; },
        function (x, y) { return (x + y) % 3 === 0; }, function (x, y) { return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; },
        function (x, y) { return x * y % 2 + x * y % 3 === 0; }, function (x, y) { return (x * y % 2 + x * y % 3) % 2 === 0; },
        function (x, y) { return ((x + y) % 2 + x * y % 3) % 2 === 0; }];
      var apply = function (mk) { for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (!fn[y][x] && MASK[mk](x, y)) mod[y][x] = !mod[y][x]; };
      var penalty = function () {
        var p = 0, dark = 0, x, y, run, prev;
        for (y = 0; y < n; y++) { run = 0; prev = null; for (x = 0; x < n; x++) { if (mod[y][x] === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else { run = 1; prev = mod[y][x]; } if (mod[y][x]) dark++; } }
        for (x = 0; x < n; x++) { run = 0; prev = null; for (y = 0; y < n; y++) { if (mod[y][x] === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else { run = 1; prev = mod[y][x]; } } }
        for (y = 0; y < n - 1; y++) for (x = 0; x < n - 1; x++) { var c = mod[y][x]; if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3; }
        // ลายคล้าย finder (1:1:3:1:1 + ขาว 4) ทำให้เครื่องสแกนสับสน
        var at = function (yy, xx) { return yy >= 0 && xx >= 0 && yy < n && xx < n && mod[yy][xx]; };
        var F = [1, 0, 1, 1, 1, 0, 1], hit = function (get) {
          for (var s = -4; s < n; s++) {
            var okF = true, k2;
            for (k2 = 0; k2 < 7 && okF; k2++) if (!!get(s + k2) !== !!F[k2]) okF = false;
            if (!okF) continue;
            var before = true, after = true;
            for (k2 = 1; k2 <= 4; k2++) { if (get(s - k2)) before = false; if (get(s + 6 + k2)) after = false; }
            if (before || after) p += 40;
          }
        };
        for (y = 0; y < n; y++) hit(function (xx) { return at(y, xx); });
        for (x = 0; x < n; x++) hit(function (yy) { return at(yy, x); });
        return p + Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
      };
      var best = 0, bestP = Infinity;
      for (var mk = 0; mk < 8; mk++) { apply(mk); drawFormat(mk); var pp = penalty(); if (pp < bestP) { bestP = pp; best = mk; } apply(mk); }
      apply(best); drawFormat(best);
      return mod;
    }
    return { make: make };
  })();

  /* ---------------- public API ---------------- */
  function startCheckout(items, cartMode) {
    show();
    S.cartMode = !!cartMode; S.items = (items || []).map(cleanItem).filter(function (x) { return x.sku; });
    S.item = S.cartMode ? null : S.items[0]; S.quote = null; S.loadErr = ''; S.formErr = ''; S.slip = null; S.busy = false;
    S.clientRef = uuid(); S.stack = []; S.orderedItems = [];
    if (!S.prefAns) S.prefAns = { category: [], budget: '', size: '' };
    S.view = ''; go('checkout');
    loadQuote(); loadConfig(); loadProfile(); ADDR.load();
    var ref = S.clientRef;
    checkMember().then(function (okToBuy) {
      if (ref !== S.clientRef || S.ov.hidden) return;        // ปิดไปแล้ว / เปิดรอบใหม่
      if (!okToBuy && S.view === 'checkout') openGate();
    });
  }
  var MeraCheckout = {
    open: function (item) {
      if (!item || !item.sku) throw new Error('MeraCheckout.open ต้องมี sku');
      startCheckout([item], false);
    },
    add: function (item) {
      if (!item || !item.sku) throw new Error('MeraCheckout.add ต้องมี sku');
      var items = mergeCartItem(item);
      try { document.dispatchEvent(new CustomEvent('mera:cart', { detail: { items: items, count: items.reduce(function (n, x) { return n + x.qty; }, 0) } })); } catch (e) {}
      startCheckout(items, true);
    },
    openCart: function (items) {
      if (Array.isArray(items)) writeCart(items);
      var cart = Array.isArray(items) ? items.map(cleanItem).filter(function (x) { return x.sku; }) : readCart();
      if (!cart.length) return;
      startCheckout(cart, true);
    },
    cartCount: function () {
      return readCart().reduce(function (n, x) { return n + x.qty; }, 0);
    },
    clearCart: function () {
      writeCart([]);
    },
    openOrders: function (fromInside) {
      show(); if (!fromInside) S.stack = [];
      S.orders = null; S.loadErr = ''; S.view = fromInside ? S.view : ''; go('orders');
      api('myOrders').then(function (j) { S.orders = j.orders.map(function (o) { o.img = imgOf(o.id); return o; }); if (S.view === 'orders') render(); })
        .catch(function (err) { S.loadErr = err.message; if (S.view === 'orders') render(); });
    },
    openOrder: function (id, fromInside) {
      show(); if (!fromInside) S.stack = [];
      S.order = null; S.loadErr = ''; S.issueFor = ''; S.rcvErr = ''; S.rcvBusy = ''; S.view = fromInside ? S.view : ''; go('order');
      loadConfig();
      api('order', { id: id }).then(function (j) { S.order = j.order; S.order.img = imgOf(j.order.id); if (S.view === 'order') render(); })
        .catch(function (err) { S.loadErr = err.message; if (S.view === 'order') render(); });
    },
    close: close,
    _qr: function (t) { return QR.make(t); }, _promptpay: promptpayPayload,
  };
  window.MeraCheckout = MeraCheckout;
  mount(); updateCartFab();

  // ลิงก์จากการ์ด LINE: ?order=MO-0001 → เปิดหน้าสถานะ (รอ LIFF พร้อมก่อน)
  function resumeAfterLogin() {
    var raw = null;
    try { raw = sessionStorage.getItem('mc_resume'); sessionStorage.removeItem('mc_resume'); } catch (e) {}
    if (!raw) return false;
    var r; try { r = JSON.parse(raw); } catch (e) { return false; }
    if (!r || !r.items || !r.items.length) return false;
    var tries = 0;
    (function wait() {
      if (CFG.testUserId || CFG.getIdToken() || tries++ > 40) return startCheckout(r.items, !!r.cart);
      setTimeout(wait, 250);
    })();
    return true;
  }
  function autoOpen() {
    if (resumeAfterLogin()) return;
    var m = /[?&]order=([A-Z]{2}-\d+)/.exec(location.search + '&' + (location.hash || '').replace(/^#/, ''));
    if (!m) return;
    var tries = 0;
    (function wait() {
      var ready = CFG.testUserId || CFG.getIdToken();
      if (ready || tries++ > 40) return MeraCheckout.openOrder(m[1]);
      setTimeout(wait, 250);
    })();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', autoOpen); else autoOpen();
  try { document.dispatchEvent(new CustomEvent('mera:checkout-ready')); } catch (e) {}
})();
