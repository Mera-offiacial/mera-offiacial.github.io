/* Mera Admin — แบนเนอร์หน้าแรก · ข้อความบนหน้าเว็บ · รูปสินค้าและโลโก้แบรนด์ (หน้าตาตาม Prototype v2 ฝั่งแอดมิน) */
(function () {
  'use strict';
  var CFG = window.MERA_ADMIN || {};
  var API = CFG.api, CAT_API = CFG.catalogApi;
  var esc = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var SPEC = { top: { w: 1200, h: 625, th: 'โปสเตอร์ด้านบน (เลื่อนได้หลายรูป)', note: '1200 × 625 px' }, mid: { w: 1200, h: 580, th: 'Mid month deal (รูปเดียว)', note: '1200 × 580 px' } };
  var A = { page: 'banners', tview: 'visual', tmode: 'edit', tlang: 'th', texts: null, tEdit: {}, tq: '', token: '', by: '', banners: [], drafts: {}, cat: null, err: '', msg: '', busy: '', sheetUrl: '', notAdmin: null, liffId: '', img: null, idraft: {}, ibrand: '' };
  try { var t = JSON.parse(sessionStorage.getItem('mera-adm') || 'null'); if (t && t.exp > Date.now()) { A.token = t.token; A.by = t.by; } } catch (e) {}

  function post(action, extra) {
    return fetch(API, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(Object.assign({ action: action, token: A.token }, extra || {})) })
      .then(function (r) { return r.text(); })
      .then(function (t) { var j; try { j = JSON.parse(t); } catch (e) { throw new Error('หลังบ้านตอบกลับไม่ถูกต้อง · ตรวจว่า Deploy เวอร์ชันใหม่แล้ว'); } return j; })
      .then(function (j) {
        if (j && j.code === 'ADMIN_AUTH' && action !== 'adminAuth') { logout('เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'); throw new Error(j.error); }
        if (j && j.error === 'ไม่รู้จักคำสั่งนี้') throw new Error('หลังบ้านยังไม่มีระบบแอดมิน · เพิ่มไฟล์ Web_Admin.gs แล้ว Deploy เวอร์ชันใหม่');
        return j;
      });
  }
  function logout(msg) { A.token = ''; A.banners = []; A.err = msg || ''; try { sessionStorage.removeItem('mera-adm'); } catch (e) {} render(); }
  function saveSession(j) { A.token = j.token; A.by = j.by; try { sessionStorage.setItem('mera-adm', JSON.stringify({ token: j.token, by: j.by, exp: Date.now() + (j.ttl || 21600) * 1000 - 60000 })); } catch (e) {} }

  /* ---------- ข้อมูลสินค้า (ใช้ทำตัวเลือกลิงก์) ---------- */
  function loadCatalog() {
    try { var c = JSON.parse(localStorage.getItem('mera-catalog-live-v1') || 'null'); if (c) useCat(c); } catch (e) {}
    if (!CAT_API) return;
    fetch(CAT_API + '?t=' + Date.now()).then(function (r) { return r.json(); }).then(function (d) { useCat(d); render(); }).catch(function () {});
  }
  function useCat(d) {
    if (!d || !Array.isArray(d.products)) return;
    var hidden = ['manitui'];
    var products = d.products.filter(function (p) { return p.variants && p.variants.length && hidden.indexOf(String(p.brand).trim().toLowerCase()) < 0; });
    var brands = {}; products.forEach(function (p) { brands[p.brand] = (d.brands || []).filter(function (b) { return b.name === p.brand; }).map(function (b) { return b.display; })[0] || p.brand; });
    A.full = { products: products.map(function (p) { return { brand: p.brand, name: p.name, images: p.images || [], formImages: p.formImages || [], colorImages: p.colorImages || {} }; }),
      brands: Object.keys(brands).map(function (k) { var b = (d.brands || []).filter(function (x) { return x.name === k; })[0] || {}; return { name: k, display: brands[k], logo: b.logo || '' }; }) };
    A.cat = { brands: brands, products: products.map(function (p) { return { sku: p.variants[0].sku, name: p.name, brand: brands[p.brand] }; }), deals: (d.deals || []).map(function (x) { return x.code; }).filter(Boolean) };
    if (d.config && d.config.liffId) A.liffId = d.config.liffId;
  }

  /* ---------- เข้าสู่ระบบ ---------- */
  function loginPassword(pw) {
    A.busy = 'login'; A.err = ''; render();
    post('adminAuth', { password: pw }).then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error || 'เข้าสู่ระบบไม่สำเร็จ'; return render(); }
      saveSession(j); loadBanners();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function loadLiff() {
    if (window.liff) return Promise.resolve(window.liff);
    return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = 'https://static.line-scdn.net/liff/edge/2/sdk.js'; s.onload = function () { res(window.liff); }; s.onerror = function () { rej(new Error('โหลด LINE ไม่สำเร็จ')); }; document.head.appendChild(s); });
  }
  function loginLine(auto) {
    if (!A.liffId) { if (!auto) { A.err = 'ยังไม่พบ LIFF ID (เปิดหน้า Catalog ก่อน 1 ครั้ง)'; render(); } return; }
    if (!auto) { A.busy = 'line'; A.err = ''; render(); }
    loadLiff().then(function (liff) { return liff.init({ liffId: A.liffId }).then(function () { return liff; }); }).then(function (liff) {
      if (!liff.isLoggedIn()) { if (auto && !(liff.isInClient && liff.isInClient())) { A.busy = ''; return render(); } return liff.login({ redirectUri: location.href.split('#')[0] }); }
      return post('adminAuth', { idToken: liff.getIDToken() }).then(function (j) {
        A.busy = '';
        if (j.code === 'NOT_ADMIN') { A.notAdmin = { userId: j.userId, name: j.name }; return render(); }
        if (!j.ok) { A.err = j.error || 'เข้าสู่ระบบไม่สำเร็จ'; return render(); }
        saveSession(j); loadBanners();
      });
    }).catch(function (e) { A.busy = ''; if (!auto) A.err = e.message; render(); });
  }

  /* ---------- แบนเนอร์ ---------- */
  function loadBanners() {
    A.busy = 'load'; render();
    post('adminBanners').then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; return render(); }
      A.banners = j.banners; A.sheetUrl = j.sheetUrl || ''; A.drafts = {}; render();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function rowOf(id) { return A.drafts[id] || A.banners.filter(function (b) { return b.id === id; })[0]; }
  function edit(id) { if (!A.drafts[id]) A.drafts[id] = Object.assign({}, rowOf(id)); A.drafts[id]._dirty = true; return A.drafts[id]; }
  function saveRow(id) {
    var b = rowOf(id); if (!b) return;
    if (!b.img) { A.err = 'ใส่รูปแบนเนอร์ก่อนบันทึก'; return render(); }
    A.busy = 'save:' + id; A.err = ''; render();
    var body = { id: b.id && b.id.indexOf('new') !== 0 ? b.id : '', slot: b.slot, title: b.title, img: b.img, link: b.link, start: b.start, end: b.end, active: !!b.active, order: b.order };
    post('adminBannerSave', { banner: body }).then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; return render(); }
      delete A.drafts[id]; A.banners = j.banners; A.msg = 'บันทึกแล้ว · หน้า Catalog จะเห็นภายใน 5 นาที'; render(); flash();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function delRow(id) {
    if (id.indexOf('new') === 0) { delete A.drafts[id]; return render(); }
    if (A.confirmDel !== id) { A.confirmDel = id; return render(); }
    A.confirmDel = ''; A.busy = 'del:' + id; render();
    post('adminBannerDelete', { id: id }).then(function (j) { A.busy = ''; if (!j.ok) { A.err = j.error; return render(); } delete A.drafts[id]; A.banners = j.banners; A.msg = 'ลบแล้ว'; render(); flash(); })
      .catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function move(id, dir) {
    var b = rowOf(id), list = listOf(b.slot), i = list.map(function (x) { return x.id; }).indexOf(id), j = i + dir;
    if (j < 0 || j >= list.length) return;
    list.forEach(function (x, k) { var e = edit(x.id); e.order = (k === i ? j : k === j ? i : k) + 1; });
    render();
  }
  function listOf(slot) {
    var saved = A.banners.filter(function (b) { return b.slot === slot; }).map(function (b) { return A.drafts[b.id] || b; });
    var news = Object.keys(A.drafts).filter(function (k) { return k.indexOf('new') === 0 && A.drafts[k].slot === slot; }).map(function (k) { return A.drafts[k]; });
    return saved.concat(news).sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
  }
  function addRow(slot) {
    var id = 'new' + Date.now().toString(36), n = listOf(slot).length;
    A.drafts[id] = { id: id, slot: slot, title: '', img: '', link: 'zone:gb', start: '', end: '', active: true, order: n + 1, _dirty: true };
    render();
  }
  function upload(id, file) {
    if (!file) return;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { A.err = 'รองรับเฉพาะไฟล์ JPG / PNG / WEBP'; return render(); }
    A.busy = 'up:' + id; A.err = ''; render();
    resize(file, 1600).then(function (out) {
      var b = edit(id); b._preview = out.dataUrl; b._ratio = out.ratio; render();
      return post('adminUpload', { data: out.dataUrl, mime: out.mime }).then(function (j) {
        A.busy = '';
        if (!j.ok) { A.err = j.error; return render(); }
        edit(id).img = j.url; A.msg = 'อัปโหลดรูปแล้ว กด "บันทึก" เพื่อใช้บนหน้า Catalog'; render(); flash();
      });
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function resize(file, maxW) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = function () { rej(new Error('อ่านไฟล์ไม่ได้')); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { rej(new Error('ไฟล์รูปเสีย หรือไม่รองรับ')); };
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, maxW / w);
          var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
          var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
          res({ dataUrl: c.toDataURL('image/jpeg', 0.86), mime: 'image/jpeg', ratio: w / h });
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  var flashT; function flash() { clearTimeout(flashT); flashT = setTimeout(function () { A.msg = ''; render(); }, 2600); }

  /* ---------- ตัวเลือกลิงก์ ---------- */
  function linkOptions(cur) {
    var o = [['zone:gb', 'โซน Mera Group Deal'], ['zone:shop', 'โซนซื้อเลย (รายการสินค้า)']];
    if (A.cat) {
      Object.keys(A.cat.brands).forEach(function (k) { o.push(['brand:' + k, 'แบรนด์ · ' + A.cat.brands[k]]); });
      A.cat.deals.forEach(function (c) { o.push(['deal:' + c, 'ดีล · ' + c]); });
      A.cat.products.forEach(function (p) { o.push(['product:' + p.sku, 'สินค้า · ' + p.brand + ' – ' + p.name]); });
    }
    o.push(['url:', 'ลิงก์ภายนอก (URL)…']);
    var isUrl = /^url:/.test(cur || ''), known = o.some(function (x) { return x[0] === cur; });
    if (cur && !known && !isUrl) o.splice(2, 0, [cur, cur + ' (ไม่พบในข้อมูลล่าสุด)']);
    return o.map(function (x) { var sel = isUrl ? x[0] === 'url:' : x[0] === cur; return '<option value="' + esc(x[0]) + '"' + (sel ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join('');
  }

  /* ---------- วาดหน้า ---------- */
  function vLogin() {
    var h = '<div class="lg"><div class="lgc"><img src="' + esc(CFG.logo || '') + '" alt="MERA" style="height:40px;width:auto;align-self:flex-start"><h1>Mera Admin</h1><p class="sub">จัดการแบนเนอร์หน้าแรกของ Catalog</p>';
    if (A.notAdmin) h += '<div class="note"><b>บัญชี LINE นี้ยังไม่อยู่ในรายชื่อแอดมิน</b><br>LINE User ID: <code class="mono">' + esc(A.notAdmin.userId) + '</code><br>ให้ผู้ดูแลเพิ่ม ID นี้ใน Script Properties → <b>ADMIN_LINE_IDS</b> แล้วกลับมาเข้าใหม่<div style="margin-top:8px"><button class="abtn o" data-a="copyId">คัดลอก ID</button></div></div>';
    h += '<form id="pwf" class="f"><label for="pw">รหัสแอดมิน (ใช้บนคอม)</label><input id="pw" type="password" autocomplete="current-password" required minlength="1"><button class="abtn" type="submit"' + (A.busy ? ' disabled' : '') + '>' + (A.busy === 'login' ? 'กำลังเข้า…' : 'เข้าสู่ระบบ') + '</button></form>' +
      '<div class="or"><span>หรือ</span></div><button class="lbtn" data-a="line"' + (A.busy ? ' disabled' : '') + '>' + (A.busy === 'line' ? 'กำลังเชื่อม LINE…' : 'เข้าด้วย LINE (บัญชีในรายชื่อแอดมิน)') + '</button>' +
      (A.err ? '<div class="err" role="alert">' + esc(A.err) + '</div>' : '') + '<a class="small" href="./">← กลับไปหน้า Catalog</a></div></div>';
    return h;
  }
  function vRow(b, i, n) {
    var sp = SPEC[b.slot], id = b.id, busy = A.busy.indexOf(':' + id) > 0;
    var src = b._preview || (/^https:\/\/lh3\.googleusercontent\.com\/d\//.test(b.img || '') ? b.img.replace(/=w\d+$/, '') + '=w800' : (b.img || ''));
    var ratioWarn = b._ratio && Math.abs(b._ratio - sp.w / sp.h) / (sp.w / sp.h) > 0.06;
    var isUrl = /^url:/.test(b.link || '');
    return '<div class="brow' + (b._dirty ? ' dirty' : '') + '">' +
      '<label class="bprev" style="aspect-ratio:' + sp.w + '/' + sp.h + '">' + (src ? '<img src="' + esc(src) + '" alt="">' : '<small>แตะเพื่อใส่รูป<br>' + sp.note + '</small>') +
      (A.busy === 'up:' + id ? '<span class="upl">กำลังอัปโหลด…</span>' : '') + '<input type="file" accept="image/jpeg,image/png,image/webp" hidden data-file="' + esc(id) + '"></label>' +
      '<div class="bf"><div class="grid">' +
      '<label class="f">ชื่อ (ไว้จำ / คำอธิบายรูป)<input class="inp" data-k="title" data-id="' + esc(id) + '" value="' + esc(b.title) + '" maxlength="120"></label>' +
      '<label class="f">กดแล้วไปที่<select class="inp" data-k="link" data-id="' + esc(id) + '">' + linkOptions(b.link) + '</select></label>' +
      (isUrl ? '<label class="f full">ลิงก์ภายนอก (ขึ้นต้นด้วย https://)<input class="inp" data-k="url" data-id="' + esc(id) + '" value="' + esc((b.link || '').slice(4)) + '" placeholder="https://"></label>' : '') +
      '<label class="f">เริ่มแสดง<input class="inp" type="date" data-k="start" data-id="' + esc(id) + '" value="' + esc(b.start) + '"></label>' +
      '<label class="f">หยุดแสดง<input class="inp" type="date" data-k="end" data-id="' + esc(id) + '" value="' + esc(b.end) + '"></label></div>' +
      (ratioWarn ? '<div class="note">สัดส่วนรูปไม่ตรง ' + sp.note + ' ขอบรูปบางส่วนจะถูกตัดบนหน้า Catalog</div>' : '') +
      '<div class="toolbar"><label class="chk"><input type="checkbox" data-k="active" data-id="' + esc(id) + '"' + (b.active ? ' checked' : '') + '> เปิดใช้</label>' +
      '<button class="abtn o" data-a="up" data-id="' + esc(id) + '"' + (i ? '' : ' disabled') + ' aria-label="เลื่อนขึ้น">↑</button><button class="abtn o" data-a="down" data-id="' + esc(id) + '"' + (i < n - 1 ? '' : ' disabled') + ' aria-label="เลื่อนลง">↓</button>' +
      '<span style="flex:1"></span><button class="abtn r" data-a="del" data-id="' + esc(id) + '"' + (busy ? ' disabled' : '') + '>' + (A.confirmDel === id ? 'กดอีกครั้งเพื่อลบ' : 'ลบ') + '</button>' +
      '<button class="abtn" data-a="save" data-id="' + esc(id) + '"' + (busy || !b._dirty ? ' disabled' : '') + '>' + (A.busy === 'save:' + id ? 'กำลังบันทึก…' : b._dirty ? 'บันทึก' : 'บันทึกแล้ว') + '</button></div></div></div>';
  }
  function vBanners() {
    var h = '<div><h1>แบนเนอร์และโปรโมชัน</h1><div class="sub">รูปที่เปิดใช้และอยู่ในช่วงวันที่จะขึ้นหน้าแรกของ Catalog ภายใน 5 นาทีหลังบันทึก · ช่องที่ยังไม่มีรูปจะแสดงเป็นกรอบว่างระบุขนาด' +
      (A.sheetUrl ? ' · <a href="' + esc(A.sheetUrl) + '" target="_blank" rel="noopener">เปิดชีต Mera Admin</a>' : '') + '</div></div>';
    if (A.busy === 'load') return h + '<div class="panel" style="padding:20px">กำลังโหลด…</div>';
    ['top', 'mid'].forEach(function (slot) {
      var list = listOf(slot);
      h += '<div class="panel"><h3>' + SPEC[slot].th + ' <span class="small muted">' + SPEC[slot].note + '</span><button class="abtn o" data-a="add" data-v="' + slot + '">+ เพิ่ม</button></h3><div class="plist">' +
        (list.length ? list.map(function (b, i) { return vRow(b, i, list.length); }).join('') : '<div class="note blue">ยังไม่มีแบนเนอร์ของตำแหน่งนี้ · ตอนนี้หน้า Catalog ใช้<b>แบนเนอร์ชั่วคราว</b>ด้านล่าง กด "+ เพิ่ม" แล้วอัปโหลดรูปจริง แบนเนอร์ชั่วคราวจะหายไปเอง</div><div class="defs">' +
          ((CFG.defaultBanners || {})[slot] || []).map(function (src) { return '<img src="' + esc(src) + '" alt="แบนเนอร์ชั่วคราว" style="aspect-ratio:' + SPEC[slot].w + '/' + SPEC[slot].h + '">'; }).join('') + '</div>') + '</div></div>';
    });
    return h;
  }
  /* ---------- ข้อความบนหน้าเว็บ ---------- */
  var REG = CFG.texts || [];
  function loadTexts() {
    A.busy = 'texts'; render();
    post('adminTexts').then(function (j) { A.busy = ''; if (!j.ok) { A.err = j.error; return render(); } A.texts = j.texts || {}; A.tEdit = {}; render(); })
      .catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function tVal(k, lang) { var e = A.tEdit[k]; if (e && e[lang] !== undefined) return e[lang]; var o = (A.texts || {})[k]; return o ? (o[lang] || '') : ''; }
  function tSet(k, lang, v) { A.tEdit[k] = A.tEdit[k] || {}; A.tEdit[k][lang] = v; }
  function tDirty() { return Object.keys(A.tEdit).filter(function (k) { var o = (A.texts || {})[k] || {}; return tVal(k, 'th') !== (o.th || '') || tVal(k, 'en') !== (o.en || ''); }); }
  function saveTexts() {
    var keys = tDirty(); if (!keys.length) return;
    A.busy = 'tsave'; A.err = ''; render();
    post('adminTextSave', { items: keys.map(function (k) { return { key: k, th: tVal(k, 'th').trim(), en: tVal(k, 'en').trim() }; }) }).then(function (j) {
      A.busy = ''; if (!j.ok) { A.err = j.error; return render(); }
      A.texts = j.texts || {}; A.tEdit = {}; A.msg = 'บันทึกข้อความแล้ว · หน้า Catalog จะเห็นภายใน 5 นาที'; render(); flash();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  // ให้หน้า Catalog ใน iframe (index.html?edit=1) เรียกใช้ตอนกดแก้ข้อความบนหน้า
  var REN = {}; REG.forEach(function (t) { REN[t.k] = t.en; });
  window.meraAdmin = {
    keys: function () { return REG.map(function (t) { return t.k; }); },
    en: function (k) { return REN[k] || ''; },
    texts: function () { return A.texts || {}; },
    mode: function () { return A.tmode; },
    lang: function () { return A.tlang; },
    save: function (k, th, en) {
      return post('adminTextSave', { items: [{ key: k, th: th, en: en }] }).then(function (j) {
        if (!j.ok) throw new Error(j.error || 'บันทึกไม่สำเร็จ');
        A.texts = j.texts || {}; updateTbar(); return A.texts;
      });
    },
  };
  function frameApi() { var f = document.getElementById('tframe'); try { return f && f.contentWindow && f.contentWindow.meraEdit; } catch (e) { return null; } }
  function tbarHTML() {
    var n = Object.keys(A.texts || {}).length;
    return '<div class="seg2" role="group" aria-label="โหมด"><button class="' + (A.tmode === 'edit' ? 'on' : '') + '" data-a="tmode" data-v="edit">✎ กดที่ข้อความเพื่อแก้</button><button class="' + (A.tmode === 'browse' ? 'on' : '') + '" data-a="tmode" data-v="browse">เลื่อนดู / กดไปหน้าอื่น</button></div>' +
      '<div class="seg2" role="group" aria-label="ภาษา"><button class="' + (A.tlang === 'th' ? 'on' : '') + '" data-a="tlang" data-v="th">ไทย</button><button class="' + (A.tlang === 'en' ? 'on' : '') + '" data-a="tlang" data-v="en">English</button></div>' +
      '<span class="small muted">แก้แล้ว ' + n + ' ข้อความ</span><span style="flex:1"></span><button class="abtn o" data-a="tview" data-v="list">ดูเป็นรายการทั้งหมด</button>';
  }
  function updateTbar() { var t = document.getElementById('tbar'); if (t) t.innerHTML = tbarHTML(); }
  function vTextsVisual() {
    return '<div><h1>ข้อความบนหน้าเว็บ</h1><div class="sub">นี่คือหน้า Catalog จริง · กดที่ข้อความที่มีเส้นประเพื่อพิมพ์แก้ตรงนั้น แล้วกด Enter หรือ "บันทึก" · ช่องอีกภาษาแก้ได้ในกล่องที่เด้งขึ้น · ข้อความที่แก้แล้วมีกรอบสีชมพู · สลับเป็น "เลื่อนดู" เพื่อกดเข้าหน้าสินค้า/ดีล/โปรไฟล์ แล้วสลับกลับมาแก้ · ข้อความที่ไม่อยู่บนหน้า (เช่น ตอนสมัครสมาชิก) แก้ได้ใน "ดูเป็นรายการทั้งหมด"</div></div>' +
      '<div class="toolbar" id="tbar">' + tbarHTML() + '</div>' +
      (A.texts === null ? '<div class="panel" style="padding:20px">กำลังโหลด…</div>' : '<div class="phonewrap"><iframe id="tframe" src="index.html?edit=1" title="หน้า Catalog โหมดแก้ข้อความ"></iframe></div>');
  }
  function vTexts() {
    if (A.tview !== 'list') return vTextsVisual();
    var h = '<div><h1>ข้อความบนหน้าเว็บ</h1><div class="toolbar" style="margin-top:6px"><button class="abtn o" data-a="tview" data-v="visual">← แก้บนหน้าเว็บ</button></div><div class="sub">แก้ข้อความบนหน้า Catalog ได้ทั้งภาษาไทยและอังกฤษ · ช่องที่ปล่อยว่างจะใช้ข้อความเดิมของเว็บ (ตัวสีเทา) · ข้อความที่มีตัวเลข/ราคาในประโยค และข้อความในขั้นตอนสั่งซื้อ-ชำระเงิน แก้ที่นี่ไม่ได้ · ข้อความเดียวกันที่อยู่หลายที่จะเปลี่ยนพร้อมกัน</div></div>';
    if (A.texts === null) return h + '<div class="panel" style="padding:20px">กำลังโหลด…</div>';
    var q = A.tq.trim().toLowerCase(), dirty = tDirty();
    h += '<div class="toolbar tbar"><input class="inp" data-t="q" value="' + esc(A.tq) + '" placeholder="ค้นหาข้อความ" style="flex:1;min-width:180px"><span class="small muted">แก้แล้ว ' + Object.keys(A.texts).length + ' ข้อความ</span>' +
      '<button class="abtn" data-a="tsave"' + (dirty.length && !A.busy ? '' : ' disabled') + '>' + (A.busy === 'tsave' ? 'กำลังบันทึก…' : 'บันทึก' + (dirty.length ? ' (' + dirty.length + ')' : '')) + '</button></div>';
    var groups = {};
    REG.forEach(function (t) { if (q && (t.k + ' ' + t.en + ' ' + tVal(t.k, 'th') + ' ' + tVal(t.k, 'en')).toLowerCase().indexOf(q) < 0) return; (groups[t.s] = groups[t.s] || []).push(t); });
    Object.keys(groups).forEach(function (sec) {
      h += '<div class="panel"><h3>' + esc(sec) + ' <span class="small muted">' + groups[sec].length + '</span></h3><div class="plist tl">' + groups[sec].map(function (t, i) {
        var th = tVal(t.k, 'th'), en = tVal(t.k, 'en'), ch = th || en, d = dirty.indexOf(t.k) >= 0, id = sec + '|' + i;
        return '<div class="trow' + (d ? ' dirty' : '') + '"><div class="grid"><label class="f">ไทย' + (ch ? ' <span class="pill">แก้แล้ว</span>' : '') + '<input class="inp" data-t="th" data-key="' + esc(t.k) + '" data-id="' + esc(id) + '" value="' + esc(th) + '" placeholder="' + esc(t.k) + '" maxlength="400"></label>' +
          '<label class="f">English<input class="inp" data-t="en" data-key="' + esc(t.k) + '" data-id="' + esc(id) + 'e" value="' + esc(en) + '" placeholder="' + esc(t.en) + '" maxlength="400"></label></div>' +
          (ch ? '<button class="link2" data-a="treset" data-key="' + esc(t.k) + '">คืนค่าเดิม</button>' : '') + '</div>';
      }).join('') + '</div></div>';
    });
    if (!Object.keys(groups).length) h += '<p class="muted">ไม่พบข้อความ</p>';
    return h;
  }

  /* ---------- รูปสินค้าและโลโก้แบรนด์ ---------- */
  var nrm = function (v) { return String(v || '').trim().toLowerCase().replace(/\s+/g, ' '); };
  var pKey = function (p) { return nrm(p.brand) + '|' + nrm(p.name); };
  var thumb = function (u, w) { return /^https:\/\/lh3\.googleusercontent\.com\/d\//.test(u || '') ? String(u).replace(/=[^\/]*$/, '') + '=w' + (w || 300) : (u || ''); };
  function loadImages() {
    A.busy = 'imgs'; render();
    post('adminImages').then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; A.img = { products: {}, brands: {} }; return render(); }
      A.img = j.images || { products: {}, brands: {} }; A.img.products = A.img.products || {}; A.img.brands = A.img.brands || {};
      A.idraft = {}; if (j.sheetUrl) A.sheetUrl = j.sheetUrl; render();
    }).catch(function (e) { A.busy = ''; A.err = e.message; A.img = { products: {}, brands: {} }; render(); });
  }
  // รายการรูปของแต่ละช่อง: ร่างที่ยังไม่บันทึก > ที่แอดมินบันทึกไว้
  function iSaved(kind, key) { var m = kind === 'b' ? A.img.brands : A.img.products, v = m[key]; return kind === 'b' ? (v ? [v] : []) : (v || []); }
  function iList(kind, key) { var d = A.idraft[kind + ':' + key]; return d ? d : iSaved(kind, key); }
  function iSet(kind, key, list) { A.idraft[kind + ':' + key] = list; }
  function iDirty(kind, key) { var d = A.idraft[kind + ':' + key]; return !!d && JSON.stringify(d) !== JSON.stringify(iSaved(kind, key)); }
  // ครอปเป็นสี่เหลี่ยมจัตุรัสตรงกลาง (การ์ดสินค้าและโลโก้บนหน้า Catalog เป็นสี่เหลี่ยมจัตุรัส)
  function squareJpeg(file, size, fit) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = function () { rej(new Error('อ่านไฟล์ไม่ได้')); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { rej(new Error('ไฟล์รูปเสีย หรือไม่รองรับ')); };
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight, S = Math.min(size, fit ? Math.max(w, h) : Math.min(w, h));
          var c = document.createElement('canvas'); c.width = S; c.height = S;
          var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, S, S);
          if (fit) { var k = S / Math.max(w, h); g.drawImage(img, (S - w * k) / 2, (S - h * k) / 2, w * k, h * k); }
          else { var m = Math.min(w, h); g.drawImage(img, (w - m) / 2, (h - m) / 2, m, m, 0, 0, S, S); }
          res(c.toDataURL('image/jpeg', 0.86));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function iUpload(kind, key, files) {
    files = Array.prototype.slice.call(files || []).filter(function (f) { return /^image\/(jpeg|png|webp)$/.test(f.type); });
    if (!files.length) { A.err = 'รองรับเฉพาะไฟล์ JPG / PNG / WEBP'; return render(); }
    if (kind === 'b') files = files.slice(0, 1);
    var fit = kind === 'b' ? false : !!A.ifit, done = 0;
    A.busy = 'iup:' + kind + ':' + key; A.err = ''; render();
    var chain = Promise.resolve();
    files.forEach(function (f) {
      chain = chain.then(function () { return squareJpeg(f, kind === 'b' ? 600 : 1200, fit); })
        .then(function (data) { return post('adminUpload', { data: data, mime: 'image/jpeg', purpose: kind === 'b' ? 'brand' : 'product' }); })
        .then(function (j) {
          if (!j.ok) throw new Error(j.error || 'อัปโหลดไม่สำเร็จ');
          var list = kind === 'b' ? [j.url] : iList(kind, key).concat([j.url]);
          iSet(kind, key, list); done++; A.busyN = done + '/' + files.length; render();
        });
    });
    chain.then(function () { A.busy = ''; A.busyN = ''; A.msg = 'อัปโหลดแล้ว กด "บันทึก" เพื่อใช้บนหน้า Catalog'; render(); flash(); })
      .catch(function (e) { A.busy = ''; A.busyN = ''; A.err = e.message; render(); });
  }
  function iSave(kind, key) {
    var list = iList(kind, key);
    A.busy = 'isave:' + kind + ':' + key; A.err = ''; render();
    post('adminImageSave', { kind: kind === 'b' ? 'brand' : 'product', key: key, images: list }).then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; return render(); }
      A.img = j.images || A.img; A.img.products = A.img.products || {}; A.img.brands = A.img.brands || {};
      delete A.idraft[kind + ':' + key];
      A.msg = list.length ? 'บันทึกแล้ว · หน้า Catalog จะเห็นภายใน 10 นาที' : 'กลับไปใช้รูปเดิมแล้ว · หน้า Catalog จะเห็นภายใน 10 นาที'; render(); flash();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function iThumbs(kind, key, list, editable) {
    return list.map(function (u, i) {
      return '<div class="ith"><img src="' + esc(thumb(u, kind === 'b' ? 200 : 300)) + '" alt="" loading="lazy">' + (editable ? '<div class="ithb">' +
        (kind === 'p' ? '<button data-a="imv" data-k2="' + esc(kind + ':' + key) + '" data-i="' + i + '" data-v="-1"' + (i ? '' : ' disabled') + ' aria-label="เลื่อนไปซ้าย">←</button><button data-a="imv" data-k2="' + esc(kind + ':' + key) + '" data-i="' + i + '" data-v="1"' + (i < list.length - 1 ? '' : ' disabled') + ' aria-label="เลื่อนไปขวา">→</button>' : '') +
        '<button data-a="idel" data-k2="' + esc(kind + ':' + key) + '" data-i="' + i + '" aria-label="ลบรูปนี้">✕</button></div>' + (i === 0 && kind === 'p' ? '<span class="ic">รูปหน้าปก</span>' : '') : '') + '</div>';
    }).join('');
  }
  function iBlock(kind, key, title, sub, source) {
    var list = iList(kind, key), dirty = iDirty(kind, key), saved = iSaved(kind, key).length > 0, k2 = kind + ':' + key;
    var busyUp = A.busy === 'iup:' + k2, busySave = A.busy === 'isave:' + k2;
    var h = '<div class="irow' + (dirty ? ' dirty' : '') + '"><div class="ihd"><div><b>' + esc(title) + '</b>' + (sub ? '<div class="small muted">' + esc(sub) + '</div>' : '') + '</div>' +
      (saved && !dirty ? '<span class="pill">ใช้รูปจากแอดมิน</span>' : '') + '</div>';
    if (list.length) h += '<div class="ithumbs' + (kind === 'b' ? ' logo' : '') + '">' + iThumbs(kind, key, list, true) + '</div>';
    else if (source.length) h += '<div class="small muted">ตอนนี้หน้า Catalog ใช้รูปจากชีต / ฟอร์ม' + (kind === 'p' ? ' (หรือรูปเดิมที่ฝังในเว็บ)' : '') + '</div><div class="ithumbs src' + (kind === 'b' ? ' logo' : '') + '">' + iThumbs(kind, key, source, false) + '</div>';
    else h += '<div class="small muted">' + (kind === 'b' ? 'ยังไม่มีโลโก้ในชีต · หน้า Catalog ใช้โลโก้เดิมที่ฝังในเว็บ หรือตัวอักษรย่อ' : 'ยังไม่มีรูปในชีต · หน้า Catalog ใช้รูปเดิมที่ฝังในเว็บ หรือรูปสำรอง MERA') + '</div>';
    h += '<div class="toolbar"><label class="abtn o' + (A.busy ? ' dis' : '') + '">' + (busyUp ? 'กำลังอัปโหลด… ' + esc(A.busyN || '') : (kind === 'b' ? (list.length ? 'เปลี่ยนโลโก้' : '+ อัปโหลดโลโก้') : '+ เพิ่มรูป')) +
      '<input type="file" accept="image/jpeg,image/png,image/webp" hidden' + (kind === 'p' ? ' multiple' : '') + ' data-ifile="' + esc(k2) + '"' + (A.busy ? ' disabled' : '') + '></label>' +
      (saved || dirty ? '<button class="link2" data-a="ireset" data-k2="' + esc(k2) + '"' + (A.busy ? ' disabled' : '') + '>' + (dirty && !saved ? 'ยกเลิก' : 'กลับไปใช้รูปเดิม') + '</button>' : '') +
      '<span style="flex:1"></span><button class="abtn" data-a="isave" data-k2="' + esc(k2) + '"' + (dirty && !A.busy ? '' : ' disabled') + '>' + (busySave ? 'กำลังบันทึก…' : dirty ? 'บันทึก' : 'บันทึกแล้ว') + '</button></div></div>';
    return h;
  }
  function vImages() {
    var h = '<div><h1>รูปสินค้าและโลโก้แบรนด์</h1><div class="sub">อัปโหลดรูปจากมือถือหรือคอมได้เลย · ระบบเก็บรูปไว้ใน Google Drive ที่เปิดแชร์แล้ว · รูปที่บันทึกที่นี่จะใช้แทนรูปจากชีตและฟอร์ม ทั้งชุด (รูปแรก = หน้าปก) · หน้า Catalog จะเห็นภายใน 10 นาที · กด "กลับไปใช้รูปเดิม" เพื่อเลิกใช้รูปจากแอดมิน' +
      (A.sheetUrl ? ' · <a href="' + esc(A.sheetUrl) + '" target="_blank" rel="noopener">เปิดชีต Mera Admin</a>' : '') + '</div></div>';
    if (A.img === null || A.busy === 'imgs') return h + '<div class="panel" style="padding:20px">กำลังโหลด…</div>';
    if (!A.full) return h + '<div class="panel" style="padding:20px">กำลังโหลดรายการสินค้า…</div>';
    var brands = A.full.brands.filter(function (b) { return A.full.products.some(function (p) { return p.brand === b.name; }); });
    if (!A.ibrand || !brands.some(function (b) { return b.name === A.ibrand; })) A.ibrand = brands[0] ? brands[0].name : '';
    h += '<div class="toolbar ibar">' + brands.map(function (b) {
      var n = A.full.products.filter(function (p) { return p.brand === b.name && iSaved('p', pKey(p)).length; }).length;
      return '<button class="chip' + (b.name === A.ibrand ? ' on' : '') + '" data-a="ibrand" data-v="' + esc(b.name) + '">' + esc(b.display || b.name) + (n ? ' <small>' + n + '</small>' : '') + '</button>';
    }).join('') + '</div>';
    h += '<label class="chk small"><input type="checkbox" data-a2="ifit"' + (A.ifit ? ' checked' : '') + '> ไม่ครอปรูปสินค้า (ย่อทั้งรูปให้อยู่ในกรอบสี่เหลี่ยม เติมพื้นขาว) · ค่าเริ่มต้นจะครอปตรงกลางให้เป็นสี่เหลี่ยมจัตุรัสเท่ากรอบบนหน้า Catalog</label>';
    var b = brands.filter(function (x) { return x.name === A.ibrand; })[0];
    if (!b) return h + '<p class="muted">ยังไม่มีสินค้า</p>';
    h += '<div class="panel"><h3>โลโก้แบรนด์</h3><div class="plist">' + iBlock('b', nrm(b.name), b.display || b.name, 'ครอปเป็นสี่เหลี่ยมจัตุรัส แสดงเป็นวงกลมบนหน้า Catalog', b.logo ? [b.logo] : []) + '</div></div>';
    var prods = A.full.products.filter(function (p) { return p.brand === b.name; });
    h += '<div class="panel"><h3>รูปสินค้า <span class="small muted">' + prods.length + ' รายการ</span></h3><div class="plist">' + prods.map(function (p) {
      var src = p.images.length ? p.images : p.formImages;
      return iBlock('p', pKey(p), p.name, '', src);
    }).join('') + '</div></div>';
    return h;
  }

  function render() {
    var app = document.getElementById('adm'); if (!app) return;
    // หน้าแก้ข้อความบนหน้าเว็บ: ไม่วาดใหม่ทั้งหน้า (ไม่ให้ iframe โหลดใหม่)
    if (A.token && A.page === 'texts' && A.tview !== 'list' && A.texts !== null && document.getElementById('tframe')) {
      updateTbar();
      var er = document.getElementById('aerr'); if (er) { er.hidden = !A.err; er.textContent = A.err || ''; }
      var tb = document.getElementById('toast'); if (A.msg) { if (!tb) { tb = document.createElement('div'); tb.id = 'toast'; tb.setAttribute('role', 'status'); document.body.appendChild(tb); } tb.textContent = A.msg; } else if (tb) tb.remove();
      return;
    }
    var ae = document.activeElement, fid = ae && ae.getAttribute && (ae.getAttribute('data-k') || ae.getAttribute('data-t')) ? [ae.getAttribute('data-k') ? 'data-k' : 'data-t', ae.getAttribute('data-k') || ae.getAttribute('data-t'), ae.getAttribute('data-id')] : null;
    if (!A.token) { app.className = 'adm-login'; app.innerHTML = vLogin(); return; }
    app.className = 'adm';
    app.innerHTML = '<aside class="side"><div class="who"><img src="' + esc(CFG.logo || '') + '" alt=""><div><b>Mera Admin</b><small>' + esc(A.by) + '</small></div></div>' +
      '<button class="' + (A.page === 'banners' ? 'on' : '') + '" data-a="page" data-v="banners">▣ แบนเนอร์และโปรโมชัน</button><button class="' + (A.page === 'texts' ? 'on' : '') + '" data-a="page" data-v="texts">✎ ข้อความบนหน้าเว็บ</button><button class="' + (A.page === 'images' ? 'on' : '') + '" data-a="page" data-v="images">▦ รูปสินค้าและโลโก้</button><span style="flex:1"></span><a class="sbtn" href="./" target="_blank" rel="noopener">เปิดหน้า Catalog ↗</a><button class="sbtn" data-a="logout">ออกจากระบบ</button></aside>' +
      '<section class="main"><div class="mtop"><b>Mera Admin</b><span style="flex:1"></span><a class="abtn o" href="./" target="_blank" rel="noopener">Catalog ↗</a><button class="abtn o" data-a="logout">ออก</button></div><div class="mtabs2"><button class="' + (A.page === 'banners' ? 'on' : '') + '" data-a="page" data-v="banners">แบนเนอร์</button><button class="' + (A.page === 'texts' ? 'on' : '') + '" data-a="page" data-v="texts">ข้อความ</button><button class="' + (A.page === 'images' ? 'on' : '') + '" data-a="page" data-v="images">รูปสินค้า</button></div>' + (A.page === 'texts' ? vTexts() : A.page === 'images' ? vImages() : vBanners()) +
      '<div class="err" role="alert" id="aerr"' + (A.err ? '' : ' hidden') + '>' + esc(A.err) + '</div></section>' + (A.msg ? '<div id="toast" role="status">' + esc(A.msg) + '</div>' : '');
    if (fid) { var el = app.querySelector('[' + fid[0] + '="' + fid[1] + '"]' + (fid[2] ? '[data-id="' + fid[2].replace(/"/g, '\\"') + '"]' : '')); if (el && el.type !== 'checkbox') { el.focus(); try { var n = el.value.length; el.setSelectionRange(n, n); } catch (e) {} } }
  }

  document.addEventListener('submit', function (e) { if (e.target.id === 'pwf') { e.preventDefault(); var pw = document.getElementById('pw').value; if (pw) loginPassword(pw); } });
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-a]'); if (!el) return;
    var a = el.getAttribute('data-a'), id = el.getAttribute('data-id'), v = el.getAttribute('data-v');
    if (a !== 'del' && A.confirmDel) A.confirmDel = '';
    switch (a) {
      case 'line': return loginLine(false);
      case 'copyId': try { navigator.clipboard.writeText(A.notAdmin.userId).then(function () { A.msg = 'คัดลอกแล้ว'; render(); flash(); }, function () {}); } catch (x) {} return;
      case 'logout': return logout('');
      case 'page': var fr0 = document.getElementById('tframe'); if (fr0 && v !== 'texts') fr0.remove(); A.page = v; A.err = ''; if (v === 'texts' && A.texts === null) loadTexts(); else if (v === 'images' && A.img === null) loadImages(); else render(); return;
      case 'tsave': return saveTexts();
      case 'tview': A.tview = v; if (v === 'list') A.tEdit = {}; var host = document.getElementById('tframe'); if (host) host.remove(); return render();
      case 'tmode': { A.tmode = v; var fa = frameApi(); if (fa) fa.setMode(v); return updateTbar(); }
      case 'tlang': { A.tlang = v; var fb = frameApi(); if (fb) fb.setLang(v); return updateTbar(); }
      case 'treset': { var k = el.getAttribute('data-key'); tSet(k, 'th', ''); tSet(k, 'en', ''); return render(); }
      case 'ibrand': A.ibrand = v; return render();
      case 'isave': case 'ireset': case 'idel': case 'imv': {
        var k2 = el.getAttribute('data-k2'), kind = k2.slice(0, 1), key = k2.slice(2);
        if (a === 'isave') return iSave(kind, key);
        if (a === 'ireset') { if (iSaved(kind, key).length) { iSet(kind, key, []); return iSave(kind, key); } delete A.idraft[k2]; return render(); }
        var list = iList(kind, key).slice(), i = +el.getAttribute('data-i');
        if (a === 'idel') list.splice(i, 1);
        else { var j = i + (+v); if (j < 0 || j >= list.length) return; var t = list[i]; list[i] = list[j]; list[j] = t; }
        iSet(kind, key, list); return render();
      }
      case 'add': return addRow(v);
      case 'save': return saveRow(id);
      case 'del': return delRow(id);
      case 'up': return move(id, -1);
      case 'down': return move(id, 1);
    }
  });
  document.addEventListener('input', function (e) {
    var tt = e.target.getAttribute && e.target.getAttribute('data-t');
    if (tt === 'q') { A.tq = e.target.value; return render(); }
    if (tt === 'th' || tt === 'en') {
      tSet(e.target.getAttribute('data-key'), tt, e.target.value);
      var n = tDirty().length, b = document.querySelector('[data-a="tsave"]'); if (b) { b.disabled = !n; b.textContent = 'บันทึก' + (n ? ' (' + n + ')' : ''); }
      var row = e.target.closest('.trow'); if (row) row.classList.add('dirty');
      return;
    }
    var k = e.target.getAttribute && e.target.getAttribute('data-k'), id = e.target.getAttribute && e.target.getAttribute('data-id'); if (!k || !id) return;
    var b = edit(id);
    if (k === 'title') b.title = e.target.value;
    else if (k === 'url') b.link = 'url:' + e.target.value.trim();
    else return;
    var btn = document.querySelector('[data-a="save"][data-id="' + id + '"]'); if (btn) { btn.disabled = false; btn.textContent = 'บันทึก'; }
    var row = btn && btn.closest('.brow'); if (row) row.classList.add('dirty');
  });
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.getAttribute && t.getAttribute('data-file')) return upload(t.getAttribute('data-file'), t.files && t.files[0]);
    if (t.getAttribute && t.getAttribute('data-ifile')) { var k3 = t.getAttribute('data-ifile'); return iUpload(k3.slice(0, 1), k3.slice(2), t.files); }
    if (t.getAttribute && t.getAttribute('data-a2') === 'ifit') { A.ifit = t.checked; return; }
    var k = t.getAttribute && t.getAttribute('data-k'), id = t.getAttribute && t.getAttribute('data-id'); if (!k || !id) return;
    var b = edit(id);
    if (k === 'link') b.link = t.value === 'url:' ? 'url:https://' : t.value;
    else if (k === 'start' || k === 'end') b[k] = t.value;
    else if (k === 'active') b.active = t.checked;
    else if (k === 'title' || k === 'url') return;
    render();
  });

  // รูปจากชีต/ฟอร์มที่เปิดไม่ได้ (ไฟล์ Drive ไม่ได้แชร์) → แสดงกรอบว่างแทนไอคอนรูปแตก
  document.addEventListener('error', function (e) { var el = e.target; if (el && el.tagName === 'IMG' && !el.getAttribute('data-fb')) { el.setAttribute('data-fb', '1'); el.src = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=='; el.title = 'เปิดรูปนี้ไม่ได้ (ไฟล์ใน Drive อาจไม่ได้เปิดแชร์)'; } }, true);
  loadCatalog();
  render();
  if (A.token) loadBanners(); else loginLine(true);
})();
