/*!
 * Mera — ตะกร้า + ซื้อทันที + ออเดอร์ของฉัน (หน้าตา Catalog V2) · ตรรกะและการเรียกหลังบ้านเหมือน mera-checkout.js เดิมทุกอย่าง
 * ------------------------------------------------------------
 * ใส่ในหน้าเว็บ (ก่อน </body>):
 *
 *   <script>
 *     window.MERA_CHECKOUT = {
 *       api: 'https://script.google.com/macros/s/xxxx/exec',   // Web app /exec ของโปรเจกต์ Inventory + GB (ตัวเดียวกับ webhook LINE)
 *       lineOaId: '@652glcdn',
 *       // getIdToken: () => liff.getIDToken()   // ค่าเริ่มต้นใช้ LIFF ที่หน้าเว็บเปิดไว้แล้ว
 *     };
 *   </script>
 *   <script src="mera-checkout.js" defer></script>
 *
 * ผูกปุ่ม "เพิ่มลงตะกร้า" ของแต่ละสินค้า:
 *   MeraCheckout.add({ sku: 'MRA040', qty: 1, name: '1984 club t-shirt', brand: 'Komé', color: 'สีดำ', size: 'M', img: 'https://…' })
 * เปิดตะกร้าเดิม: MeraCheckout.openCart()
 * ซื้อสินค้าเดียวทันที (รองรับโค้ดเก่า): MeraCheckout.open({ sku: 'MRA040', qty: 1 })
 * หน้า "ออเดอร์ของฉัน":  MeraCheckout.openOrders()
 * ลิงก์ในการ์ด LINE (?order=MO-0001) เปิดหน้าสถานะออเดอร์ให้เอง
 */
(function () {
  'use strict';
  var CFG = Object.assign({
    api: '',
    lineOaId: '@652glcdn',
    addressDb: 'https://cdn.jsdelivr.net/gh/earthchie/jquery.Thailand.js@master/jquery.Thailand.js/database/raw_database/raw_database.json',
    getIdToken: function () { try { return window.liff && window.liff.getIDToken ? window.liff.getIDToken() : ''; } catch (e) { return ''; } },
    testUserId: '',
    privacyUrl: 'privacy.html',   // หน้านโยบายความเป็นส่วนตัว
  }, window.MERA_CHECKOUT || {});

  /* ---------------- styles ---------------- */
  var CSS = [
    '.mc-ov{position:fixed;inset:0;z-index:9990;background:#EFE6DC;display:flex;justify-content:center}',
    '.mc-ov[hidden]{display:none}',
    '.mc-sh{width:100%;max-width:520px;height:100%;max-height:100vh;max-height:100dvh;background:#FFFBED;color:#2a0a14;font-family:Poppins,Prompt,system-ui,sans-serif;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 0 40px rgba(42,10,20,.12)}',
    '.mc-sh *{box-sizing:border-box}',
    '.mc-sh button{font:inherit;cursor:pointer}',
    '.mc-hd{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;padding:8px 14px;padding-top:calc(8px + env(safe-area-inset-top,0px));border-bottom:1px solid #efe2d8;background:#FFFBED;flex:none}',
    '.mc-hd h2{margin:0;text-align:center;font-size:18px;font-weight:600;line-height:1.3}',
    '.mc-hd h2 small{display:block;font-size:11px;font-weight:500;color:#8a6a72}',
    '.mc-ib{width:34px;height:34px;border-radius:50%;background:#841132;border:0;display:flex;align-items:center;justify-content:center;color:#fff;padding:0}',
    '.mc-ib.plain{background:none;color:#2a0a14;justify-self:end}',
    '.mc-bd{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:16px 16px calc(28px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;gap:14px}',
    '.mc-card{background:#fff;border-radius:12px;box-shadow:0 2px 10px rgba(58,7,22,.10);padding:14px;display:flex;flex-direction:column;gap:10px}',
    '.mc-row{display:flex;justify-content:space-between;gap:10px;align-items:baseline;font-size:14px}',
    '.mc-row .m{color:#8a6a72}',
    '.mc-hr{height:1px;background:#efe2d8}',
    '.mc-total{display:flex;justify-content:space-between;align-items:baseline;gap:10px}',
    '.mc-total b{font-size:22px;color:#841132}',
    '.mc-free{color:#17652F;font-weight:600}',
    '.mc-h{margin:4px 0 0;font-size:18px;font-weight:700}',
    '.mc-sub{font-size:13px;color:#5e2a37;line-height:1.5}',
    '.mc-small{font-size:12px;color:#8a6a72;line-height:1.5}',
    '.mc-btn{display:flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:999px;background:#841132;color:#fff;font-weight:600;font-size:15px;min-height:48px;padding:10px 18px;width:100%;text-decoration:none}',
    '.mc-btn[disabled]{opacity:.45;cursor:default}',
    '.mc-btn2{display:flex;align-items:center;justify-content:center;gap:8px;border:1.5px solid #2a0a14;border-radius:999px;background:#fff;color:#2a0a14;font-weight:600;font-size:15px;min-height:48px;padding:10px 18px;width:100%;text-decoration:none}',
    '.mc-link{border:0;background:none;color:#841132;font-size:13px;font-weight:600;text-decoration:underline;text-underline-offset:3px;padding:4px 0;align-self:center}',
    '.mc-btns{border:1px solid #2a0a14;background:#fff;border-radius:999px;font-size:12px;font-weight:600;padding:5px 12px;min-height:30px;white-space:nowrap;color:#2a0a14}',
    '.mc-btnline{display:flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:999px;background:#06C755;color:#fff;font-weight:700;font-size:15px;min-height:50px;width:100%}',
    '.mc-pill{display:inline-flex;align-items:center;font-size:11px;font-weight:600;padding:3px 9px;border-radius:999px;background:#FCE4E8;color:#841132;white-space:nowrap;align-self:flex-start}',
    '.mc-pill.ok{background:#DDF2E2;color:#17652F}.mc-pill.bad{background:#F8D7DA;color:#9b1c1c}.mc-pill.off{background:#eee5e0;color:#5e2a37}',
    '.mc-chips{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin:0 -16px;padding:0 16px}',
    '.mc-chips::-webkit-scrollbar{display:none}',
    '.mc-chip{border:1.5px solid #841132;background:#fff;color:#841132;border-radius:999px;padding:7px 14px;font-size:13px;font-weight:600;white-space:nowrap;min-height:36px}',
    '.mc-chip.on{background:#841132;color:#fff}',
    '.mc-line{display:flex;gap:12px;align-items:center}',
    '.mc-line img,.mc-ph{width:84px;height:84px;border-radius:10px;object-fit:cover;flex:none;background:#f3e9e3;box-shadow:0 2px 8px rgba(58,7,22,.10)}',
    '.mc-line.s img,.mc-line.s .mc-ph{width:64px;height:64px}',
    '.mc-col{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
    '.mc-brand{font-size:12px;color:#841132;font-weight:600}',
    '.mc-name{font-size:14px;font-weight:600;line-height:1.35}',
    '.mc-var{font-size:12px;color:#8a6a72}',
    '.mc-price{font-size:16px;font-weight:700}',
    '.mc-left{font-size:11px;color:#5e2a37}.mc-left.low{color:#9b1c1c;font-weight:600}',
    '.mc-qty{display:inline-flex;align-items:center;gap:12px;background:#fff;border-radius:999px;box-shadow:0 1px 4px rgba(0,0,0,.15);padding:3px 6px}',
    '.mc-qty button{width:28px;height:28px;border-radius:50%;border:0;background:#841132;color:#fff;font-size:16px;line-height:1;padding:0}',
    '.mc-qty button.m{background:#fff;color:#841132;border:1.5px solid #841132}',
    '.mc-qty button[disabled]{opacity:.35}',
    '.mc-qty b{min-width:14px;text-align:center}',
    '.mc-f{display:flex;flex-direction:column;gap:5px;font-size:12px;font-weight:600;color:#5e2a37}',
    '.mc-f input,.mc-f select,.mc-sh textarea{border:1px solid #e3d6ce;background:#fff;border-radius:12px;padding:11px 12px;font:400 15px Poppins,Prompt,system-ui,sans-serif;color:#2a0a14;box-shadow:0 1px 3px rgba(0,0,0,.06);width:100%;min-width:0;min-height:44px}',
    '.mc-sh textarea{min-height:80px;resize:vertical}',
    '.mc-f.bad input,.mc-f.bad select{border-color:#9b1c1c;background:#fff6f6}',
    '.mc-g2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}',
    '.mc-chk{display:flex;gap:8px;align-items:center;font-size:13px;color:#5e2a37}',
    '.mc-chk input{width:18px;height:18px;accent-color:#841132}',
    '.mc-err{background:#F8D7DA;color:#9b1c1c;border-radius:10px;padding:10px 12px;font-size:13px;line-height:1.5}',
    '.mc-note{background:#fff8e6;border:1px solid #f1dfae;color:#6b4e00;border-radius:10px;padding:9px 12px;font-size:12px;line-height:1.55}',
    '.mc-load{display:flex;align-items:center;justify-content:center;gap:10px;padding:40px 0;color:#5e2a37;font-size:14px}',
    '.mc-spin{width:18px;height:18px;border-radius:50%;border:2.5px solid #f0dfe2;border-top-color:#841132;animation:mcspin .8s linear infinite;display:inline-block}',
    '@keyframes mcspin{to{transform:rotate(360deg)}}',
    '.mc-pay{display:flex;gap:10px;align-items:center}',
    '.mc-radio{width:18px;height:18px;border-radius:50%;border:5px solid #841132;flex:none}',
    '.mc-qrcard{align-items:center;text-align:center}',
    '.mc-qrhead{background:#113566;color:#fff;font-size:11px;font-weight:700;padding:4px 12px;border-radius:6px;letter-spacing:.06em}',
    '.mc-qrimg{width:210px;max-width:100%;aspect-ratio:1}',
    '.mc-qrimg canvas,.mc-qrimg img{width:100%;height:100%;display:block}',
    '.mc-amt{font-size:30px;font-weight:700;color:#841132;line-height:1.2}',
    '.mc-acct{font-size:12px;color:#5e2a37;white-space:pre-line}',
    '.mc-copies{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}',
    '.mc-pick{border:1.5px dashed #841132;background:#fff;border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:112px;padding:10px;color:#2a0a14}',
    '.mc-pick b{color:#841132;font-size:14px}',
    '.mc-slip{display:flex;flex-direction:column;gap:10px;align-items:stretch}',
    '.mc-slip .mc-slipimg{background:#f6efe9;border-radius:10px;display:flex;align-items:center;justify-content:center;padding:6px}',
    '.mc-slip .mc-slipimg img{display:block;width:auto;height:auto;max-width:100%;max-height:min(62vh,520px);object-fit:contain;border-radius:6px}',
    '.mc-slip .mc-row{align-items:center}',
    '.mc-done{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:40px 10px 10px;text-align:center}',
    '.mc-done .ring{width:132px;height:132px;border-radius:50%;background:#841132;display:flex;align-items:center;justify-content:center}',
    '.mc-done h3{margin:10px 0 0;font-size:26px}',
    '.mc-id{font-family:ui-monospace,Menlo,monospace;font-weight:700;color:#841132;font-size:15px}',
    '.mc-steps{display:flex;justify-content:space-between;position:relative;padding:0 4px}',
    '.mc-steps:before{content:"";position:absolute;left:24px;right:24px;top:12px;height:2px;background:#e6d3d6}',
    '.mc-st{position:relative;display:flex;flex-direction:column;align-items:center;gap:5px;width:20%;text-align:center}',
    '.mc-st i{width:24px;height:24px;border-radius:50%;background:#fff;color:#841132;font-style:normal;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;border:2px solid #841132}',
    '.mc-st.done i{background:#841132;color:#fff}',
    '.mc-st b{font-size:10px;font-weight:600;line-height:1.25}',
    '.mc-st small{font-size:9px;color:#8a6a72}',
    '.mc-trk{display:flex;justify-content:space-between;align-items:center;gap:10px;background:#faf4ef;border-radius:10px;padding:8px 10px}',
    '.mc-trk b{font-family:ui-monospace,Menlo,monospace;font-size:13px}',
    '.mc-card.mc-oi{display:flex;flex-direction:row;gap:14px;align-items:center;text-align:left;border:0;width:100%;color:inherit}',
    '.mc-oi>img,.mc-oi>.mc-ph{width:72px;height:88px;flex:0 0 72px;object-fit:cover;border-radius:12px;background:#f4ece6;display:block}','.mc-oi .mc-col{min-width:0;flex:1}',
    '.mc-empty{text-align:center;color:#8a6a72;padding:40px 10px}',
    '.mc-perks{display:flex;flex-direction:column;gap:9px}',
    '.mc-perks div{display:flex;gap:8px;align-items:center;font-size:14px}',
    '.mc-perks span{width:20px;height:20px;border-radius:50%;background:#841132;display:flex;align-items:center;justify-content:center;flex:none}',
    '.mc-cps{display:flex;gap:8px;flex-wrap:wrap}',
    '.mc-fs{border:0;margin:0;padding:14px;background:#fff;border-radius:12px;box-shadow:0 2px 10px rgba(58,7,22,.10);display:flex;flex-direction:column;gap:10px;min-width:0}',
    '.mc-fs legend{font-weight:700;float:left;width:100%;padding:0;margin-bottom:10px}',
    '.mc-ck{display:flex;gap:10px;align-items:flex-start;border:0;background:none;text-align:left;font-size:13px;color:#2a0a14;padding:4px 0}',
    '.mc-ck b{width:20px;height:20px;border-radius:6px;border:1.5px solid #841132;display:flex;align-items:center;justify-content:center;flex:none;color:#fff;font-size:12px}',
    '.mc-ck.on b{background:#841132}',
    '.mc-ck a{color:#841132}',
    '.mc-bars{display:flex;gap:4px}.mc-bars span{flex:1;height:5px;border-radius:999px;background:#f0dfe2}.mc-bars span.on{background:#841132}',
    '.mc-cartfab{position:fixed;right:16px;bottom:calc(84px + env(safe-area-inset-bottom));z-index:60;border:0;border-radius:999px;background:#841132;color:#fff;box-shadow:0 8px 24px rgba(58,7,22,.28);font:600 14px Poppins,Prompt,system-ui,sans-serif;padding:11px 18px;min-height:46px;cursor:pointer;display:flex;align-items:center;gap:8px}',
    '.mc-cartfab[hidden]{display:none}',
    '.mc-toast{position:fixed;left:50%;bottom:calc(140px + env(safe-area-inset-bottom));transform:translateX(-50%);background:#2a0a14;color:#fff;padding:10px 16px;border-radius:999px;font:500 13px Poppins,Prompt,system-ui,sans-serif;z-index:9995;max-width:calc(100% - 32px);text-align:center}',
  ].join('');

  var ICON = {
    back: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
    close: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    truck: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/></svg>',
    line: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M12 4C7 4 3 7.2 3 11.2c0 3.6 3.2 6.6 7.5 7.1-.2.8-.6 2.1-.7 2.4 0 0 0 .4.4.3.4-.1 3.6-2.4 5.1-3.6 3.4-1 5.7-3.4 5.7-6.2C21 7.2 17 4 12 4z"/></svg>',
    up: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg>',
    check: '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>',
    checkW: '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" aria-hidden="true"><path d="M12 8v5M12 17h.01"/><circle cx="12" cy="12" r="9"/></svg>',
    down: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>',
    warn: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9b1c1c" stroke-width="2.4" aria-hidden="true"><path d="M12 8v5M12 17h.01"/><circle cx="12" cy="12" r="9"/></svg>',
    pin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
    cam: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
    pic: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/></svg>',
    cart: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 4h2l2.4 11h10.2L20 7H6.2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/></svg>',
  };

  /* ---------------- helpers ---------------- */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function baht(n) { return Number(n || 0).toLocaleString('th-TH', { maximumFractionDigits: 2 }) + ' บาท'; }
  function $(sel) { return S.root ? S.root.querySelector(sel) : null; }
  function variant(o) { return [o.color, o.size ? 'ไซซ์ ' + o.size : '', (o.qty || 1) + ' ชิ้น'].filter(Boolean).join(' · '); }
  function uuid() { return 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  var TH_M = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  function thDate(ms) { if (!ms) return ''; var d = new Date(ms); return d.getDate() + ' ' + TH_M[d.getMonth()] + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }

  function api(action, data) {
    if (!CFG.api) return Promise.reject(new Error('ยังไม่ได้ตั้งค่า MERA_CHECKOUT.api'));
    var body = Object.assign({ action: action }, data || {});
    var needAuth = ['config', 'quote'].indexOf(action) < 0;
    var optAuth = action === 'quote';   // ค่าส่งขึ้นกับลำดับสมาชิก → ส่ง token ถ้ามี ไม่มีก็ยังดูราคาได้
    var auth = !needAuth && !optAuth ? Promise.resolve() : CFG.testUserId ? Promise.resolve().then(function () { body.testUserId = CFG.testUserId; })
      : getToken().then(function (tok) { if (tok) body.idToken = tok; else if (needAuth) throw new Error(authHint()); });
    return auth.then(function () { return send(body); });
    function send(body) {
    if (typeof CFG.mockApi === 'function') return Promise.resolve(CFG.mockApi(body)).then(check);
    return fetch(CFG.api, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) })
      .catch(function () { throw new Error('เชื่อมต่อระบบสั่งซื้อไม่ได้ ตรวจอินเทอร์เน็ต หรือแจ้งทีม Mera (ลิงก์ api ไม่ถูกต้อง)'); })
      .then(function (r) { return r.text(); })
      .then(function (t) {
        var j; try { j = JSON.parse(t); } catch (e) { console.warn('mera-checkout: หลังบ้านตอบว่า', String(t).slice(0, 300)); throw new Error(diagnose(t)); }
        return j;
      }).then(check);
    }
    function check(j) { if (!j || !j.ok) { var e = new Error((j && j.error) || 'ระบบขัดข้อง ลองใหม่อีกครั้ง'); e.code = j && j.code; throw e; } return j; }
  }

  /** ขอ ID token จาก LINE (รอ LIFF เริ่มทำงานเสร็จก่อน สูงสุด 5 วินาที) */
  function getToken() {
    var t = CFG.getIdToken();
    if (t) return Promise.resolve(t);
    var l = window.liff;
    if (!l || !l.ready) return Promise.resolve('');
    return Promise.race([l.ready, new Promise(function (r) { setTimeout(r, 5000); })]).then(function () { return CFG.getIdToken(); }, function () { return ''; });
  }
  function authHint() {
    var l = window.liff;
    if (!l) return 'หน้าเว็บยังไม่ได้เชื่อม LINE (ไม่พบ LIFF) — กรุณาเปิดผ่านลิงก์ใน LINE ของ Mera';
    try {
      if (l.isLoggedIn && !l.isLoggedIn()) { l.login({ redirectUri: location.href }); return 'กำลังพาไปเข้าสู่ระบบ LINE…'; }
    } catch (e) {}
    return 'ยืนยันตัวตน LINE ไม่ได้: แอป LIFF ต้องเปิดสิทธิ์ (Scope) "openid" — แจ้งทีม Mera';
  }

  /** หลังบ้านตอบกลับไม่ใช่ JSON → บอกสาเหตุที่น่าจะเป็น (ให้ทีมแก้ได้ทันที) */
  function diagnose(t) {
    t = String(t || '').trim();
    var pre = 'ระบบสั่งซื้อยังไม่พร้อม: ';
    if (t === 'OK' || t === 'ERROR') return pre + 'Apps Script ยังไม่รับออเดอร์เว็บ — เพิ่ม 5 บรรทัด webHandlePost_ ใน doPost แล้ว Deploy → Manage deployments → New version';
    if (/accounts\.google\.com|ServiceLogin|Sign in/i.test(t)) return pre + 'ลิงก์ api ต้องตั้ง Who has access = Anyone';
    if (/Script function not found|ไม่พบฟังก์ชันสคริปต์|doPost/i.test(t)) return pre + 'ลิงก์ api ไม่ใช่ /exec ของโปรเจกต์ Inventory + GB';
    if (/<html/i.test(t)) return pre + 'Apps Script ตอบกลับเป็นหน้าเว็บ (ตรวจว่าใช้ลิงก์ /exec ไม่ใช่ /dev และ Deploy เวอร์ชันล่าสุดแล้ว)';
    return pre + 'หลังบ้านตอบกลับไม่ถูกต้อง (' + t.slice(0, 60) + ')';
  }

  /* ---------------- state + shell ---------------- */
  var CART_KEY = 'mera_cart_v1';
  var S = { root: null, view: '', item: null, items: [], cartMode: false, quote: null, config: null, addr: null, profileName: '', slip: null, busy: false, order: null, orders: null, stack: [] };

  function mount() {
    if (S.root) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    var ov = document.createElement('div'); ov.className = 'mc-ov'; ov.hidden = true;
    ov.innerHTML = '<div class="mc-sh" role="dialog" aria-modal="true" aria-labelledby="mc-title"></div>';
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    document.body.appendChild(ov);
    var fab = document.createElement('button'); fab.type = 'button'; fab.className = 'mc-cartfab'; fab.hidden = true;
    fab.addEventListener('click', function () { MeraCheckout.openCart(); });
    document.body.appendChild(fab);
    S.ov = ov; S.root = ov.firstChild; S.fab = fab; updateCartFab();
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !S.ov.hidden) back(); });
    window.addEventListener('popstate', function () { if (!S.ov.hidden) { S.popping = true; back(); S.popping = false; } });
  }
  function show() {
    mount();
    if (S.ov.hidden) {
      S.ov.hidden = false; S.prevOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
      try { history.pushState({ mc: 1 }, ''); } catch (e) {}
    }
  }
  function close() {
    if (!S.ov || S.ov.hidden) return;
    S.ov.hidden = true; document.body.style.overflow = S.prevOverflow || ''; S.stack = [];
    if (!S.popping) { try { if (history.state && history.state.mc) history.back(); } catch (e) {} }
  }
  function back() { var prev = S.stack.pop(); if (prev) go(prev, true); else close(); }
  function go(view, isBack) {
    if (!isBack && S.view && S.view !== view && S.view !== 'done') S.stack.push(S.view);
    if (view === 'done') S.stack = [];
    S.view = view; render();
    var bd = $('.mc-bd'); if (bd) bd.scrollTop = 0;
    var t = $('#mc-title'); if (t) { t.tabIndex = -1; t.focus({ preventScroll: true }); }
  }
  function header(title, sub, canBack) {
    return '<div class="mc-hd">' + (canBack ? '<button class="mc-ib" data-a="back" aria-label="ย้อนกลับ">' + ICON.back + '</button>' : '<span></span>') +
      '<h2 id="mc-title">' + esc(title) + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</h2>' +
      '<button class="mc-ib plain" data-a="close" aria-label="ปิด">' + ICON.close + '</button></div>';
  }
  function loading(t) { return '<div class="mc-load"><span class="mc-spin"></span>' + esc(t || 'กำลังโหลด…') + '</div>'; }
  function errBox(msg) { return msg ? '<div class="mc-err" role="alert">' + esc(msg) + '</div>' : ''; }

  function cleanItem(item) {
    item = item || {};
    return { sku: String(item.sku || '').trim().toUpperCase(), qty: Math.max(1, Math.floor(Number(item.qty) || 1)),
      name: item.name || '', brand: item.brand || '', color: item.color || '', size: item.size || '', img: item.img || '' };
  }
  function readCart() {
    try { var a = JSON.parse(localStorage.getItem(CART_KEY) || '[]'); return Array.isArray(a) ? a.map(cleanItem).filter(function (x) { return x.sku; }) : []; }
    catch (e) { return []; }
  }
  function writeCart(items) {
    items = (items || []).map(cleanItem).filter(function (x) { return x.sku; });
    try { localStorage.setItem(CART_KEY, JSON.stringify(items)); } catch (e) {}
    updateCartFab(items);
    try { document.dispatchEvent(new CustomEvent('mera:cart', { detail: { items: items, count: items.reduce(function (n, x) { return n + x.qty; }, 0) } })); } catch (e) {}
  }
  function updateCartFab(items) {
    if (!S.fab) return;
    items = items || readCart();
    var n = items.reduce(function (sum, x) { return sum + (Number(x.qty) || 0); }, 0);
    S.fab.hidden = !n || CFG.hideFab === true; S.fab.innerHTML = ICON.cart + 'ตะกร้า · ' + n + ' ชิ้น';
  }
  function mergeCartItem(item) {
    var next = readCart(), x = cleanItem(item), old = next.find(function (it) { return it.sku === x.sku; });
    if (old) {
      old.qty = Math.min(5, old.qty + x.qty);
      ['name', 'brand', 'color', 'size', 'img'].forEach(function (k) { if (x[k]) old[k] = x[k]; });
    } else next.push(x);
    writeCart(next); return next;
  }

  function render() {
    var v = S.view, html = '';
    if (v === 'cart') html = viewCart();
    else if (v === 'checkout') html = viewCheckout();
    else if (v === 'pay') html = viewPay();
    else if (v === 'done') html = viewDone(S.order);
    else if (v === 'order') html = viewOrder(S.order);
    else if (v === 'orders') html = viewOrders();
    else if (v === 'gate') html = viewGate();
    else if (v === 'profile') html = viewProfile();
    else if (v === 'welcome') html = viewWelcome();
    var bd0 = S.root.querySelector('.mc-bd'), keep = bd0 && v === S.lastView ? bd0.scrollTop : 0;
    var fa = document.activeElement, fid = fa && S.root.contains(fa) && fa.id ? fa.id : '', caret = null;
    try { caret = fid && fa.selectionStart != null ? fa.selectionStart : null; } catch (e) {}
    S.root.innerHTML = html;
    bind();
    var bd = S.root.querySelector('.mc-bd'); if (bd && keep) bd.scrollTop = keep;
    if (fid && v === S.lastView) {
      var el = document.getElementById(fid);
      if (el) { try { el.focus({ preventScroll: true }); if (caret != null && el.setSelectionRange) el.setSelectionRange(caret, caret); } catch (e) {} }
    }
    S.lastView = v;
  }

  /* ---------------- Membership: สมัคร → รู้จักคุณอีกนิด → ต้อนรับ ---------------- */
  var PROFILE_Q = [
    { key: 'age', label: 'ช่วงอายุ', options: ['ต่ำกว่า 18', '18–23', '24–29', '30–39', '40+'] },
    { key: 'job', label: 'อาชีพ', options: ['นักเรียน / นักศึกษา', 'พนักงานบริษัท', 'Freelance', 'เจ้าของธุรกิจ', 'ข้าราชการ / รัฐวิสาหกิจ', 'อื่น ๆ', 'ไม่สะดวกตอบ'] },
    { key: 'income', label: 'รายได้โดยประมาณต่อเดือน (บาท)', options: ['ต่ำกว่า 10,000', '10,001–20,000', '20,001–30,000', '30,001–50,000', '50,001+', 'ไม่สะดวกตอบ'] },
    { key: 'area', label: 'พื้นที่อาศัยหลัก', options: ['กรุงเทพฯ', 'ปริมณฑล', 'ต่างจังหวัดเมืองใหญ่', 'ต่างจังหวัดอื่น ๆ'] },
    { key: 'fashionBudget', label: 'งบประมาณเสื้อผ้าต่อเดือน (บาท)', options: ['ต่ำกว่า 500', '500–1,000', '1,001–3,000', '3,000+'] },
  ];
  // คำถามจากหลังบ้าน (ถ้ามี) — รองรับตัวเลือกที่เป็นข้อความ หรือ {label, value} · ข้อไหนไม่มีตัวเลือก ใช้ชุดสำรองในเว็บ
  function memberQs() {
    var src = (S.mem && S.mem.profileOptions && S.mem.profileOptions.length) ? S.mem.profileOptions : PROFILE_Q;
    var local = {}; PROFILE_Q.forEach(function (q) { local[q.key] = q; });
    return src.map(function (q) {
      var opts = (q.options || q.opts || []).map(function (o) { return o && typeof o === 'object' ? String(o.value != null ? o.value : o.label) : String(o); }).filter(Boolean);
      if (!opts.length && local[q.key]) opts = local[q.key].options;
      return { key: q.key, label: q.label || q.q || (local[q.key] && local[q.key].label) || q.key, options: opts };
    }).filter(function (q) { return q.key && q.options.length; });
  }
  var METRO = ['นนทบุรี', 'ปทุมธานี', 'สมุทรปราการ', 'สมุทรสาคร', 'นครปฐม'];
  var BIG = ['เชียงใหม่', 'ขอนแก่น', 'นครราชสีมา', 'ชลบุรี', 'ภูเก็ต', 'สงขลา', 'อุดรธานี', 'ระยอง', 'สุราษฎร์ธานี', 'พิษณุโลก', 'อุบลราชธานี', 'เชียงราย'];
  // คำตอบตอนสมัครในหน้าแค็ตตาล็อก (อายุ / อาชีพ / จังหวัด) → เติมให้ล่วงหน้า ไม่ต้องตอบซ้ำ
  function signupAnswers() {
    var g = {}; try { g = JSON.parse(localStorage.getItem('mera-gate-ans') || '{}') || {}; } catch (e) {}
    var m = {}; try { m = JSON.parse(localStorage.getItem('mera-member-v1') || '{}') || {}; } catch (e) {}
    var a = Object.assign({}, m, g), out = {};
    if (a.age) out.age = a.age;
    if (a.occupation || a.job) out.job = a.job || a.occupation;
    var pv = a.province;
    if (a.area) out.area = a.area;
    else if (pv) out.area = pv === 'กรุงเทพมหานคร' ? 'กรุงเทพฯ' : METRO.indexOf(pv) >= 0 ? 'ปริมณฑล' : BIG.indexOf(pv) >= 0 ? 'ต่างจังหวัดเมืองใหญ่' : pv === 'ต่างประเทศ' ? '' : 'ต่างจังหวัดอื่น ๆ';
    return out;
  }
  var TICK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#FFFBED" stroke-width="3" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>';
  var LINE_G = '<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M12 3C6.5 3 2 6.6 2 11c0 3.9 3.5 7.2 8.3 7.9.3.1.8.2.9.5.1.3.1.7 0 1l-.1.9c0 .3-.2 1 .9.5 1.1-.5 5.9-3.5 8.1-6C21.4 14.1 22 12.6 22 11c0-4.4-4.5-8-10-8z"/></svg>';

  function viewGate() {
    var sh = (S.mem && S.mem.shipping) || {};
    var perks = [sh.perk || 'ใช้สิทธิ์สมาชิกตามเงื่อนไขของ Mera', 'ซื้อทันที และจองดีลราคาส่งได้', 'ดูสถานะออเดอร์ได้ทุกเครื่อง'];
    var h = header('สมัคร Mera Member', '', false) + '<div class="mc-bd">';
    h += '<div class="mc-card" style="align-items:center;text-align:center"><h3 class="mc-h" style="color:#841132">สมัครสมาชิกก่อนสั่งซื้อ</h3>' +
      '<span class="mc-sub">สมัครผ่าน LINE ใช้เวลาไม่ถึง 1 นาที ไม่ต้องตั้งรหัสผ่าน</span></div>';
    h += '<div class="mc-card mc-perks">' + perks.map(function (p) { return '<div><span>' + TICK + '</span>' + esc(p) + '</div>'; }).join('') + '</div>';
    h += errBox(S.gateErr);
    h += '<button class="mc-btnline" data-a="gateGo">' + LINE_G + (S.loggedIn ? 'สมัครด้วย LINE' : 'เข้าสู่ระบบด้วย LINE') + '</button>';
    h += '<span class="mc-small" style="text-align:center">มือถือ: กด "อนุญาต" ในแอป LINE · คอม: สแกน QR ด้วยแอป LINE</span>';
    return h + '</div>';
  }

  function viewProfile() {
    var a = S.profAns || {}, qs = memberQs();
    var n = qs.filter(function (q) { return a[q.key]; }).length;
    var ready = n === qs.length && S.profPolicy;
    var h = header('สมัคร Mera Member', 'ตอบแล้ว ' + n + '/' + qs.length + ' ข้อ', true) + '<div class="mc-bd">';
    h += '<span class="mc-pill ok">✓ เชื่อมต่อ LINE แล้ว' + (S.profileName ? ' · ' + esc(S.profileName) : '') + '</span>';
    h += '<div class="mc-bars" aria-hidden="true">' + qs.map(function (q) { return '<span' + (a[q.key] ? ' class="on"' : '') + '></span>'; }).join('') + '</div>';
    var done = qs.filter(function (q) { return a[q.key] && (S.profPre || {})[q.key] && !(S.profOpen || {})[q.key]; });
    if (done.length) h += '<div class="mc-card" style="gap:6px"><b style="font-size:14px">ข้อมูลจากตอนสมัคร</b>' + done.map(function (q) {
      return '<div class="mc-row" style="align-items:center"><span class="m">' + esc(q.label) + '</span><span style="display:flex;gap:8px;align-items:center"><b>' + esc(a[q.key]) + '</b><button type="button" class="mc-link" data-a="profEdit" data-g="' + esc(q.key) + '">แก้</button></span></div>';
    }).join('') + '</div>';
    qs.filter(function (q) { return done.indexOf(q) < 0; }).forEach(function (q) {
      h += '<fieldset class="mc-fs"><legend>' + esc(q.label) + '</legend><div class="mc-cps">' + q.options.map(function (o) {
        var on = a[q.key] === o;
        return '<button type="button" class="mc-chip' + (on ? ' on' : '') + '" data-a="prof" data-g="' + esc(q.key) + '" data-v="' + esc(o) + '" aria-pressed="' + on + '">' + esc(o) + '</button>';
      }).join('') + '</div></fieldset>';
    });
    var pol = CFG.privacyUrl ? '<a href="' + esc(CFG.privacyUrl) + '" target="_blank" rel="noopener">นโยบายความเป็นส่วนตัว</a>' : 'นโยบายความเป็นส่วนตัว';
    h += '<button type="button" class="mc-ck' + (S.profPolicy ? ' on' : '') + '" data-a="profPolicy" role="checkbox" aria-checked="' + !!S.profPolicy + '"><b>' + (S.profPolicy ? '✓' : '') + '</b><span>ฉันยอมรับ ' + pol + '</span></button>';
    h += '<button type="button" class="mc-ck' + (S.profMkt ? ' on' : '') + '" data-a="profMkt" role="checkbox" aria-checked="' + !!S.profMkt + '"><b>' + (S.profMkt ? '✓' : '') + '</b><span>รับข่าวสารและดีลจาก Mera ผ่าน LINE <span style="color:#8a6a72">(ไม่บังคับ)</span></span></button>';
    h += errBox(S.profErr);
    h += '<button class="mc-btn" data-a="profSave"' + (ready && !S.busy ? '' : ' disabled') + '>' + (S.busy ? 'กำลังบันทึก…' : 'สมัครและไปต่อ') + '</button>';
    if (!ready) h += '<span class="mc-small" style="text-align:center;color:#9b1c1c">ตอบให้ครบ ' + qs.length + ' ข้อ และยอมรับนโยบายก่อนไปต่อ</span>';
    return h + '</div>';
  }

  function viewWelcome() {
    var m = (S.mem && S.mem.member) || {}, sh = (S.mem && S.mem.shipping) || {};
    var h = header('ยินดีต้อนรับ', '', false) + '<div class="mc-bd"><div class="mc-done" style="min-height:0;padding-top:10px">';
    h += '<span class="ring">' + ICON.check + '</span><h3>ยินดีต้อนรับค่ะ' + (S.profileName ? ' คุณ ' + esc(S.profileName) : '') + '</h3>' +
      '<span class="mc-sub">คุณเป็น Mera Member แล้ว</span>' + (m.customerId ? '<span class="mc-small">รหัสสมาชิก</span><span class="mc-id">' + esc(m.customerId) + '</span>' : '') + '</div>';
    h += '<div class="mc-card"><b style="display:flex;gap:8px;align-items:center">' + ICON.truck + (sh.free ? 'ส่งฟรีออเดอร์นี้' : 'ค่าส่ง ' + baht(sh.fee || 0) + ' ต่อออเดอร์') + '</b>' +
      (sh.policy ? '<span class="mc-small">' + esc(sh.policy) + '</span>' : '') + '</div>';
    h += '<button class="mc-btn" data-a="welcomeGo">ไปชำระเงิน</button><button class="mc-btn2" data-a="close">ดูสินค้าต่อ</button>';
    return h + '</div>';
  }

  /** เช็กสมาชิกก่อนซื้อ: ยังไม่ล็อกอิน / ยังกรอกไม่ครบ → หน้า gate */
  function checkMember() {
    S.gateErr = '';
    return Promise.all([loadConfig(), api('memberGet').then(function (j) { S.loggedIn = true; return j; }, function (err) {
      if (err.code === 'AUTH' || /LINE/.test(err.message)) { S.loggedIn = false; return null; }
      return { error: err };
    })]).then(function (r) {
      var cfg = r[0] || {}, j = r[1];
      if (j && j.error) return true;
      if (j) { S.mem = j; if (j.name) S.profileName = S.profileName || j.name; }
      if (cfg.requireProfile !== true) return true;
      S.needGate = !j || !j.profileComplete;
      return !S.needGate;
    });
  }
  function openGate() {
    var m = (S.mem && S.mem.member) || {}, qs = memberQs();
    var pre = signupAnswers();
    S.profAns = {}; qs.forEach(function (q) { var v = m[q.key] || pre[q.key]; if (v && q.options.indexOf(v) >= 0) S.profAns[q.key] = v; });
    S.profPolicy = false; S.profMkt = !!m.marketing; S.profErr = ''; S.profOpen = {}; S.profPre = Object.assign({}, S.profAns);
    S.stack = []; S.view = ''; go(S.loggedIn ? 'profile' : 'gate');   // ล็อกอิน LINE แล้ว → ไปหน้ากรอกข้อมูลเลย ไม่ต้องกดสมัครซ้ำ
  }
  function saveProfile() {
    if (S.busy) return;
    S.busy = true; S.profErr = ''; render();
    var ans = Object.assign({}, S.profAns, { acceptPolicy: true, marketing: !!S.profMkt,
      policyVersion: (S.mem && S.mem.policyVersion) || (S.config && S.config.policyVersion) || '' });
    api('memberSave', { answers: ans }).then(function (j) {
      S.busy = false;
      S.mem = Object.assign({}, S.mem || {}, { member: j.member, profileComplete: j.profileComplete, missing: j.missing, shipping: j.shipping });
      if (!j.profileComplete) { S.profErr = 'ยังตอบไม่ครบ กรุณาตรวจอีกครั้ง'; return render(); }
      S.needGate = false; S.stack = []; S.view = ''; go('welcome');
      try { document.dispatchEvent(new CustomEvent('mera:member', { detail: j.member })); } catch (er) {}
    }).catch(function (err) { S.busy = false; S.profErr = err.message; render(); });
  }
  function lineLogin() {
    var l = window.liff;
    if (l && l.login) {
      try { sessionStorage.setItem('mc_resume', JSON.stringify({ cart: S.cartMode, items: S.items })); } catch (e) {}
      try { l.login({ redirectUri: location.href }); return; } catch (e) { try { sessionStorage.removeItem('mc_resume'); } catch (er) {} }
    }
    S.gateErr = 'เปิดหน้านี้ผ่าน LINE (แตะลิงก์ Mera ในแชท LINE) แล้วกดอีกครั้ง'; render();
  }

  /* ---------------- รายการสินค้า ---------------- */
  // รูปสินค้า: ใช้รูปที่ส่งมา ถ้าไม่มี (เช่นออเดอร์จาก LINE / เครื่องอื่น) หาจาก SKU หรือชื่อสินค้าในแค็ตตาล็อก
  function imgFor(o) {
    if (o && o.img) return o.img;
    var f = (window.MERA_CHECKOUT && window.MERA_CHECKOUT.imgFor) || CFG.imgFor;
    try { return (typeof f === 'function' && f(o)) || ''; } catch (e) { return ''; }
  }
  function pic(o) { var src = imgFor(o); return src ? '<img src="' + esc(src) + '" alt="" loading="lazy" onerror="this.outerHTML=\'<span class=&quot;mc-ph&quot;></span>\'">' : '<span class="mc-ph"></span>'; }
  function leftTag(left, qty) {
    if (left == null) return '';
    if (left > 0 && !(qty && left < qty)) return '';
    return '<span class="mc-left low">' + (left > 0 ? 'มีสินค้าแค่ ' + left + ' ชิ้น' : 'สินค้าหมด') + '</span>';
  }
  function mergedItems() {
    var q = S.quote || {}, quoted = {}, problemBySku = {};
    (q.items || []).forEach(function (x) { quoted[x.sku] = x; });
    (q.problems || []).forEach(function (x) { problemBySku[x.sku] = x; });
    if (!S.cartMode) {
      var it = S.item || {}, pr = q.product || {};
      return [Object.assign({}, it, { brand: it.brand || pr.brand, name: it.name || pr.name, color: pr.color || it.color, size: pr.size || it.size, sku: pr.sku || it.sku,
        img: it.img || pr.img, available: q.available, unit: q.price ? q.price.unit : 0, qty: q.price ? q.price.qty : it.qty })];
    }
    return S.items.map(function (local) {
      var remote = quoted[local.sku] || {}, problem = problemBySku[local.sku] || {};
      return Object.assign({}, local, remote, { img: local.img || remote.img, available: remote.available != null ? remote.available : problem.available });
    });
  }
  function problemsOf() {
    var q = S.quote;
    if (!q) return [];
    return S.cartMode ? (q.problems || []) : (q.available < q.qty ? [{ error: q.available ? 'สินค้าเหลือ ' + q.available + ' ชิ้น ลดจำนวนก่อนสั่งซื้อ' : 'สินค้าหมดแล้ว' }] : []);
  }
  function probTxt(x) { var it = x.sku ? S.items.filter(function (i) { return i.sku === x.sku; })[0] : null; return (it && it.name ? it.name + ' ' : '') + x.error; }
  function variantTxt(o) { return [o.color, o.size ? 'ไซซ์ ' + o.size : ''].filter(Boolean).join(' · '); }

  /* ---------------- view: ตะกร้า ---------------- */
  function viewCart() {
    var q = S.quote;
    var h = header('ตะกร้าสินค้า', '', true) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '<button class="mc-btn2" data-a="close">กลับไปเลือกสินค้า</button></div>';
    if (!S.items.length) return h + '<p class="mc-empty">ตะกร้ายังว่างอยู่</p><button class="mc-btn2" data-a="close">ดูสินค้าทั้งหมด</button></div>';
    if (!q) return h + loading('กำลังเช็กราคาและสต็อก…') + '</div>';
    mergedItems().forEach(function (o) {
      var left = o.available;
      h += '<div class="mc-card"><div class="mc-line">' + pic(o) + '<div class="mc-col"><span class="mc-brand">' + esc(o.brand) + '</span><span class="mc-name">' + esc(o.name) + '</span>' +
        '<span class="mc-var">' + esc(variantTxt(o)) + '</span><span class="mc-price">' + baht((o.unit || 0) * o.qty) + '</span>' + leftTag(left, o.qty) + '</div></div>' +
        '<div class="mc-row" style="align-items:center"><span class="mc-qty"><button type="button" class="m" data-a="cartDec" data-sku="' + esc(o.sku) + '" aria-label="ลดจำนวน"' + (o.qty <= 1 ? ' disabled' : '') + '>−</button><b>' + o.qty + '</b>' +
        '<button type="button" data-a="cartInc" data-sku="' + esc(o.sku) + '" aria-label="เพิ่มจำนวน"' + ((left != null && o.qty >= left) || o.qty >= 5 ? ' disabled' : '') + '>+</button></span>' +
        '<button type="button" class="mc-link" data-a="cartRemove" data-sku="' + esc(o.sku) + '" style="align-self:center">นำออก</button></div></div>';
    });
    var p = q.price || {}, probs = problemsOf();
    h += '<div class="mc-card"><div class="mc-row"><span class="m">ราคาสินค้า (' + (p.qty || 0) + ' ชิ้น)</span><span>' + baht(p.subtotal) + '</span></div>' +
      '<div class="mc-row"><span class="m">ค่าส่ง</span><span>' + (p.shipping ? baht(p.shipping) : '<span class="mc-free">' + esc(p.shipLabel || 'ฟรี') + '</span>') + '</span></div>' +
      '<div class="mc-hr"></div><div class="mc-total"><b style="font-size:15px;color:#2a0a14">ยอดชำระ</b><b>' + baht(p.total) + '</b></div></div>';
    if (probs.length) h += errBox('กรุณาแก้ตะกร้า: ' + probs.map(probTxt).join(' · '));
    h += '<button class="mc-btn" data-a="toCheckout"' + (probs.length ? ' disabled' : '') + '>ไปชำระเงิน</button>';
    h += '<button class="mc-btn2" data-a="shopMore">เลือกสินค้าเพิ่ม</button>';
    h += '<span class="mc-small" style="text-align:center">สินค้าหลายแบรนด์ แต่ละแบรนด์แยกกล่องจัดส่ง</span>';
    return h + '</div>';
  }

  /* ---------------- view: ชำระเงิน (ที่อยู่ + สรุป) ---------------- */
  function viewCheckout() {
    var q = S.quote, cart = S.cartMode;
    var h = header(cart ? 'ชำระเงิน' : 'ซื้อทันที', 'ขั้นตอน 1/2 · ที่อยู่และสรุปยอด', cart) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '<button class="mc-btn2" data-a="close">ปิด</button></div>';
    if (!q) return h + loading('กำลังเช็กราคาและสต็อก…') + '</div>';
    h += addressForm();
    h += '<h3 class="mc-h">รายการสั่งซื้อ</h3>';
    mergedItems().forEach(function (o) {
      h += '<div class="mc-line s">' + pic(o) + '<div class="mc-col"><span class="mc-brand">' + esc(o.brand) + '</span><span class="mc-name">' + esc(o.name) + '</span>' +
        '<span class="mc-var">' + esc(variantTxt(o)) + '</span>' + leftTag(o.available, o.qty) + '</div><b>×' + o.qty + '</b></div>';
    });
    var p = q.price;
    h += '<div class="mc-card"><div class="mc-row"><span class="m">' + (cart ? 'ราคาสินค้า (' + p.qty + ' ชิ้น)' : 'ราคาสินค้า (' + baht(p.unit) + ' × ' + p.qty + ')') + '</span><span>' + baht(p.subtotal) + '</span></div>' +
      '<div class="mc-row"><span class="m">ค่าส่ง</span><span>' + (p.shipping ? baht(p.shipping) : '<span class="mc-free">' + esc(p.shipLabel || 'ฟรี') + '</span>') + '</span></div>' +
      (p.saved ? '<div class="mc-row"><span class="m">ส่วนต่างจากราคาปกติ</span><span class="mc-free">' + baht(p.saved) + '</span></div>' : '') +
      '<div class="mc-hr"></div><div class="mc-total"><b style="font-size:15px;color:#2a0a14">ยอดชำระ</b><b>' + baht(p.total) + '</b></div>' +
      (p.shipPolicy ? '<span class="mc-small">' + esc(p.shipPolicy) + '</span>' : '') + '</div>';
    h += '<div class="mc-card mc-pay"><span class="mc-radio"></span><span style="flex:1"><b>สแกนจ่าย QR พร้อมเพย์</b><br><span class="mc-small">แนบสลิปในขั้นถัดไป · ทีม Mera ตรวจสลิปภายใน 1 ชม.</span></span></div>';
    if (q.eta) h += '<div class="mc-card" style="flex-direction:row;gap:10px;align-items:center">' + ICON.truck + '<span><span class="mc-small">คาดว่าจะได้รับ</span><br><b>' + esc(q.eta.label) + '</b></span></div>';
    var probs = problemsOf();
    if (probs.length) h += errBox('กรุณาแก้รายการ: ' + probs.map(probTxt).join(' · '));
    h += prefsForm();
    h += errBox(S.formErr);
    h += '<button class="mc-btn" data-a="toPay"' + (probs.length ? ' disabled' : '') + '>ดำเนินการชำระเงิน · ' + baht(p.total) + '</button>';
    return h + '</div>';
  }
  function addrDone() {
    var a = S.addr || {};
    return a.name && /^0\d{8,9}$/.test(String(a.phone || '').replace(/\D/g, '')) && a.line && /^\d{5}$/.test(a.postcode || '') && a.province && a.district && a.subdistrict;
  }
  function addressForm() {
    var a = S.addr || {}, db = ADDR.ready;
    var hd = '<div class="mc-card"><div class="mc-row" style="align-items:center"><b style="display:flex;gap:6px;align-items:center">' + ICON.pin + 'ที่อยู่จัดส่ง</b>';
    if (S.addrPrefilled && addrDone() && !S.addrEdit) {
      return hd + '<button class="mc-link" data-a="addrEdit" style="align-self:center">แก้ไข</button></div><div class="mc-hr"></div>' +
        '<span class="mc-sub">' + esc(a.name) + ' · ' + esc(a.phone) + '<br>' + esc(a.line) + ' ' + esc(a.subdistrict) + ' ' + esc(a.district) + ' ' + esc(a.province) + ' ' + esc(a.postcode) + '</span></div>';
    }
    var f = function (id, label, input) { return '<label class="mc-f" id="mcf-' + id + '">' + label + input + '</label>'; };
    var inp = function (id, val, attrs) { return '<input id="mc-' + id + '" value="' + esc(val) + '" ' + (attrs || '') + '>'; };
    var sel = function (id, list, val, ph) {
      return '<select id="mc-' + id + '"><option value="">' + esc(ph) + '</option>' + list.map(function (x) { return '<option' + (x === val ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('') + '</select>';
    };
    var h = hd + '</div><div class="mc-hr"></div>';
    h += f('name', 'ชื่อ-นามสกุลผู้รับ', inp('name', a.name, 'autocomplete="name"'));
    h += f('phone', 'เบอร์โทร', inp('phone', a.phone, 'type="tel" inputmode="tel" autocomplete="tel" placeholder="08X-XXX-XXXX"'));
    h += f('line', 'บ้านเลขที่ / หมู่บ้าน / ซอย / ถนน', inp('line', a.line, 'autocomplete="address-line1" placeholder="เช่น 99/1 หมู่บ้าน… ซอย… ถนน…"'));
    h += '<div class="mc-g2">';
    h += f('postcode', 'รหัสไปรษณีย์', inp('postcode', a.postcode, 'inputmode="numeric" maxlength="5" autocomplete="postal-code"'));
    if (db) {
      h += f('province', 'จังหวัด', sel('province', ADDR.provinces(a.postcode), a.province, 'เลือกจังหวัด'));
      h += f('district', 'เขต / อำเภอ', sel('district', ADDR.districts(a.province, a.postcode), a.district, 'เลือก'));
      h += f('subdistrict', 'แขวง / ตำบล', sel('subdistrict', ADDR.subdistricts(a.province, a.district, a.postcode), a.subdistrict, 'เลือก'));
    } else {
      h += f('province', 'จังหวัด', inp('province', a.province, 'autocomplete="address-level1"'));
      h += f('district', 'เขต / อำเภอ', inp('district', a.district, 'autocomplete="address-level2"'));
      h += f('subdistrict', 'แขวง / ตำบล', inp('subdistrict', a.subdistrict, 'autocomplete="address-level3"'));
    }
    h += '</div>' + (db ? '<span class="mc-small">พิมพ์รหัสไปรษณีย์ แล้วเลือกจังหวัด เขต แขวงจากรายการ</span>' : '');
    h += '<label class="mc-chk"><input type="checkbox" id="mc-save"' + (S.saveAddr !== false ? ' checked' : '') + '>จำที่อยู่นี้ไว้ใช้ครั้งต่อไป</label></div>';
    return h;
  }
  function readAddr() {
    var g = function (id) { var el = $('#mc-' + id); return el ? el.value.trim() : ''; };
    if (!$('#mc-name')) return;
    S.addr = { name: g('name'), phone: g('phone'), line: g('line'), postcode: g('postcode'), province: g('province'), district: g('district'), subdistrict: g('subdistrict') };
    var s = $('#mc-save'); if (s) S.saveAddr = s.checked;
  }
  function validAddr() {
    var a = S.addr || {}, bad = [];
    if (!a.name) bad.push(['name', 'กรอกชื่อผู้รับ']);
    if (!/^0\d{8,9}$/.test(String(a.phone || '').replace(/\D/g, ''))) bad.push(['phone', 'เบอร์โทรไม่ถูกต้อง']);
    if (!a.line) bad.push(['line', 'กรอกบ้านเลขที่ / ถนน']);
    if (!/^\d{5}$/.test(a.postcode || '')) bad.push(['postcode', 'รหัสไปรษณีย์ 5 หลัก']);
    if (!a.province) bad.push(['province', 'เลือกจังหวัด']);
    if (!a.district) bad.push(['district', 'เลือกเขต/อำเภอ']);
    if (!a.subdistrict) bad.push(['subdistrict', 'เลือกแขวง/ตำบล']);
    return bad;
  }
  var BUDGET_TH = { '<300': 'ต่ำกว่า 300', '300-500': '300–500', '501-700': '501–700', '701+': '700 ขึ้นไป' };
  function prefsForm() {
    if (!CFG.askPrefs) return '';
    var miss = S.prefMissing || [], o = S.prefOptions, a = S.prefAns;
    if (!miss.length || !o) return '';
    var chip = function (group, val, label, on) { return '<button type="button" class="mc-chip' + (on ? ' on' : '') + '" data-a="pref" data-g="' + group + '" data-v="' + esc(val) + '" aria-pressed="' + on + '">' + esc(label) + '</button>'; };
    var h = '<div class="mc-card"><b>ช่วยบอก Mera อีกนิด <span class="mc-small">(ข้ามได้)</span></b>';
    if (miss.indexOf('category') >= 0) h += '<b class="mc-small">สนใจหมวดไหน</b><div class="mc-cps">' + o.categories.map(function (c) { return chip('category', c, c, a.category.indexOf(c) >= 0); }).join('') + '</div>';
    if (miss.indexOf('budget') >= 0) h += '<b class="mc-small">งบต่อชิ้น (บาท)</b><div class="mc-cps">' + o.budgets.map(function (c) { return chip('budget', c, BUDGET_TH[c] || c, a.budget === c); }).join('') + '</div>';
    if (miss.indexOf('size') >= 0) h += '<b class="mc-small">ไซซ์ที่ใส่ประจำ</b><div class="mc-cps">' + o.sizes.map(function (c) { return chip('size', c, c, a.size === c); }).join('') + '</div>';
    return h + '</div>';
  }

  /* ---------------- view: โอนจ่าย + แนบสลิป ---------------- */
  function viewPay() {
    var p = S.quote.price, pay = (S.config && S.config.payment) || {};
    var h = header(S.reupload ? 'แนบสลิปใหม่' : 'ชำระเงิน', S.reupload ? (S.order ? 'ออเดอร์ ' + S.order.id : '') : 'ขั้นตอน 2/2 · โอนและแนบสลิป', true) + '<div class="mc-bd">';
    var amt = Number(p.total).toLocaleString('th-TH', { minimumFractionDigits: 2 });
    var acct = (String(pay.text || '').match(/\d{3}-?\d-?\d{5}-?\d/) || [])[0] || '';
    var hasQr = pay.promptpayId || pay.qrUrl;
    h += '<div class="mc-card mc-qrcard">' + (hasQr ? '<span class="mc-qrhead">THAI QR PAYMENT</span>' : '') +
      (pay.promptpayId ? '<div class="mc-qrimg" id="mc-qr" role="img" aria-label="QR พร้อมเพย์ ' + amt + ' บาท"></div>'
        : pay.qrUrl ? '<div class="mc-qrimg"><img id="mc-qrpic" src="' + esc(pay.qrUrl) + '" alt="QR พร้อมเพย์สำหรับโอนเงิน"></div>' : '') +
      '<span class="mc-small">ยอดชำระ</span><span class="mc-amt">' + amt + ' <small style="font-size:16px">บาท</small></span>' +
      (pay.accountName ? '<b style="font-size:14px">' + esc(pay.accountName) + '</b>' : '') +
      (pay.text ? '<span class="mc-acct">' + esc(pay.text) + '</span>' : '') +
      (hasQr ? '<button class="mc-btn" data-a="saveQr">' + ICON.down + 'บันทึกรูป QR</button><span class="mc-small">ถ้ากดแล้วไม่บันทึก ให้กดค้างที่รูป QR แล้วเลือก "บันทึกรูปภาพ"</span>' : '') +
      '<div class="mc-copies"><button class="mc-btns" data-a="copy" data-v="' + esc(String(p.total)) + '">คัดลอกยอด</button>' +
      (acct ? '<button class="mc-btns" data-a="copy" data-v="' + esc(acct.replace(/-/g, '')) + '">คัดลอกเลขบัญชี</button>' : '') + '</div></div>';
    h += '<div class="mc-card"><b>วิธีชำระ</b><ol style="margin:0;padding-left:20px;font-size:13px;line-height:1.7;color:#5e2a37">' +
      (hasQr ? '<li>บันทึกรูป QR ลงเครื่อง</li><li>เปิดแอปธนาคาร → สแกน → เลือกรูป QR จากอัลบั้ม</li>' : '<li>โอนเข้าบัญชีด้านบน</li>') +
      '<li>โอนยอด <b>' + amt + ' บาท</b> แล้วบันทึกสลิป</li><li>กลับมาหน้านี้ แนบสลิปด้านล่าง</li></ol></div>';
    h += '<h3 class="mc-h">แนบสลิป</h3>';
    if (S.slip) h += '<div class="mc-card mc-slip"><div class="mc-slipimg"><img src="' + S.slip.preview + '" alt="สลิปที่แนบ"></div><div class="mc-row"><span class="mc-pill ok">✓ แนบสลิปแล้ว</span><button class="mc-btns" data-a="pickSlip" data-v="lib">เปลี่ยนรูป</button></div></div>';
    else h += '<div class="mc-g2"><button class="mc-pick" data-a="pickSlip" data-v="cam">' + ICON.cam + '<b>ถ่ายรูป</b><span class="mc-small">ถ่ายสลิปจากหน้าจอ</span></button>' +
      '<button class="mc-pick" data-a="pickSlip" data-v="lib">' + ICON.pic + '<b>เลือกจากอัลบั้ม</b><span class="mc-small">รูปจากแอปธนาคาร</span></button></div>';
    h += '<input type="file" id="mc-file" accept="image/*" hidden><input type="file" id="mc-cam" accept="image/*" capture="environment" hidden>';
    h += errBox(S.payErr);
    h += '<button class="mc-btn" data-a="submit"' + (!S.slip || S.busy ? ' disabled' : '') + '>' + (S.busy ? '<span class="mc-spin" style="border-color:rgba(255,255,255,.4);border-top-color:#fff"></span>กำลังส่ง…' : 'ยืนยันการชำระเงิน') + '</button>';
    h += '<span class="mc-small" style="text-align:center">ทีม Mera ตรวจสลิปภายใน 1 ชม. แล้วแจ้งผลทาง LINE</span>';
    return h + '</div>';
  }

  /* ---------------- view: สั่งซื้อสำเร็จ ---------------- */
  function viewDone(o) {
    var h = header('สั่งซื้อสำเร็จ', '', false) + '<div class="mc-bd">';
    if (!o) return h + loading() + '</div>';
    h += '<div class="mc-done"><span class="ring">' + ICON.check + '</span><h3>ขอบคุณค่ะ!</h3>' +
      '<span class="mc-sub">ได้รับออเดอร์และสลิปแล้ว<br>ทีม Mera กำลังตรวจสลิป และจะแจ้งผลทาง LINE ภายใน 1 ชม.</span>' +
      '<span class="mc-small" style="margin-top:14px">เลขออเดอร์</span><span class="mc-id">' + esc(o.id) + '</span></div>';
    var items = (S.orderedItems && S.orderedItems.length) ? S.orderedItems : (o.items && o.items.length ? o.items : [o]);
    h += '<div class="mc-card">' + items.map(function (x) {
      return '<div class="mc-line s">' + pic(Object.assign({}, x, { img: x.img || (items.length === 1 ? o.img : '') })) + '<div class="mc-col"><span class="mc-brand">' + esc(x.brand || '') + '</span><span class="mc-name">' + esc(x.name || x.sku || '') + '</span><span class="mc-var">' + esc(variantTxt(x)) + '</span></div><b>×' + (x.qty || 1) + '</b></div>';
    }).join('') + '<div class="mc-hr"></div><div class="mc-total"><b style="font-size:15px;color:#2a0a14">ยอดชำระรวม</b><b>' + baht(o.total) + '</b></div></div>';
    h += '<button class="mc-btn" data-a="openOrder" data-id="' + esc(o.id) + '">ติดตามออเดอร์</button>';
    h += '<button class="mc-btn2" data-a="close">กลับไปเลือกสินค้าต่อ</button>';
    return h + '</div>';
  }

  /* ---------------- view: ติดตามออเดอร์ ---------------- */
  var STEPS = [['ได้รับออเดอร์', 'createdAt'], ['ตรวจสลิป', 'paidAt'], ['แบรนด์แพ็กของ', ''], ['จัดส่งแล้ว', 'shippedAt'], ['ได้รับสินค้า', '']];
  function stepOf(o) {
    if (o.status === 'Cancelled' || o.status === 'Slip Rejected') return -1;
    if (o.received) return 4;
    return { Confirmed: 2, 'Partially Shipped': 3, Shipped: 3 }[o.status] || 1;
  }
  var ST_LABEL = { 'Pending Slip': 'กำลังตรวจสลิป', Confirmed: 'ยืนยันแล้ว', 'Partially Shipped': 'จัดส่งบางส่วน', Shipped: 'จัดส่งแล้ว', 'Slip Rejected': 'สลิปไม่ผ่าน', Cancelled: 'ยกเลิก', Error: 'กำลังตรวจสอบ', Received: 'ได้รับแล้ว' };
  var ST_CLS = { Received: 'off', Confirmed: 'ok', 'Partially Shipped': 'ok', Shipped: 'ok', Cancelled: 'off', 'Slip Rejected': 'bad' };
  function stOf(o) { return o.received ? 'Received' : o.status; }
  function viewOrder(o) {
    var h = header('ติดตามออเดอร์', o ? o.id : '', true) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '</div>';
    if (!o) return h + loading() + '</div>';
    var st = stOf(o), stp = stepOf(o);
    h += '<div class="mc-card"><div class="mc-row" style="align-items:center"><span><span class="mc-id">' + esc(o.id) + '</span><br><span class="mc-small">สั่งเมื่อ ' + esc(thDate(o.createdAt)) + '</span></span><span class="mc-pill ' + (ST_CLS[st] || '') + '">' + esc(ST_LABEL[st] || o.statusLabel || st) + '</span></div>';
    if (stp >= 0) {
      if (o.eta && !o.received) h += '<span class="mc-small">คาดว่าจะได้รับ</span><b style="margin-top:-6px">' + esc(o.eta.label) + '</b>';
      h += '<div class="mc-steps">' + STEPS.map(function (s, i) {
        var t = s[1] && o[s[1]] ? thDate(o[s[1]]) : '';
        return '<div class="mc-st' + (i <= stp ? ' done' : '') + '"><i>' + (i + 1) + '</i><b>' + esc(s[0]) + '</b><small>' + esc(i <= stp ? t : '') + '</small></div>';
      }).join('') + '</div>';
    }
    if (o.status === 'Slip Rejected') h += '<div class="mc-err">สลิปไม่ผ่าน' + (o.rejectReason ? ': ' + esc(o.rejectReason) : ' กรุณาแนบสลิปใหม่ หรือทักแอดมินทาง LINE') + '</div><button class="mc-btn" data-a="reupload">แนบสลิปใหม่</button>';
    if (o.status === 'Cancelled') h += '<div class="mc-note">ออเดอร์นี้ถูกยกเลิกแล้ว สอบถามเพิ่มเติมทาง LINE ได้เลย</div>';
    h += '</div>';
    var brands = []; (o.items || []).forEach(function (x) { if (x.brand && brands.indexOf(x.brand) < 0) brands.push(x.brand); });
    if ((o.shipments || []).length && brands.length > 1) {
      h += '<h3 class="mc-h">การจัดส่ง (' + o.shipments.length + '/' + brands.length + ' แบรนด์)</h3>';
      brands.forEach(function (bn) {
        var s = o.shipments.filter(function (x) { return x.brand === bn; })[0];
        h += '<div class="mc-card"><div class="mc-row"><b>' + esc(bn) + '</b><span class="mc-pill ' + (s ? 'ok' : '') + '">' + (s ? 'จัดส่งแล้ว' : 'แบรนด์กำลังแพ็ก') + '</span></div>' +
          (s ? '<div class="mc-trk"><span><span class="mc-small">' + esc(s.company || '') + '</span><br><b>' + esc(s.tracking) + '</b></span><button class="mc-btns" data-a="copyTrk" data-v="' + esc(s.tracking) + '">คัดลอก</button></div>' : '') + '</div>';
      });
    } else if (o.tracking) {
      h += '<div class="mc-card"><b>การจัดส่ง</b><div class="mc-trk"><span><span class="mc-small">' + esc(o.shippingCompany || '') + '</span><br><b>' + esc(o.tracking) + '</b></span><button class="mc-btns" data-a="copyTrk" data-v="' + esc(o.tracking) + '">คัดลอก</button></div></div>';
    }
    h += receiptCard(o);
    var items = o.items && o.items.length ? o.items : [o];
    h += '<div class="mc-card"><b>รายละเอียดออเดอร์</b>' + items.map(function (x, i) {
      return '<div class="mc-line s">' + pic(Object.assign({}, x, { img: x.img || (items.length === 1 ? o.img : '') })) + '<div class="mc-col"><span class="mc-brand">' + esc(x.brand || '') + '</span><span class="mc-name">' + esc(x.name || x.sku || '') + '</span><span class="mc-var">' + esc(variantTxt(x)) + '</span></div><b>×' + (x.qty || 1) + '</b></div>';
    }).join('') + '<div class="mc-hr"></div>' + (o.shipping ? '<div class="mc-row"><span class="m">ค่าส่ง</span><span>' + baht(o.shipping) + '</span></div>' : '') +
      '<div class="mc-total"><b style="font-size:15px;color:#2a0a14">ยอดชำระ</b><b>' + baht(o.total) + '</b></div></div>';
    h += '<a class="mc-btn2" href="https://line.me/R/ti/p/' + encodeURIComponent(CFG.lineOaId) + '" target="_blank" rel="noopener">สอบถามออเดอร์ทาง LINE</a>';
    h += '<button class="mc-link" data-a="orders">ดูออเดอร์ทั้งหมด</button>';
    h += '<span class="mc-small" style="text-align:center">ทุกสถานะแจ้งทาง LINE ด้วย</span>';
    return h + '</div>';
  }
  /** ได้รับของแล้ว / มีปัญหา (รายแบรนด์) */
  function receiptCard(o) {
    var rc = o.receipt || [];
    if (!rc.length || !rc.some(function (x) { return x.state !== 'preparing'; })) return '';
    var many = rc.length > 1, open = rc.some(function (x) { return x.state === 'shipped'; });
    var h = '<div class="mc-card"><b>' + (open ? 'ได้รับสินค้าแล้วหรือยัง?' : 'การรับสินค้า') + '</b>';
    if (open) h += '<span class="mc-small">กดยืนยันเมื่อได้รับของครบ ถ้ามีปัญหา (ของไม่ครบ / ชำรุด / ผิดแบบ) แจ้งได้ภายใน 3 วันหลังได้รับ</span>';
    rc.forEach(function (x) {
      var b = esc(x.brand || '');
      h += '<div style="display:flex;flex-direction:column;gap:8px">' + (many ? '<b style="font-size:13px">' + b + '</b>' : '');
      if (x.state === 'received') h += '<span class="mc-pill ok">✓ ได้รับแล้ว' + (x.receivedAt ? ' · ' + esc(thDate(x.receivedAt)) : '') + '</span>';
      else if (x.state === 'issue') h += '<div class="mc-note">แจ้งปัญหาแล้ว ทีม Mera จะติดต่อกลับทาง LINE</div>';
      else if (x.state === 'refunded') h += '<span class="mc-pill off">คืนเงินแล้ว</span>';
      else if (x.state === 'preparing') h += '<span class="mc-small">รอแบรนด์จัดส่ง</span>';
      else if (S.issueFor === (x.brand || '*')) {
        h += '<textarea id="mc-issue" maxlength="300" placeholder="เล่าปัญหาสั้นๆ เช่น ได้ของไม่ครบ / สินค้าชำรุด / ผิดสีหรือไซซ์">' + esc(S.issueText || '') + '</textarea>' +
          '<div class="mc-g2"><button class="mc-btn2" data-a="issueCancel">ยกเลิก</button><button class="mc-btn" data-a="issueSend" data-b="' + b + '"' + (S.rcvBusy ? ' disabled' : '') + '>' + (S.rcvBusy ? 'กำลังส่ง…' : 'ส่งให้ทีม Mera') + '</button></div>';
      } else {
        h += '<div class="mc-g2"><button class="mc-btn" data-a="recv" data-b="' + b + '"' + (S.rcvBusy ? ' disabled' : '') + '>' + (S.rcvBusy === (x.brand || '*') ? 'กำลังบันทึก…' : 'ได้รับของแล้ว') + '</button>' +
          '<button class="mc-btn2" data-a="issueOpen" data-b="' + b + '">มีปัญหากับสินค้า</button></div>';
      }
      h += '</div>';
    });
    return h + errBox(S.rcvErr) + '</div>';
  }
  function receiptAct(kind, brand) {
    if (S.rcvBusy || !S.order) return;
    var note = '';
    if (kind === 'reportIssue') { var ta = $('#mc-issue'); note = ta ? ta.value.trim() : ''; S.issueText = note; if (!note) { S.rcvErr = 'เล่าปัญหาสั้นๆ ก่อนส่งนะคะ'; return render(); } }
    S.rcvBusy = brand || '*'; S.rcvErr = ''; render();
    var img = S.order.img;
    api(kind, { id: S.order.id, brand: brand || '', note: note }).then(function (j) {
      S.rcvBusy = ''; S.issueFor = ''; S.issueText = '';
      S.order = j.order; S.order.img = img; S.orders = null; render();
    }).catch(function (err) { S.rcvBusy = ''; S.rcvErr = err.message; render(); });
  }
  var OFILTER = [['all', 'ทั้งหมด'], ['proc', 'กำลังดำเนินการ'], ['ship', 'จัดส่งแล้ว'], ['done', 'ได้รับแล้ว']];
  function viewOrders() {
    var h = header('ออเดอร์ของฉัน', '', false) + '<div class="mc-bd">';
    if (S.loadErr) return h + errBox(S.loadErr) + '</div>';
    if (!S.orders) return h + loading() + '</div>';
    var f = S.ofilter || 'all';
    h += '<div class="mc-chips">' + OFILTER.map(function (c) { return '<button class="mc-chip' + (f === c[0] ? ' on' : '') + '" data-a="ofilter" data-v="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div>';
    var list = S.orders.filter(function (o) {
      var s = stepOf(o);
      return f === 'all' || (f === 'proc' && s >= 0 && s < 3) || (f === 'ship' && s === 3) || (f === 'done' && s === 4);
    });
    if (!list.length) return h + '<p class="mc-empty">' + (S.orders.length ? 'ไม่มีออเดอร์ในหมวดนี้' : 'ยังไม่มีออเดอร์') + '</p></div>';
    list.forEach(function (o) {
      var st = stOf(o), btn = st === 'Slip Rejected' ? 'แนบสลิปใหม่' : (st === 'Shipped' || st === 'Partially Shipped') ? 'ยืนยันรับของ' : 'ติดตาม';
      h += '<button class="mc-card mc-oi" data-a="openOrder" data-id="' + esc(o.id) + '">' + pic(o) +
        '<span class="mc-col"><span class="mc-small">ออเดอร์ <span class="mc-id" style="font-size:12px">' + esc(o.id) + '</span></span><span class="mc-pill ' + (ST_CLS[st] || '') + '">' + esc(ST_LABEL[st] || st) + '</span>' +
        '<span class="mc-name">' + esc(o.name || '') + '</span><span class="mc-small">' + esc(thDate(o.createdAt)) + (o.tracking ? ' · เลขพัสดุ ' + esc(o.tracking) : o.eta && o.status !== 'Cancelled' && !o.received ? ' · คาดว่าได้รับ ' + esc(o.eta.label) : '') + '</span>' +
        '<span class="mc-row" style="align-items:center"><b>รวม ' + baht(o.total) + '</b><span class="mc-btns">' + btn + '</span></span></span></button>';
    });
    return h + '</div>';
  }

  /* ---------------- events ---------------- */
  function bind() {
    S.root.querySelectorAll('[data-a]').forEach(function (el) { el.addEventListener('click', onAction); });
    ['#mc-file', '#mc-cam'].forEach(function (id) { var file = $(id); if (file) file.addEventListener('change', onSlip); });
    var qr = $('#mc-qr'); if (qr && S.config && S.config.payment.promptpayId) drawQr(qr, S.config.payment.promptpayId, S.quote.price.total);
    if (S.view === 'checkout' && ADDR.ready) bindAddr();
  }
  function bindAddr() {
    var pc = $('#mc-postcode'), pv = $('#mc-province'), ds = $('#mc-district'), sd = $('#mc-subdistrict');
    if (!pc || !pv || !ds || !sd) return;   // ฟอร์มยังไม่ขึ้น (กำลังเช็กราคา / มี error) — ห้ามหยุดการเปิดหน้า
    var refresh = function () { readAddr(); render(); };
    pc.addEventListener('input', function () {
      pc.value = pc.value.replace(/\D/g, '').slice(0, 5);
      if (pc.value.length === 5) {
        readAddr();
        var hits = ADDR.byZip(pc.value), a = S.addr;
        if (hits.length) {
          var pick = function (k) { var u = uniq(hits.map(function (x) { return x[k]; })); return u.length === 1 ? u[0] : ''; };
          a.province = pick('province') || a.province; a.district = pick('amphoe') || (ADDR.districts(a.province, a.postcode).indexOf(a.district) >= 0 ? a.district : '');
          a.subdistrict = pick('district') || (ADDR.subdistricts(a.province, a.district, a.postcode).indexOf(a.subdistrict) >= 0 ? a.subdistrict : '');
        }
        render(); var f = hits.length && !S.addr.subdistrict ? $('#mc-subdistrict') : null; if (f) f.focus();
      }
    });
    pv.addEventListener('change', function () { readAddr(); S.addr.district = ''; S.addr.subdistrict = ''; if (S.addr.postcode && !ADDR.byZip(S.addr.postcode).some(function (x) { return x.province === S.addr.province; })) S.addr.postcode = ''; render(); });
    ds.addEventListener('change', function () { readAddr(); S.addr.subdistrict = ''; render(); });
    sd.addEventListener('change', function () {
      readAddr();
      var hit = ADDR.data.find(function (x) { return x.province === S.addr.province && x.amphoe === S.addr.district && x.district === S.addr.subdistrict; });
      if (hit) S.addr.postcode = String(hit.zipcode);
      render();
    });
    void refresh;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }

  function changeCart(sku, delta, remove) {
    readAddr();
    var next = S.items.map(cleanItem), i = next.findIndex(function (x) { return x.sku === sku; });
    if (i < 0) return;
    if (remove) next.splice(i, 1);
    else next[i].qty = Math.max(1, Math.min(5, next[i].qty + delta));
    S.items = next; writeCart(next); S.quote = null; S.loadErr = ''; S.formErr = '';
    if (!next.length) { close(); return; }
    render(); loadQuote();
  }

  function onAction(e) {
    var a = e.currentTarget.getAttribute('data-a');
    if (a === 'close') return close();
    if (a === 'back') return back();
    if (a === 'shopMore') return close();
    if (a === 'toCheckout') { if (S.needGate) return openGate(); S.formErr = ''; return go('checkout'); }
    if (a === 'addrEdit') { S.addrEdit = true; return render(); }
    if (a === 'ofilter') { S.ofilter = e.currentTarget.getAttribute('data-v'); return render(); }
    if (a === 'cartInc') return changeCart(e.currentTarget.getAttribute('data-sku'), 1, false);
    if (a === 'cartDec') return changeCart(e.currentTarget.getAttribute('data-sku'), -1, false);
    if (a === 'cartRemove') return changeCart(e.currentTarget.getAttribute('data-sku'), 0, true);
    if (a === 'toPay') {
      readAddr(); S.formErr = '';
      if (S.needGate) return openGate();
      var bad = validAddr();
      S.root.querySelectorAll('.mc-f').forEach(function (f) { f.classList.remove('bad'); });
      if (bad.length) {
        bad.forEach(function (b) { var f = $('#mcf-' + b[0]); if (f) f.classList.add('bad'); });
        S.formErr = 'กรุณาตรวจ: ' + bad.map(function (b) { return b[1]; }).join(', ');
        var box = S.root.querySelector('.mc-err'); if (box) box.textContent = S.formErr; else render();
        var first = $('#mc-' + bad[0][0]); if (first) first.focus();
        return;
      }
      S.reupload = false; S.payErr = ''; return go('pay');
    }
    if (a === 'pickSlip') { var f = $(e.currentTarget.getAttribute('data-v') === 'cam' ? '#mc-cam' : '#mc-file'); if (f) f.click(); return; }
    if (a === 'submit') return submit();
    if (a === 'saveQr') return saveQr();
    if (a === 'copy') {
      var btn = e.currentTarget, old = btn.textContent, done = function () { btn.textContent = 'คัดลอกแล้ว ✓'; setTimeout(function () { btn.textContent = old; }, 1500); };
      try { navigator.clipboard.writeText(btn.getAttribute('data-v')).then(done, done); } catch (er) { done(); }
      return;
    }
    if (a === 'gateGo') return S.loggedIn ? go('profile') : lineLogin();
    if (a === 'profEdit') { S.profOpen = S.profOpen || {}; S.profOpen[e.currentTarget.getAttribute('data-g')] = true; return render(); }
    if (a === 'prof') { var pg = e.currentTarget.getAttribute('data-g'); S.profAns[pg] = e.currentTarget.getAttribute('data-v'); return render(); }
    if (a === 'profPolicy') { S.profPolicy = !S.profPolicy; return render(); }
    if (a === 'profMkt') { S.profMkt = !S.profMkt; return render(); }
    if (a === 'profSave') return saveProfile();
    if (a === 'welcomeGo') { S.stack = []; S.view = ''; S.quote = null; go(S.cartMode ? 'cart' : 'checkout'); loadQuote(); return; }
    if (a === 'pref') {
      readAddr();
      var g = e.currentTarget.getAttribute('data-g'), val = e.currentTarget.getAttribute('data-v'), ans = S.prefAns;
      if (g === 'category') { var i = ans.category.indexOf(val); if (i >= 0) ans.category.splice(i, 1); else ans.category.push(val); }
      else ans[g] = ans[g] === val ? '' : val;
      return render();
    }
    if (a === 'copyTrk') { try { navigator.clipboard.writeText(e.currentTarget.getAttribute('data-v') || S.order.tracking); e.currentTarget.textContent = 'คัดลอกแล้ว'; } catch (er) {} return; }
    if (a === 'recv') return receiptAct('confirmReceived', e.currentTarget.getAttribute('data-b'));
    if (a === 'issueOpen') { S.issueFor = e.currentTarget.getAttribute('data-b') || '*'; S.issueText = ''; S.rcvErr = ''; render(); var ta = $('#mc-issue'); if (ta) ta.focus(); return; }
    if (a === 'issueCancel') { S.issueFor = ''; S.rcvErr = ''; return render(); }
    if (a === 'issueSend') return receiptAct('reportIssue', e.currentTarget.getAttribute('data-b'));
    if (a === 'orders') return MeraCheckout.openOrders(true);
    if (a === 'openOrder') return MeraCheckout.openOrder(e.currentTarget.getAttribute('data-id'), true);
    if (a === 'reupload') {
      S.reupload = true; S.slip = null; S.payErr = ''; S.orderedItems = [];
      S.quote = { price: { total: S.order.total } };
      return go('pay');
    }
  }

  function onSlip(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    S.payErr = '';
    compress(file).then(function (s) { S.slip = s; render(); }).catch(function () { S.payErr = 'อ่านรูปนี้ไม่ได้ ลองเลือกรูปใหม่ (JPG/PNG)'; render(); });
  }
  function compress(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var max = 1600, w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, max / Math.max(w, h));
        var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        var data = c.toDataURL('image/jpeg', 0.85);
        URL.revokeObjectURL(url);
        resolve({ name: file.name || 'slip.jpg', mime: 'image/jpeg', data: data.split(',')[1], preview: data });
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        if (file.size > 4.5 * 1024 * 1024) return reject(new Error('big'));
        var r = new FileReader();
        r.onload = function () { resolve({ name: file.name, mime: file.type || 'image/jpeg', data: String(r.result).split(',')[1], preview: String(r.result) }); };
        r.onerror = reject; r.readAsDataURL(file);
      };
      img.src = url;
    });
  }

  function submit() {
    if (!S.slip || S.busy) return;
    S.busy = true; S.payErr = ''; render();
    var slip = { mime: S.slip.mime, data: S.slip.data };
    var p = S.reupload
      ? api('reuploadSlip', { id: S.order.id, slip: slip })
      : S.cartMode
        ? api('createCartOrder', {
          items: S.items.map(function (x) { return { sku: x.sku, qty: x.qty }; }), expectedTotal: S.quote.price.total, clientRef: S.clientRef,
          customer: S.addr, saveAddress: S.saveAddr !== false, slip: slip, prefs: prefsPayload(),
        })
        : api('createOrder', {
          sku: S.item.sku, qty: S.quote.price.qty, expectedTotal: S.quote.price.total, clientRef: S.clientRef,
          customer: S.addr, saveAddress: S.saveAddr !== false, slip: slip, prefs: prefsPayload(),
        });
    p.then(function (j) {
      S.busy = false; S.slip = null;
      if (S.prefMissing && S.prefAns) S.prefMissing = S.prefMissing.filter(function (k) { return k === 'category' ? !S.prefAns.category.length : !S.prefAns[k]; });
      if (S.cartMode) {
        var local = {}; S.items.forEach(function (x) { local[x.sku] = x; });
        S.orderedItems = (S.quote.items || []).map(function (x) { return Object.assign({}, x, { img: (local[x.sku] || {}).img || x.img }); });
        writeCart([]);
      } else S.orderedItems = [];
      S.order = Object.assign({ img: S.cartMode ? ((S.orderedItems[0] || {}).img || '') : (S.item && S.item.img) || (S.order && S.order.img) }, j.order);
      remember(S.order);
      go('done');
      try { document.dispatchEvent(new CustomEvent('mera:order', { detail: S.order })); } catch (er) {}
    }).catch(function (err) {
      S.busy = false; S.payErr = err.message;
      if (err.code === 'PROFILE_REQUIRED') { S.needGate = true; return checkMember().then(function () { openGate(); }); }
      if (err.code === 'PRICE_CHANGED' || err.code === 'OUT_OF_STOCK' || err.code === 'CART_PROBLEM' || err.code === 'BAD_ADDRESS') {
        S.formErr = err.message; S.quote = null; go('checkout', true); S.stack = []; loadQuote();
      } else render();
    });
  }

  /* รูปสินค้าของออเดอร์ (เก็บในเครื่อง เพราะชีตไม่มีรูป) */
  function remember(o) { try { var m = JSON.parse(localStorage.getItem('mc_img') || '{}'); if (o.img) { m[o.id] = o.img; localStorage.setItem('mc_img', JSON.stringify(m)); } } catch (e) {} }
  function imgOf(id) { try { return JSON.parse(localStorage.getItem('mc_img') || '{}')[id] || ''; } catch (e) { return ''; } }

  /* ---------------- data loading ---------------- */
  function loadQuote() {
    S.loadErr = '';
    var req = S.cartMode
      ? api('quoteCart', { items: S.items.map(function (x) { return { sku: x.sku, qty: x.qty }; }) })
      : api('quote', { sku: S.item.sku, qty: S.item.qty || 1 });
    return req.then(function (q) {
      S.quote = q;
      if (!S.cartMode && !S.item.img && q.product && q.product.img) S.item.img = q.product.img;   // เว็บไม่ได้ส่งรูปมา → ใช้รูปจาก Product Database
      if (S.view === 'checkout' || S.view === 'cart') render();
    })
      .catch(function (err) { S.loadErr = err.message; if (S.view === 'checkout' || S.view === 'cart') render(); });
  }
  function loadConfig() {
    if (S.config) return Promise.resolve(S.config);
    return api('config').then(function (c) { S.config = c; return c; }).catch(function () { S.config = { payment: {} }; return S.config; });
  }
  function loadProfile() {
    if (S.addrLoaded) return Promise.resolve();
    return api('profile').then(function (j) {
      S.addrLoaded = true; S.profileName = j.name || '';
      readAddr();   // เก็บสิ่งที่ลูกค้าพิมพ์ไปแล้ว ไม่เขียนทับ
      var cur = S.addr || {}, src = j.address || { name: j.name || '' }, filled = false;
      Object.keys(src).forEach(function (k) { if (!cur[k] && src[k]) { cur[k] = String(src[k]); filled = true; } });
      S.addr = cur; if (j.address && filled) S.addrPrefilled = true;
      var pf = j.prefs || {};
      S.prefOptions = j.prefOptions || null;
      S.prefMissing = ['category', 'budget', 'size'].filter(function (k) { return !pf[k]; });
      if (S.view === 'checkout' && S.quote) render();
    }).catch(function (err) {
      if (/LINE/.test(err.message)) { S.loadErr = err.message; if (S.view === 'checkout') render(); }
    });
  }

  /* ---------------- Thai address database ---------------- */
  var ADDR = {
    ready: false, data: [], loading: null,
    load: function () {
      if (ADDR.loading) return ADDR.loading;
      ADDR.loading = fetch(CFG.addressDb).then(function (r) { return r.json(); }).then(function (rows) {
        ADDR.data = rows.map(function (x) { return { district: x.district, amphoe: x.amphoe, province: x.province, zipcode: String(x.zipcode) }; });
        ADDR.ready = ADDR.data.length > 100;
        if (S.view === 'checkout' && S.quote) { readAddr(); render(); }
      }).catch(function (e) { console.warn('mera-checkout: โหลดฐานข้อมูลที่อยู่ไม่ได้ ใช้ช่องพิมพ์แทน', e); });
      return ADDR.loading;
    },
    byZip: function (z) { return ADDR.data.filter(function (x) { return x.zipcode === z; }); },
    provinces: function (z) {
      var all = uniq(ADDR.data.map(function (x) { return x.province; })).sort(thSort);
      var bkk = 'กรุงเทพมหานคร'; all = [bkk].concat(all.filter(function (p) { return p !== bkk; }));
      void z; return all;
    },
    districts: function (p, z) {
      if (!p) return [];
      var rows = ADDR.data.filter(function (x) { return x.province === p; });
      var byZ = /^\d{5}$/.test(z || '') ? rows.filter(function (x) { return x.zipcode === z; }) : [];
      return uniq((byZ.length ? byZ : rows).map(function (x) { return x.amphoe; })).sort(thSort);
    },
    subdistricts: function (p, d, z) {
      if (!p || !d) return [];
      var rows = ADDR.data.filter(function (x) { return x.province === p && x.amphoe === d; });
      var byZ = /^\d{5}$/.test(z || '') ? rows.filter(function (x) { return x.zipcode === z; }) : [];
      return uniq((byZ.length ? byZ : rows).map(function (x) { return x.district; })).sort(thSort);
    },
  };
  function thSort(a, b) { return a.localeCompare(b, 'th'); }

  /* ---------------- PromptPay QR (EMVCo) ---------------- */
  function promptpayPayload(id, amount) {
    var f = function (tag, v) { return tag + String(v.length).padStart(2, '0') + v; };
    var t = String(id).replace(/\D/g, ''), acc;
    if (t.length >= 15) acc = f('03', t);
    else if (t.length >= 13) acc = f('02', t);
    else acc = f('01', ('0000000000000' + t.replace(/^0/, '66')).slice(-13));
    var s = f('00', '01') + f('01', amount ? '12' : '11') + f('29', f('00', 'A000000677010111') + acc) + f('53', '764') +
      (amount ? f('54', Number(amount).toFixed(2)) : '') + f('58', 'TH') + '6304';
    return s + crc16(s);
  }
  function crc16(s) {
    var crc = 0xFFFF;
    for (var i = 0; i < s.length; i++) { crc ^= s.charCodeAt(i) << 8; for (var j = 0; j < 8; j++) crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1; crc &= 0xFFFF; }
    return crc.toString(16).toUpperCase().padStart(4, '0');
  }
  function drawQr(el, id, amount) {
    var m = QR.make(promptpayPayload(id, amount)), n = m.length, q = 4, scale = 8;
    var c = document.createElement('canvas'); c.width = c.height = (n + q * 2) * scale;
    var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#000';
    for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (m[y][x]) g.fillRect((x + q) * scale, (y + q) * scale, scale, scale);
    el.innerHTML = ''; el.appendChild(c); S.qrCanvas = c;
  }
  function prefsPayload() {
    if (!CFG.askPrefs) return null;
    var a = S.prefAns || {}, o = {};
    if (a.category && a.category.length) o.category = a.category.join(', ');
    if (a.budget) o.budget = a.budget;
    if (a.size) o.size = a.size;
    return Object.keys(o).length ? o : null;
  }
  function saveQr() {
    var name = 'mera-qr-' + S.quote.price.total + '.png';
    var dl = function (href) { var a = document.createElement('a'); a.download = name; a.href = href; document.body.appendChild(a); a.click(); a.remove(); };
    if (S.qrCanvas) return dl(S.qrCanvas.toDataURL('image/png'));
    var pic = $('#mc-qrpic'); if (!pic) return;
    // รูป QR จากลิงก์ภายนอก: ลองดาวน์โหลด ถ้าเว็บต้นทางไม่ยอม → เปิดรูปให้กดค้างบันทึก
    fetch(pic.src, { mode: 'cors' }).then(function (r) { return r.blob(); })
      .then(function (b) { var u = URL.createObjectURL(b); dl(u); setTimeout(function () { URL.revokeObjectURL(u); }, 4000); })
      .catch(function () { window.open(pic.src, '_blank'); });
  }

  /* QR Code generator (byte mode, ECC M, version 1–10) */
  var QR = (function () {
    var EC = [0, [10, 1, 16, 0, 0], [16, 1, 28, 0, 0], [26, 1, 44, 0, 0], [18, 2, 32, 0, 0], [24, 2, 43, 0, 0], [16, 4, 27, 0, 0], [18, 4, 31, 0, 0], [22, 2, 38, 2, 39], [22, 3, 36, 2, 37], [26, 4, 43, 1, 44]];
    var ALIGN = [0, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
    function mul(x, y) { var z = 0; for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 0xFF; }
    function divisor(deg) { var r = []; for (var i = 0; i < deg - 1; i++) r.push(0); r.push(1); var root = 1; for (i = 0; i < deg; i++) { for (var j = 0; j < r.length; j++) { r[j] = mul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = mul(root, 2); } return r; }
    function remainder(data, div) { var r = div.map(function () { return 0; }); data.forEach(function (b) { var f = b ^ r.shift(); r.push(0); div.forEach(function (c, i) { r[i] ^= mul(c, f); }); }); return r; }
    function utf8(s) { var out = [], b = unescape(encodeURIComponent(s)); for (var i = 0; i < b.length; i++) out.push(b.charCodeAt(i)); return out; }
    function make(text) {
      var data = utf8(text), ver, e;
      for (ver = 1; ver <= 10; ver++) { e = EC[ver]; var cap = e[1] * e[2] + e[3] * e[4]; if (4 + (ver < 10 ? 8 : 16) + data.length * 8 <= cap * 8) break; }
      if (ver > 10) throw new Error('QR data too long');
      var cap8 = (e[1] * e[2] + e[3] * e[4]), bits = [];
      var push = function (v, n) { for (var i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); };
      push(4, 4); push(data.length, ver < 10 ? 8 : 16); data.forEach(function (b) { push(b, 8); });
      push(0, Math.min(4, cap8 * 8 - bits.length)); while (bits.length % 8) bits.push(0);
      var cw = []; for (var i = 0; i < bits.length; i += 8) cw.push(parseInt(bits.slice(i, i + 8).join(''), 2));
      for (var pad = 0xEC; cw.length < cap8; pad ^= 0xEC ^ 0x11) cw.push(pad);
      var blocks = [], ecb = [], k = 0, div = divisor(e[0]);
      for (i = 0; i < e[1] + e[3]; i++) { var len = i < e[1] ? e[2] : e[4]; var b = cw.slice(k, k + len); k += len; blocks.push(b); ecb.push(remainder(b, div)); }
      var all = [], maxLen = Math.max(e[2], e[4]);
      for (i = 0; i < maxLen; i++) blocks.forEach(function (b) { if (i < b.length) all.push(b[i]); });
      for (i = 0; i < e[0]; i++) ecb.forEach(function (b) { all.push(b[i]); });

      var n = ver * 4 + 17, mod = [], fn = [];
      for (i = 0; i < n; i++) { mod.push(new Array(n).fill(false)); fn.push(new Array(n).fill(false)); }
      var set = function (x, y, d) { mod[y][x] = !!d; fn[y][x] = true; };
      for (i = 0; i < n; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
      [[3, 3], [n - 4, 3], [3, n - 4]].forEach(function (c) {
        for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
          var x = c[0] + dx, y = c[1] + dy; if (x < 0 || y < 0 || x >= n || y >= n) continue;
          var d = Math.max(Math.abs(dx), Math.abs(dy)); set(x, y, d !== 2 && d !== 4);
        }
      });
      var al = ALIGN[ver];
      al.forEach(function (ax, ii) { al.forEach(function (ay, jj) {
        if ((ii === 0 && jj === 0) || (ii === 0 && jj === al.length - 1) || (ii === al.length - 1 && jj === 0)) return;
        for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
      }); });
      var drawFormat = function (mask) {
        var d = (0 << 3) | mask, rem = d; for (var t = 0; t < 10; t++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        var fb = ((d << 10) | rem) ^ 0x5412, bit = function (t) { return (fb >>> t) & 1; };
        for (t = 0; t <= 5; t++) set(8, t, bit(t));
        set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8));
        for (t = 9; t < 15; t++) set(14 - t, 8, bit(t));
        for (t = 0; t < 8; t++) set(n - 1 - t, 8, bit(t));
        for (t = 8; t < 15; t++) set(8, n - 15 + t, bit(t));
        set(8, n - 8, true);
      };
      drawFormat(0);
      if (ver >= 7) {
        var rem = ver; for (i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
        var vb = (ver << 12) | rem;
        for (i = 0; i < 18; i++) { var bt = (vb >>> i) & 1, a = n - 11 + i % 3, bb = Math.floor(i / 3); set(a, bb, bt); set(bb, a, bt); }
      }
      var bi = 0;
      for (var right = n - 1; right >= 1; right -= 2) {
        if (right === 6) right = 5;
        for (var vert = 0; vert < n; vert++) for (var j = 0; j < 2; j++) {
          var x = right - j, up = ((right + 1) & 2) === 0, y = up ? n - 1 - vert : vert;
          if (!fn[y][x] && bi < all.length * 8) { mod[y][x] = ((all[bi >>> 3] >>> (7 - (bi & 7))) & 1) === 1; bi++; }
        }
      }
      var MASK = [function (x, y) { return (x + y) % 2 === 0; }, function (x, y) { return y % 2 === 0; }, function (x) { return x % 3 === 0; },
        function (x, y) { return (x + y) % 3 === 0; }, function (x, y) { return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; },
        function (x, y) { return x * y % 2 + x * y % 3 === 0; }, function (x, y) { return (x * y % 2 + x * y % 3) % 2 === 0; },
        function (x, y) { return ((x + y) % 2 + x * y % 3) % 2 === 0; }];
      var apply = function (mk) { for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) if (!fn[y][x] && MASK[mk](x, y)) mod[y][x] = !mod[y][x]; };
      var penalty = function () {
        var p = 0, dark = 0, x, y, run, prev;
        for (y = 0; y < n; y++) { run = 0; prev = null; for (x = 0; x < n; x++) { if (mod[y][x] === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else { run = 1; prev = mod[y][x]; } if (mod[y][x]) dark++; } }
        for (x = 0; x < n; x++) { run = 0; prev = null; for (y = 0; y < n; y++) { if (mod[y][x] === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else { run = 1; prev = mod[y][x]; } } }
        for (y = 0; y < n - 1; y++) for (x = 0; x < n - 1; x++) { var c = mod[y][x]; if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3; }
        // ลายคล้าย finder (1:1:3:1:1 + ขาว 4) ทำให้เครื่องสแกนสับสน
        var at = function (yy, xx) { return yy >= 0 && xx >= 0 && yy < n && xx < n && mod[yy][xx]; };
        var F = [1, 0, 1, 1, 1, 0, 1], hit = function (get) {
          for (var s = -4; s < n; s++) {
            var okF = true, k2;
            for (k2 = 0; k2 < 7 && okF; k2++) if (!!get(s + k2) !== !!F[k2]) okF = false;
            if (!okF) continue;
            var before = true, after = true;
            for (k2 = 1; k2 <= 4; k2++) { if (get(s - k2)) before = false; if (get(s + 6 + k2)) after = false; }
            if (before || after) p += 40;
          }
        };
        for (y = 0; y < n; y++) hit(function (xx) { return at(y, xx); });
        for (x = 0; x < n; x++) hit(function (yy) { return at(yy, x); });
        return p + Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
      };
      var best = 0, bestP = Infinity;
      for (var mk = 0; mk < 8; mk++) { apply(mk); drawFormat(mk); var pp = penalty(); if (pp < bestP) { bestP = pp; best = mk; } apply(mk); }
      apply(best); drawFormat(best);
      return mod;
    }
    return { make: make };
  })();

  /* ---------------- public API ---------------- */
  function startCheckout(items, cartMode) {
    show();
    S.cartMode = !!cartMode; S.items = (items || []).map(cleanItem).filter(function (x) { return x.sku; });
    S.item = S.cartMode ? null : S.items[0]; S.quote = null; S.loadErr = ''; S.formErr = ''; S.slip = null; S.busy = false;
    S.clientRef = uuid(); S.stack = []; S.orderedItems = [];
    if (!S.prefAns) S.prefAns = { category: [], budget: '', size: '' };
    S.view = ''; S.addrEdit = false; go(S.cartMode ? 'cart' : 'checkout');
    loadQuote(); loadConfig(); loadProfile(); ADDR.load();
    var ref = S.clientRef;
    checkMember().then(function (okToBuy) {
      if (ref !== S.clientRef || S.ov.hidden) return;        // ปิดไปแล้ว / เปิดรอบใหม่
      if (!okToBuy && S.view === 'checkout') openGate();
    });
  }
  var MeraCheckout = {
    open: function (item) {
      if (!item || !item.sku) throw new Error('MeraCheckout.open ต้องมี sku');
      startCheckout([item], false);
    },
    add: function (item, opts) {
      if (!item || !item.sku) throw new Error('MeraCheckout.add ต้องมี sku');
      var items = mergeCartItem(item);
      if (opts && opts.open === false) return items.reduce(function (n, x) { return n + x.qty; }, 0);
      startCheckout(items, true);
    },
    openCart: function (items) {
      if (Array.isArray(items)) writeCart(items);
      var cart = Array.isArray(items) ? items.map(cleanItem).filter(function (x) { return x.sku; }) : readCart();
      if (!cart.length) return;
      startCheckout(cart, true);
    },
    cartCount: function () {
      return readCart().reduce(function (n, x) { return n + x.qty; }, 0);
    },
    clearCart: function () {
      writeCart([]);
    },
    openOrders: function (fromInside) {
      show(); if (!fromInside) S.stack = [];
      S.orders = null; S.loadErr = ''; S.view = fromInside ? S.view : ''; go('orders');
      api('myOrders').then(function (j) { S.orders = j.orders.map(function (o) { o.img = imgOf(o.id); return o; }); if (S.view === 'orders') render(); })
        .catch(function (err) { S.loadErr = err.message; if (S.view === 'orders') render(); });
    },
    openOrder: function (id, fromInside) {
      show(); if (!fromInside) S.stack = [];
      S.order = null; S.loadErr = ''; S.issueFor = ''; S.rcvErr = ''; S.rcvBusy = ''; S.view = fromInside ? S.view : ''; go('order');
      loadConfig();
      api('order', { id: id }).then(function (j) { S.order = j.order; S.order.img = imgOf(j.order.id); if (S.view === 'order') render(); })
        .catch(function (err) { S.loadErr = err.message; if (S.view === 'order') render(); });
    },
    close: close,
    _qr: function (t) { return QR.make(t); }, _promptpay: promptpayPayload,
  };
  window.MeraCheckout = MeraCheckout;
  mount(); updateCartFab();

  // ลิงก์จากการ์ด LINE: ?order=MO-0001 → เปิดหน้าสถานะ (รอ LIFF พร้อมก่อน)
  function resumeAfterLogin() {
    var raw = null;
    try { raw = sessionStorage.getItem('mc_resume'); sessionStorage.removeItem('mc_resume'); } catch (e) {}
    if (!raw) return false;
    var r; try { r = JSON.parse(raw); } catch (e) { return false; }
    if (!r || !r.items || !r.items.length) return false;
    var tries = 0;
    (function wait() {
      if (CFG.testUserId || CFG.getIdToken() || tries++ > 40) return startCheckout(r.items, !!r.cart);
      setTimeout(wait, 250);
    })();
    return true;
  }
  function autoOpen() {
    if (resumeAfterLogin()) return;
    var m = /[?&]order=([A-Z]{2}-\d+)/.exec(location.search + '&' + (location.hash || '').replace(/^#/, ''));
    if (!m) return;
    var tries = 0;
    (function wait() {
      var ready = CFG.testUserId || CFG.getIdToken();
      if (ready || tries++ > 40) return MeraCheckout.openOrder(m[1]);
      setTimeout(wait, 250);
    })();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', autoOpen); else autoOpen();
  try { document.dispatchEvent(new CustomEvent('mera:checkout-ready')); } catch (e) {}
})();
