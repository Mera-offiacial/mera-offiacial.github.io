/* Mera Catalog v2 */

let BRANDS = [
  { id: 'kome', name: 'Komé', logo: 'img/e92d0a1028d3.jpg' },
  { id: 'midnight', name: 'Midnight Lullabyy', logo: 'img/3313a9229eb6.jpg' },
  { id: 'narris', name: 'Narris', logo: 'img/86b2978332f9.jpg' },
  { id: 'sonthaya', name: 'Sonthaya Plussize', logo: 'img/28a1a1549a99.jpg' }
];
const CAT = { 'กระโปรง': 'กระโปรง', 'เสื้อ': 'เสื้อ', 'กระเป๋า': 'กระเป๋า', 'สูท': 'สูท' };
// หมวดที่ความหมายซ้ำกัน รวมเป็นหมวดเดียว (เสื้อผ้า = เสื้อ)
const CAT_MERGE = { 'เสื้อผ้า': 'เสื้อ', 'เสื้อยืด': 'เสื้อ', 'Tops': 'เสื้อ' };
const normCat = c => { const t = String(c || '').trim(); return CAT_MERGE[t] || t || 'อื่นๆ'; };
const HEX = { 'สีดำ': '#1f1a1b', 'สีเทา': '#8a8686', 'สีขาว': '#f4f1ea', 'สีชมพู': '#f2b8c6', 'เทา': '#8a8686', 'ชมพู': '#f2b8c6', 'แดง': '#a3262a', 'Fruity': '#9bcf6a', 'Blueberry yogurt': '#c9c3d9', 'Birthday cake': '#e7a3c4', 'Caramel Suede': '#b07a4a', 'Brown': '#6b4430', 'สีน้ำตาลหนัง PU': '#5a3a2a', 'สีเงิน PU': '#c0c0c4', 'สีคาราเมล หนังกลับ': '#b07a4a', 'หนังกลับ': '#7a5236', 'น้ำตาล': '#6b4430', 'ฟ้า': '#9cc3e4', 'ครีม': '#efe4cf', 'สีฟ้า PU': '#9cc3e4', 'สีน้ำตาล': '#6b4430', 'สีเทาเข้ม': '#4a4d4f', 'สีเทาอ่อน': '#b9bbbb', 'สีกรม': '#1f2a44', 'Navy': '#1f2a44', 'Red': '#a3262a' };
const grid = (start, colors, sizes) => { const out = []; let n = start; colors.forEach(c => sizes.forEach(s => out.push([c, s, 'MRA' + String(n++).padStart(3, '0')]))); return out; };
let PRODUCTS = [
  { id: 'ruby', brand: 'kome', name: 'Ruby skirt', cat: 'กระโปรง', v: grid(33, ['สีดำ', 'สีเทา'], ['S', 'M', 'L']), imgs: { 'สีดำ': 'img/fdc4b58789ac.jpg', 'สีเทา': 'img/671b43f8f86b.jpg' }, extra: ['img/dd4fa86d3ff3.jpg', 'img/b4b84ff89ab9.jpg'] },
  { id: '1984', brand: 'kome', name: '1984 club t-shirt', cat: 'เสื้อ', v: grid(39, ['สีดำ', 'สีขาว', 'สีชมพู'], ['S', 'M', 'L']), imgs: { 'สีดำ': 'img/0d535eb164bd.jpg', 'สีขาว': 'img/754e909c897c.jpg', 'สีชมพู': 'img/9f4682d81fac.jpg' } },
  { id: 'sporty', brand: 'kome', name: 'Sporty t-shirt', cat: 'เสื้อ', v: grid(48, ['สีขาว'], ['S', 'M', 'L']), img: 'img/f22a4eae8f9c.jpg', extra: ['img/d1554bc36fad.jpg'] },
  { id: 'hailey', brand: 'kome', name: 'Hailey top', cat: 'เสื้อ', v: grid(51, ['เทา', 'ชมพู', 'แดง'], ['S', 'M', 'L', 'XL', '2XL']), imgs: { 'เทา': 'img/fb48cd89ae8d.jpg', 'ชมพู': 'img/2dfe0d1d78f4.jpg', 'แดง': 'img/e1a248ad9a74.jpg' }, extra: ['img/87d5987c9802.jpg'] },
  { id: 'sweater', brand: 'kome', name: 'Breathtaking Sweater', cat: 'เสื้อ', v: [['Navy', 'Free size', 'MRA028'], ['Red', 'Free size', 'MRA029']], imgs: { 'Navy': 'img/31f161d6ed56.jpg', 'Red': 'img/8e6887d7866b.jpg' }, extra: ['img/55c9c31dd5c8.jpg'] },
  { id: 'florenz', brand: 'midnight', name: 'MNL florenz halter top', cat: 'เสื้อ', v: [['Fruity', 'Free size', 'MRA067'], ['Blueberry yogurt', 'Free size', 'MRA068'], ['Birthday cake', 'Free size', 'MRA069']], imgs: { 'Fruity': 'img/8e78f58491bd.jpg', 'Blueberry yogurt': 'img/f01ca8d5c8ef.jpg', 'Birthday cake': 'img/5b15a6973ad2.jpg' }, extra: ['img/18cff3192a44.jpg', 'img/bdaf7a4b9382.jpg', 'img/576c06ec6833.jpg'] },
  { id: 'daily', brand: 'narris', name: 'Daily Tote', cat: 'กระเป๋า', v: [['Caramel Suede', '', 'MRA076']], img: 'img/5d3a87fceb22.jpg' },
  { id: 'journey', brand: 'narris', name: 'Journey', cat: 'กระเป๋า', v: [['Brown', '', 'MRA077']], img: 'img/75f61181ffcf.jpg' },
  { id: 'hobo', brand: 'narris', name: 'Hobo Bag', cat: 'กระเป๋า', v: [['สีน้ำตาลหนัง PU', '', 'MRA078'], ['สีเงิน PU', '', 'MRA079'], ['สีคาราเมล หนังกลับ', '', 'MRA080']], imgs: { 'สีน้ำตาลหนัง PU': 'img/a8a76849213d.jpg', 'สีเงิน PU': 'img/b2c6857108b8.jpg', 'สีคาราเมล หนังกลับ': 'img/f156849b8a56.jpg' } },
  { id: 'soul', brand: 'narris', name: 'Soul Soul', cat: 'กระเป๋า', v: [['หนังกลับ', '', 'MRA081']], img: 'img/c2df53b9b896.jpg' },
  { id: 'merlin', brand: 'narris', name: 'Merlin', cat: 'กระเป๋า', v: [['แดง', '', 'MRA082'], ['น้ำตาล', '', 'MRA083']], imgs: { 'แดง': 'img/4f1bff9319f7.jpg', 'น้ำตาล': 'img/c8b497510a84.jpg' } },
  { id: 'shadow', brand: 'narris', name: 'Shadow', cat: 'กระเป๋า', v: [['แดง', '', 'MRA084'], ['น้ำตาล', '', 'MRA085'], ['ฟ้า', '', 'MRA086']], imgs: { 'แดง': 'img/ca669d8ad835.jpg', 'น้ำตาล': 'img/dc72fcb5ad3f.jpg', 'ฟ้า': 'img/41987a059e82.jpg' } },
  { id: 'slay', brand: 'narris', name: 'Slay', cat: 'กระเป๋า', v: [['แดง', '', 'MRA087']], img: 'img/21a2105779ea.jpg' },
  { id: 'jolie', brand: 'narris', name: 'Jolie bag', cat: 'กระเป๋า', v: [['ฟ้า', '', 'MRA088'], ['ครีม', '', 'MRA089']], imgs: { 'ฟ้า': 'img/7af2ca7b02cd.jpg', 'ครีม': 'img/0ef6fb3188ed.jpg' } },
  { id: 'boston', brand: 'narris', name: 'Soft boston', cat: 'กระเป๋า', v: [['สีฟ้า PU', '', 'MRA090'], ['สีน้ำตาล', '', 'MRA091']], imgs: { 'สีฟ้า PU': 'img/98dbece7f04c.jpg', 'สีน้ำตาล': 'img/06d3ee8de383.jpg' } },
  { id: 'suit', brand: 'sonthaya', name: 'Formal suit', cat: 'สูท', v: [['สีดำ', '20', 'MRA096'], ['สีเทาเข้ม', '20', 'MRA097'], ['สีเทาอ่อน', '20', 'MRA098'], ['สีกรม', '20', 'MRA099']], imgs: { 'สีดำ': 'img/df7681d90336.jpg', 'สีเทาเข้ม': 'img/74c5942a7990.jpg', 'สีเทาอ่อน': 'img/568f8467635e.jpg', 'สีกรม': 'img/7aecc45b39b7.jpg' } }
];
const TEE = ['S – อก 32-35" ยาว 18" ยาวแขน 5" รอบแขน 14"', 'M – อก 34-36" ยาว 18" ยาวแขน 5" รอบแขน 14"', 'L – อก 35-38" ยาว 18.5" ยาวแขน 5.2" รอบแขน 15"'];
let DETAIL = {
  ruby: ['S – เอว 23-24" สะโพก 33-34" ยาว 15"', 'M – เอว 25-26" สะโพก 35-36" ยาว 15"', 'L – เอว 27-28" สะโพก 37-38" ยาว 16"'],
  '1984': TEE, sporty: TEE,
  hailey: ['S – chest 22-32" length 9"', 'M – chest 23-34" length 9.5"', 'L – chest 24-37" length 10"', 'XL – chest 26-40" length 10.5"', '2XL – chest 27-43" length 11.5"'],
  sweater: ['Freesize – อกไม่เกิน 48" ยาว 28" ยาวแขน 30" วงแขน 18"'],
  florenz: ['Free size – อก 28-38 นิ้ว ยาว 18 นิ้ว', 'เนื้อผ้า: ไหมพรม'],
  suit: ['Size 20 – อก 44-48 นิ้ว | เอว 40 นิ้ว | รอบแขน 22 นิ้ว | ไหล่ 17-18 นิ้ว | สะโพก 46-48 นิ้ว | ยาว 27', 'ใส่ตามไซส์ได้เลย ไม่ต้องเผื่อ เป็นไซส์ของผู้ใส่']
};
let STOCK = {"MRA033":5,"MRA034":5,"MRA035":5,"MRA036":5,"MRA037":5,"MRA038":5,"MRA039":5,"MRA040":5,"MRA041":5,"MRA042":5,"MRA043":5,"MRA044":5,"MRA045":5,"MRA046":5,"MRA047":5,"MRA048":5,"MRA049":5,"MRA050":5,"MRA051":3,"MRA052":3,"MRA053":3,"MRA054":3,"MRA055":3,"MRA056":3,"MRA057":3,"MRA058":3,"MRA059":3,"MRA060":3,"MRA061":3,"MRA062":3,"MRA063":3,"MRA064":3,"MRA065":3,"MRA066":10,"MRA028":5,"MRA029":5,"MRA067":8,"MRA068":8,"MRA069":8,"MRA076":6,"MRA077":3,"MRA078":19,"MRA079":24,"MRA080":12,"MRA081":12,"MRA082":25,"MRA083":19,"MRA084":13,"MRA085":12,"MRA086":3,"MRA087":8,"MRA088":60,"MRA089":17,"MRA090":70,"MRA091":15,"MRA096":3,"MRA097":2,"MRA098":2,"MRA099":2};
let DEALS = {
  boston: { code: 'C001', colors: ['สีน้ำตาล'], price: 400, orig: 990, tiers: [[5, 400], [10, 300]], close: '29 ก.ย. 21:00', deposit: 100, gal: ['img/06d3ee8de383.jpg'] },
  ruby: { code: 'C002', colors: ['สีดำ', 'สีเทา'], price: 200, orig: 520, tiers: [[5, 200], [10, 150]], close: '1 ต.ค. 23:00', deposit: 100, gal: ['img/b4b84ff89ab9.jpg', 'img/dd4fa86d3ff3.jpg', 'img/671b43f8f86b.jpg'] },
  florenz: { code: 'C003', colors: ['Fruity', 'Blueberry yogurt', 'Birthday cake'], price: 300, orig: 380, tiers: [[3, 300]], close: '30 ก.ย. 23:00', deposit: 100, gal: ['img/8e78f58491bd.jpg', 'img/f01ca8d5c8ef.jpg', 'img/5b15a6973ad2.jpg'] }
};
const COMING = new Set([]);
const HOW = [['img/438a22588592.jpg', 'ช้อปแฟชั่นแบรนด์ไทยในราคาคุ้มค่า'], ['img/645cda63cf99.jpg', 'ขั้นตอนซื้อสินค้ากับ Mera'], ['img/14a93e3821a5.jpg', 'ขั้นตอน 1–2'], ['img/f995c1945450.jpg', 'ขั้นตอน 3–4'], ['img/29bdeaa88701.jpg', 'ขั้นตอน 5–6']];
const stockOf = sku => STOCK[sku] ?? 0;
const uniq = a => [...new Set(a)];
const TINT = { 'กระเป๋า': '#F3EBE1', 'สูท': '#EFEAE4' };
const SORTS = [['brand', 'แบรนด์'], ['name', 'ชื่อ A–Z'], ['stock', 'มีของเยอะสุด']];
function scrollGal(id, i, instant) { const el = document.getElementById(id); if (el) el.scrollTo({ left: i * el.clientWidth, behavior: instant ? 'auto' : 'smooth' }); }
function copyText(t, done) {
  const fb = () => { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); done(); } catch (_) {} a.remove(); };
  try { navigator.clipboard.writeText(t).then(done, fb); } catch (_) { fb(); }
}


// ===== Live data from Google Sheet (Apps Script Web App) =====
// วาง URL ของ Web App ตรงนี้ (หรือใส่ใน prop "apiUrl")
const API_URL = 'https://script.google.com/macros/s/AKfycbyLpV_gCumuBu616iKD8eA7PvwiaHMRX21nY0ePnDGuh9YyQ_NJBfh46pgsf9IRhH1vQg/exec';
const LIVE_CACHE = 'mera-catalog-live-v1';
const LIVE_REFRESH_MS = 60000;
// แบรนด์ทดสอบ ไม่แสดงบนเว็บ (พิมพ์ชื่อตาม Brand Master)
const EXCLUDE_BRANDS = ['Manitui'];
const LEGACY = { brands: BRANDS, products: PRODUCTS, detail: DETAIL, deals: DEALS };
const LEGACY_BRAND = { 'kome.offi': 'kome', 'kome': 'kome', 'komé': 'kome', 'midnight.lullabyy': 'midnight', 'narris': 'narris', 'sonthaya plus size': 'sonthaya', 'sonthaya plussize': 'sonthaya' };
const norm = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
const hashId = s => { let h = 5381; for (const ch of s) h = ((h * 33) ^ ch.codePointAt(0)) >>> 0; return h.toString(36); };
// รูปจาก Google Drive: ขอขนาดตามที่แสดงจริง (เดิมขอ =w1000 ทุกที่)
const LH3 = /^(https:\/\/lh3\.googleusercontent\.com\/d\/[^=?#\s]+)(=[^?#\s]*)?$/;
const imgW = (u, w) => { const m = LH3.exec(String(u || '')); return m ? m[1] + '=w' + w : u; };
const BLANK_IMG = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
const svgData = svg => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
const monogram = name => {
  const ch = (String(name).match(/[A-Za-z0-9ก-ฮ]/) || ['•'])[0].toUpperCase();
  return svgData(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#FCE4E8"/><text x="32" y="42" text-anchor="middle" font-family="Poppins,Prompt,sans-serif" font-size="26" font-weight="700" fill="#841132">${ch}</text></svg>`);
};
const PLACEHOLDER = svgData('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#FCE4E8"/><text x="50" y="56" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="800" font-size="16" fill="#841132" opacity="0.5">MERA</text></svg>');
Object.assign(HEX, { 'ดำ': '#1f1a1b', 'ขาว': '#f4f1ea', 'น้ำเงิน': '#2b3f7a', 'เหลือง': '#f2d36b', 'เขียว': '#6f9b62', 'ม่วง': '#8d6fb0', 'ส้ม': '#e8925a', 'เบจ': '#d9c4a5', 'กากี': '#b5a37a', 'Navy blue': '#1f2a44', 'Black': '#1f1a1b', 'White': '#f4f1ea', 'Blue': '#9cc3e4', 'Pink': '#f2b8c6', 'Grey': '#8a8686', 'Gray': '#8a8686', 'Green': '#6f9b62', 'Yellow': '#f2d36b', 'Cream': '#efe4cf' });
const HEX_KEYS = () => Object.keys(HEX).sort((a, b) => b.length - a.length);
function hexOf(c) {
  if (!c) return '#ccc';
  if (HEX[c]) return HEX[c];
  const lc = c.toLowerCase(), k = HEX_KEYS().find(k => lc.includes(k.toLowerCase()));
  return k ? HEX[k] : '#ccc';
}
const dealLink = d => d.link || ('https://mera-deal.netlify.app/' + d.code);

// ปุ่มซื้อเลย: ใช้ได้เมื่อโหลด mera-checkout.js แล้ว และตั้งลิงก์ API แล้ว
const checkoutOn = () => !!(window.MeraCheckout && window.MERA_CHECKOUT && window.MERA_CHECKOUT.api);
// ราคาขายต่อชิ้นจากชีต (Sale Price / Original Price ต่อ SKU)
let PRICE = {};
const baht = n => Number(n).toLocaleString('th-TH') + ' บาท';
function priceOfSku(sku) { const x = PRICE[sku]; return x && x.price > 0 ? x : null; }
function priceRange(p) {
  const ps = p.v.map(x => priceOfSku(x[2])).filter(Boolean);
  if (!ps.length) return null;
  const min = Math.min(...ps.map(x => x.price)), max = Math.max(...ps.map(x => x.price));
  const origs = ps.filter(x => x.price === min).map(x => x.orig).filter(o => o > min);
  return { label: (min !== max ? 'เริ่ม ' : '') + baht(min), orig: origs.length ? baht(Math.max(...origs)) : '' };
}
function applyLive(data) {
  if (!data || !Array.isArray(data.products) || !data.products.length) return false;
  const legacyB = Object.fromEntries(LEGACY.brands.map(b => [b.id, b]));
  const legacyP = {}; LEGACY.products.forEach(p => { legacyP[p.brand + '|' + norm(p.name)] = p; });
  const brandIdOf = name => LEGACY_BRAND[norm(name)] || ('b' + hashId(norm(name)));
  const brands = [], byId = {};
  const addBrand = (name, display, logo) => {
    const id = brandIdOf(name);
    if (!byId[id]) {
      const lb = legacyB[id];
      const ov = (IMGX.brands || {})[norm(name)];
      byId[id] = { id, name: display || (lb && lb.name) || name, logo: ov || logo || (lb && lb.logo) || monogram(display || name), ovLogo: !!ov };
      brands.push(byId[id]);
    } else if (logo && !byId[id].ovLogo && byId[id].logo.startsWith('data:image/svg')) byId[id].logo = logo;
    return id;
  };
  const hidden = new Set(EXCLUDE_BRANDS.map(norm));
  (data.brands || []).filter(b => !hidden.has(norm(b.name))).forEach(b => addBrand(b.name, b.display, b.logo));

  const products = [], stock = {}, detail = {}, bySku = {}, price = {};
  data.products.forEach(lp => {
    if (!lp.variants || !lp.variants.length || hidden.has(norm(lp.brand))) return;
    const bid = addBrand(lp.brand);
    const leg = legacyP[bid + '|' + norm(lp.name)];
    const id = leg ? leg.id : 'p' + hashId(norm(lp.brand) + '|' + norm(lp.name));
    const p = { id, brand: bid, name: lp.name, cat: normCat(lp.cat), v: lp.variants.map(x => [x.color || '', x.size || '', x.sku]) };
    lp.variants.forEach(x => { stock[x.sku] = Math.max(0, +x.stock || 0); bySku[x.sku] = p; price[x.sku] = { price: +x.price || 0, orig: +x.orig || 0 }; });
    if (lp.images && lp.images.length) { p.img = lp.images[0]; p.extra = lp.images.slice(1); if (lp.colorImages && Object.keys(lp.colorImages).length) p.imgs = lp.colorImages; }
    else if (leg) {
      if (leg.imgs) p.imgs = leg.imgs;
      p.img = leg.img || (leg.imgs && Object.values(leg.imgs)[0]);
      if (leg.extra) p.extra = leg.extra;
      if (leg.fit) p.fit = leg.fit;
    }
    else if (lp.formImages && lp.formImages.length) { p.img = lp.formImages[0]; p.extra = lp.formImages.slice(1); }
    else p.img = PLACEHOLDER;
    const ovp = (IMGX.products || {})[norm(lp.brand) + '|' + norm(lp.name)];
    if (ovp && ovp.length) { p.img = ovp[0]; p.extra = ovp.slice(1); delete p.imgs; p.ovAll = ovp; }
    // รูปแยกตามสี (แอดมิน) → แกลเลอรีของสีนั้น + รูป "ทุกสี" ของแอดมินต่อท้าย
    const ovc = (IMGX.colors || {})[norm(lp.brand) + '|' + norm(lp.name)];
    if (ovc) { const m = {}; Object.keys(ovc).forEach(c => { if (ovc[c] && ovc[c].length) m[norm(c)] = ovc[c]; }); if (Object.keys(m).length) p.cgal = m; }
    const blank = s => /^[\s\-–—.]*$/.test(String(s || ''));
    const sheetChart = (lp.sizeChart || []).filter(s => !blank(s));
    const chart = sheetChart.length ? sheetChart : (LEGACY.detail[id] || []);
    const d = [...chart, ...(!blank(lp.material) ? ['เนื้อผ้า: ' + lp.material] : [])];
    if (d.length) detail[id] = d;
    products.push(p);
  });

  const deals = {};
  (data.deals || []).forEach(ld => {
    const p = (ld.skus || []).map(s => bySku[s]).find(Boolean);
    if (!p || deals[p.id]) return;
    const colors = uniq(p.v.filter(x => ld.skus.includes(x[2])).map(x => x[0]));
    const legDeal = Object.values(LEGACY.deals).find(x => x.code === ld.code);
    const prodImgs = [...(p.cgal ? [].concat(...Object.values(p.cgal)) : []), p.img, ...(p.imgs ? Object.values(p.imgs) : []), ...(p.extra || [])].filter((x, i, a) => x && x !== PLACEHOLDER && a.indexOf(x) === i);
    const tiers = (ld.tiers && ld.tiers.length) ? ld.tiers : [[ld.threshold || 1, ld.price]];
    deals[p.id] = {
      code: ld.code, colors: colors.length ? colors : uniq(p.v.map(x => x[0])),
      price: ld.price || tiers[0][1], orig: ld.orig || 0, tiers,
      close: ld.closeLabel || '', closeAt: ld.close ? Date.parse(ld.close) || 0 : 0, deposit: ld.deposit || 0,
      booked: ld.booked, threshold: ld.threshold || tiers[0][0],
      gal: (ld.images && ld.images.length) ? ld.images : (legDeal ? legDeal.gal : (prodImgs.length ? prodImgs : [PLACEHOLDER])),
      link: ld.link || ''
    };
  });

  BRANDS = brands.filter(b => products.some(p => p.brand === b.id));
  PRODUCTS = products; STOCK = stock; DETAIL = detail; DEALS = deals; PRICE = price;
  return true;
}

// ===== สมัครสมาชิกด้วย LINE (LIFF) + คำถาม 4 ข้อ =====
// ใส่ LIFF ID เพื่อเปิดใช้ (เว้นว่าง = ปิดการบังคับสมัคร เว็บเปิดดูได้ปกติ)
const LIFF_ID = '2011928469-icqhLzdN';
const MEMBER_KEY = 'mera-member-v1';
const GATE_Q = [
  // ---- ข้อมูลประชากร (demographic) — ข้ามได้ทุกข้อ ----
  { key: 'age', q: 'อายุเท่าไหร่คะ', sub: 'ข้ามได้', cols: 2, skip: true, demo: true,
    opts: ['ต่ำกว่า 18', '18–23', '24–29', '30–39', '40+', 'ไม่ระบุ'] },
  { key: 'gender', q: 'เพศของคุณคะ', sub: 'ข้ามได้', cols: 2, skip: true, demo: true,
    opts: ['หญิง', 'ชาย', 'LGBTQ+', 'ไม่ระบุ'] },
  { key: 'province', q: 'อยู่จังหวัดไหนคะ', sub: 'ข้ามได้', skip: true, demo: true, select: true,
    opts: 'กรุงเทพมหานคร,กระบี่,กาญจนบุรี,กาฬสินธุ์,กำแพงเพชร,ขอนแก่น,จันทบุรี,ฉะเชิงเทรา,ชลบุรี,ชัยนาท,ชัยภูมิ,ชุมพร,เชียงราย,เชียงใหม่,ตรัง,ตราด,ตาก,นครนายก,นครปฐม,นครพนม,นครราชสีมา,นครศรีธรรมราช,นครสวรรค์,นนทบุรี,นราธิวาส,น่าน,บึงกาฬ,บุรีรัมย์,ปทุมธานี,ประจวบคีรีขันธ์,ปราจีนบุรี,ปัตตานี,พระนครศรีอยุธยา,พะเยา,พังงา,พัทลุง,พิจิตร,พิษณุโลก,เพชรบุรี,เพชรบูรณ์,แพร่,ภูเก็ต,มหาสารคาม,มุกดาหาร,แม่ฮ่องสอน,ยโสธร,ยะลา,ร้อยเอ็ด,ระนอง,ระยอง,ราชบุรี,ลพบุรี,ลำปาง,ลำพูน,เลย,ศรีสะเกษ,สกลนคร,สงขลา,สตูล,สมุทรปราการ,สมุทรสงคราม,สมุทรสาคร,สระแก้ว,สระบุรี,สิงห์บุรี,สุโขทัย,สุพรรณบุรี,สุราษฎร์ธานี,สุรินทร์,หนองคาย,หนองบัวลำภู,อ่างทอง,อำนาจเจริญ,อุดรธานี,อุตรดิตถ์,อุทัยธานี,อุบลราชธานี,ต่างประเทศ'.split(',') },
  { key: 'occupation', q: 'ทำงานอะไรคะ', sub: 'ข้ามได้', cols: 2, skip: true, demo: true,
    opts: ['นักเรียน / นักศึกษา', 'พนักงานบริษัท', 'Freelance', 'เจ้าของธุรกิจ', 'ข้าราชการ / รัฐวิสาหกิจ', 'อื่น ๆ', 'ไม่สะดวกตอบ'] },
];
const PROFILE_VERSION = 2;                                  // เพิ่มเลขนี้เมื่อเพิ่มคำถามใหม่ → สมาชิกเดิมจะถูกถามเฉพาะข้อใหม่
const DEMO_START = GATE_Q.findIndex(q => q.demo);
function loadLiff() {
  if (window.liff) return Promise.resolve(window.liff);
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://static.line-scdn.net/liff/edge/2/sdk.js';
    s.onload = () => res(window.liff); s.onerror = () => rej(new Error('โหลด LINE ไม่สำเร็จ'));
    document.head.appendChild(s);
  });
}
function readMember() { try { return JSON.parse(localStorage.getItem(MEMBER_KEY) || 'null'); } catch (_) { return null; } }
function writeMember(m) { try { localStorage.setItem(MEMBER_KEY, JSON.stringify(m)); } catch (_) {} }

const MERA_LOGO = 'img/e6caece427a6.png';

const MERA_QR = 'img/672e370c0652.svg';  // QR → https://liff.line.me/2011928469-icqhLzdN

const VERIFY_SM = 'img/89350f4a78d5.png';
const VERIFY_LG = 'img/bc510ffbaf17.png';



/* =====================================================================
 * Mera Catalog — หน้าตา Prototype v2
 * ข้อมูลสินค้า / สมัครสมาชิก LINE / เก็บพฤติกรรม / ตะกร้า-สั่งซื้อ ใช้ระบบเดิมทั้งหมด
 * (โค้ดส่วนบนของไฟล์นี้คัดลอกจากเว็บเดิมโดยไม่แก้ · ส่วนล่างนี้คือหน้าตาใหม่)
 * ===================================================================== */
const LINE_ID = '@652glcdn';
const CK = () => (window.MERA_CHECKOUT && window.MERA_CHECKOUT.api) || '';
let LANG = (() => { try { return localStorage.getItem('mera-lang') === 'en' ? 'en' : 'th'; } catch (_) { return 'th'; } })();
// ข้อความบนหน้าเว็บ: แอดมินแก้ได้จากหน้าแอดมิน (แท็บ Texts ในชีต Mera Admin) · ช่องว่าง = ใช้ข้อความเดิม
let TXT = (() => { try { const c = JSON.parse(localStorage.getItem('mera-content-v1') || 'null'); return (c && c.texts) || {}; } catch (_) { return {}; } })();
// รูปสินค้า/โลโก้แบรนด์ที่แอดมินอัปโหลดจากหน้าแอดมิน (แท็บ Images ในชีต Mera Admin) · ใช้แทนรูปจากชีตสินค้า/ฟอร์ม
let IMGX = (() => { try { const c = JSON.parse(localStorage.getItem('mera-content-v1') || 'null'); return (c && c.images) || {}; } catch (_) { return {}; } })();
const clean = v => String(v).replace(/[<>"]/g, '');
const Lraw = (th, en) => { const o = TXT[th]; return LANG === 'en' ? (o && o.en ? clean(o.en) : en) : (o && o.th ? clean(o.th) : th); };
/* ---------- โหมดแก้ข้อความ (เปิดจากหน้าแอดมินเท่านั้น: admin.html → index.html?edit=1 ใน iframe) ---------- */
const ADMIN = (() => { try { return /[?&]edit=1/.test(location.search) && window.parent !== window && window.parent.meraAdmin ? window.parent.meraAdmin : null; } catch (_) { return null; } })();
const EDIT = !!ADMIN;
const EK = [], EKI = {};
const EREG = EDIT ? new Set(ADMIN.keys()) : null;
const L = (th, en) => {
  const out = Lraw(th, en);
  if (!EDIT || !EREG.has(th)) return out;
  let i = EKI[th]; if (i == null) { i = EK.length; EK.push(th); EKI[th] = i; }
  return '\uE000' + i + '\uE001' + out + '\uE002';
};
// เปลี่ยนเครื่องหมายในข้อความให้เป็นจุดที่กดแก้ได้ (และลบออกจาก attribute เช่น aria-label / placeholder)
function decorate(root) {
  if (!EDIT || !root) return;
  const MK = /[\uE000-\uE002]/, STRIP = /\uE000\d+\uE001|\uE002/g;
  root.querySelectorAll('*').forEach(el => { for (const a of Array.from(el.attributes)) if (MK.test(a.value)) el.setAttribute(a.name, a.value.replace(STRIP, '')); });
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), nodes = [];
  while (w.nextNode()) if (MK.test(w.currentNode.nodeValue)) nodes.push(w.currentNode);
  nodes.forEach(n => {
    const par = n.parentElement;
    if (!par || /^(OPTION|TEXTAREA|TITLE|SCRIPT|STYLE)$/.test(par.tagName)) { n.nodeValue = n.nodeValue.replace(STRIP, ''); return; }
    const frag = document.createDocumentFragment(), re = /\uE000(\d+)\uE001([\s\S]*?)\uE002/g, v = n.nodeValue; let last = 0, m;
    while ((m = re.exec(v))) {
      if (m.index > last) frag.appendChild(document.createTextNode(v.slice(last, m.index).replace(STRIP, '')));
      const sp = document.createElement('span'); sp.className = 'tk'; sp.setAttribute('data-tk', m[1]); sp.textContent = m[2];
      const o = TXT[EK[+m[1]]]; if (o && (o.th || o.en)) sp.classList.add('tk-on');
      frag.appendChild(sp); last = re.lastIndex;
    }
    if (last < v.length) frag.appendChild(document.createTextNode(v.slice(last).replace(STRIP, '')));
    n.replaceWith(frag);
  });
}
const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => LANG === 'en' ? '฿' + Number(n).toLocaleString('en-US') : baht(n);
const abs = u => { try { return u ? new URL(u, document.baseURI || location.href).href : ''; } catch (_) { return ''; } };
const CAT_EN = { 'กระโปรง': 'Skirts', 'เสื้อ': 'Tops', 'เสื้อผ้า': 'Clothing', 'กระเป๋า': 'Bags', 'สูท': 'Suits', 'กางเกง': 'Pants', 'เดรส': 'Dresses', 'รองเท้า': 'Shoes', 'เครื่องประดับ': 'Accessories', 'อื่นๆ': 'Others' };
const catName = c => LANG === 'en' ? (CAT_EN[c] || c) : (CAT[c] || c);
// รูปย่อของรูปในเว็บ (สร้างตอน build) ใช้กับการ์ดสินค้า/โลโก้ที่แสดงเล็ก
const THUMBS = new Set(["06d3ee8de383.jpg", "14a93e3821a5.jpg", "18cff3192a44.jpg", "21a2105779ea.jpg", "29bdeaa88701.jpg", "2dfe0d1d78f4.jpg", "31f161d6ed56.jpg", "438a22588592.jpg", "4f1bff9319f7.jpg", "55c9c31dd5c8.jpg", "576c06ec6833.jpg", "5b15a6973ad2.jpg", "5d3a87fceb22.jpg", "645cda63cf99.jpg", "671b43f8f86b.jpg", "74c5942a7990.jpg", "754e909c897c.jpg", "75f61181ffcf.jpg", "7aecc45b39b7.jpg", "87d5987c9802.jpg", "8e6887d7866b.jpg", "8e78f58491bd.jpg", "9f4682d81fac.jpg", "a8a76849213d.jpg", "b2c6857108b8.jpg", "b4b84ff89ab9.jpg", "bdaf7a4b9382.jpg", "c2df53b9b896.jpg", "c8b497510a84.jpg", "d1554bc36fad.jpg", "df7681d90336.jpg", "e1a248ad9a74.jpg", "f01ca8d5c8ef.jpg", "f156849b8a56.jpg", "f22a4eae8f9c.jpg", "f995c1945450.jpg", "fb48cd89ae8d.jpg", "fdc4b58789ac.jpg"]);
const imgS = (u, w) => { const m = /^img\/([^/]+\.jpg)$/.exec(String(u || '')); return m && w <= 500 && THUMBS.has(m[1]) ? 'img/t/' + m[1] : imgW(u, w); };
const brandById = id => BRANDS.find(b => b.id === id) || { id, name: '', logo: PLACEHOLDER };
const brandIdOf = name => LEGACY_BRAND[norm(name)] || ('b' + hashId(norm(name)));
const totalStock = p => p.v.reduce((n, x) => n + stockOf(x[2]), 0);
const dealIdByCode = code => Object.keys(DEALS).find(k => DEALS[k].code === code);
// ช่วงราคา (ตรรกะเดียวกับ priceRange ของเว็บเดิม แต่คืนเป็นตัวเลขเพื่อแสดงได้ 2 ภาษา)
function prRange(p) {
  const ps = p.v.map(x => priceOfSku(x[2])).filter(Boolean);
  if (!ps.length) return null;
  const min = Math.min(...ps.map(x => x.price)), max = Math.max(...ps.map(x => x.price));
  const origs = ps.filter(x => x.price === min).map(x => x.orig).filter(o => o > min);
  return { from: min !== max, min, orig: origs.length ? Math.max(...origs) : 0 };
}

const IC = {
  back: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
  search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  cart: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 4h2l2.2 11h11l2-8H6.3"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/></svg>',
  burger: '<svg width="30" height="22" viewBox="0 0 30 22" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M1 2h28M1 11h28M1 20h28"/></svg>',
  home: on => '<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z" fill="' + (on ? '#841132' : 'none') + '" stroke="' + (on ? '#841132' : '#2a0a14') + '" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  box: on => '<svg width="24" height="24" viewBox="0 0 24 24" fill="' + (on ? '#841132' : 'none') + '" stroke="' + (on ? '#841132' : '#2a0a14') + '" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9" stroke="' + (on ? '#fff' : '#2a0a14') + '"/></svg>',
  user: on => '<svg width="24" height="24" viewBox="0 0 24 24" fill="' + (on ? '#841132' : 'none') + '" stroke="' + (on ? '#841132' : '#2a0a14') + '" stroke-width="1.7" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7z"/></svg>',
  chev: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2a0a14" stroke-width="2" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  ruler: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 15.5 15.5 3 21 8.5 8.5 21z"/><path d="M7 12l2 2M10 9l2 2M13 6l2 2"/></svg>',
  down: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#841132" stroke-width="2.4" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
  x: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  ok: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>',
  line: '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#fff" d="M12 3C6.5 3 2 6.6 2 11c0 3.9 3.5 7.2 8.3 7.9.3.1.8.2.9.5.1.3.1.7 0 1l-.1.9c0 .3-.2 1 .9.5 1.1-.5 5.9-3.5 8.1-6C21.4 14.1 22 12.6 22 11c0-4.4-4.5-8-10-8z"/></svg>',
  clock: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  star: '<svg width="44" height="44" viewBox="0 0 40 40" aria-hidden="true"><path d="M20 0C21.5 13 27 18.5 40 20C27 21.5 21.5 27 20 40C18.5 27 13 21.5 0 20C13 18.5 18.5 13 20 0Z" fill="#841132"/></svg>',
};

/* ---------- สถานะหน้าเว็บ ---------- */
const S = { view: 'home', params: {}, stack: [], cat: 'all', bcat: 'all', q: '', sel: {}, gi: {}, sheet: null, menu: false, toast: '', gate: null, zone: 'gb', banners: [], admin: false, acc: {}, how: 0, pinfo: {}, unit: '', live: null };
const A = {};   // ข้อมูล LINE / LIFF ของผู้ใช้ (เหมือน this._xxx ในเว็บเดิม)
let RECENT = (() => { try { return JSON.parse(localStorage.getItem('mera-recent') || '[]'); } catch (_) { return []; } })();

/* ---------- นำทาง ---------- */
function go(view, params) {
  S.stack.push([S.view, S.params, window.scrollY]);
  S.view = view; S.params = params || {}; S.sheet = null; S.menu = false;
  try { history.pushState({ mv: S.stack.length }, ''); } catch (_) {}
  render(); window.scrollTo(0, 0); trackView();
}
function doBack() {
  const p = S.stack.pop(); if (!p) return;
  S.view = p[0]; S.params = p[1]; S.sheet = null; S.menu = false;
  render(); window.scrollTo(0, p[2] || 0);
}
function back() {
  if (history.state && history.state.mv === S.stack.length && S.stack.length) history.back(); else doBack();
}
window.addEventListener('popstate', e => {
  const ov = document.querySelector('.mc-ov'); if (ov && !ov.hidden) return;   // หน้าสั่งซื้อจัดการเอง
  const depth = (e.state && e.state.mv) || 0;
  if (S.sheet || S.menu) { S.sheet = null; S.menu = false; render(); }
  while (S.stack.length > depth) doBack();
});
function tab(view) { S.stack = []; S.view = view; S.params = {}; S.sheet = null; S.menu = false; try { history.replaceState({ mv: 0 }, ''); } catch (_) {} render(); window.scrollTo(0, 0); }
function toast(t) { S.toast = t; renderOverlay(); clearTimeout(A.tt); A.tt = setTimeout(() => { S.toast = ''; renderOverlay(); }, 1800); }

/* ---------- เลือกสี / ไซซ์ (ตรรกะเดียวกับเว็บเดิม) ---------- */
function pick(id, patch) { S.sel[id] = Object.assign({}, S.sel[id] || {}, patch); }
function resolve(p, dealMode) {
  const s = S.sel[p.id] || {};
  const colors = uniq(p.v.map(x => x[0])).filter(c => !dealMode || DEALS[p.id].colors.includes(c));
  const colorOk = c => colors.includes(c) && p.v.some(x => x[0] === c && stockOf(x[2]) > 0);
  const color = colors.includes(s.color) ? s.color : (colors.find(colorOk) ?? colors[0]);
  const sizes = uniq(p.v.filter(x => x[0] === color).map(x => x[1]).filter(Boolean));
  const sizeOk = z => p.v.some(x => x[0] === color && x[1] === z && stockOf(x[2]) > 0);
  const size = sizes.includes(s.size) ? s.size : (sizes.find(sizeOk) || sizes[0] || '');
  const row = p.v.find(x => x[0] === color && (x[1] === size || !size)) || p.v[0];
  const main = (p.imgs && p.imgs[color]) || p.img || '';
  const cg = p.cgal && p.cgal[norm(color)];
  const gal = (cg ? [...cg, ...(p.ovAll || [])] : [main, ...(p.extra || [])]).filter((x, i, a) => x && a.indexOf(x) === i);
  const stock = stockOf(row[2]);
  const qty = Math.max(1, Math.min(s.qty || 1, stock || 1));
  return { s, colors, colorOk, color, sizes, sizeOk, size, row, gal, stock, qty };
}

/* ---------- ชิ้นส่วนซ้ำ ---------- */
function hdr(title, right) {
  return '<div class="hdr"><button class="back" data-a="back" aria-label="' + L('ย้อนกลับ', 'Back') + '">' + IC.back + '</button><h1>' + esc(title) + '</h1>' + (right || '<span></span>') + '</div>';
}
const verifyBtn = () => '<span class="mb" role="button" tabindex="0" data-a="verify" aria-label="Mera Verified"><img src="' + VERIFY_SM + '" alt="Mera Verified"></span>';
function pcard(p, narrow) {
  const pr = prRange(p), st = totalStock(p), b = brandById(p.brand), r = resolve(p);
  const sizes = uniq(p.v.map(x => x[1]).filter(Boolean)), colors = r.colors.filter(Boolean);
  const tag = COMING.has(p.id) ? '<span class="tag soon">Coming soon</span>' : DEALS[p.id] ? '<span class="tag">' + L('ดีลราคาส่ง', 'Deal') + ' ✦</span>' : !st ? '<span class="tag dark">' + L('หมด', 'Sold out') + '</span>' : '';
  return '<button class="pcard' + (narrow ? ' w150' : '') + '" data-a="product" data-id="' + esc(p.id) + '"><span class="pim' + (st ? '' : ' out') + '" style="background:' + (TINT[p.cat] || '#FCE4E8') + '">' +
    '<img class="ph" src="' + esc(imgS(r.gal[0] || PLACEHOLDER, 500)) + '" alt="' + esc(p.name) + '" loading="lazy" decoding="async" style="object-fit:' + (p.fit || 'cover') + '">' + verifyBtn() + tag + '</span>' +
    '<span class="pb"><span class="pr">' + (pr ? '<b>' + (pr.from ? L('เริ่ม ', 'from ') : '') + money(pr.min) + '</b>' + (pr.orig ? '<s>' + money(pr.orig) + '</s>' : '') : '') + '</span>' +
    '<span class="pn">' + esc(p.name) + '</span><span class="ps">' + esc([b.name, sizes.length ? sizes.join('/') : (colors.length > 1 ? colors.length + L(' สี', ' colours') : '')].filter(Boolean).join(' · ')) + '</span>' +
    (colors.length > 1 ? '<span class="cdots">' + colors.slice(0, 6).map(c => '<i style="background:' + hexOf(c) + '"></i>').join('') + '</span>' : '') + '</span></button>';
}
// นับถอยหลังปิดรอบดีล (เวลาปิดจริงจากชีตดีล)
function cdText(at) {
  const t = Math.max(0, at - Date.now()); if (!t) return L('ปิดรอบแล้ว', 'Closed');
  const d = Math.floor(t / 864e5), hh = Math.floor(t / 36e5) % 24, mm = Math.floor(t / 6e4) % 60, ss = Math.floor(t / 1e3) % 60, z = n => String(n).padStart(2, '0');
  return (d ? d + L(' วัน ', 'd ') : '') + z(hh) + ':' + z(mm) + ':' + z(ss);
}
setInterval(() => { document.querySelectorAll('[data-cd]').forEach(el => { const v = cdText(Number(el.getAttribute('data-cd'))); if (el.textContent !== v) el.textContent = v; }); }, 1000);
function dcard(id, full) {
  const d = DEALS[id], p = PRODUCTS.find(x => x.id === id), b = brandById(p.brand);
  const min = d.tiers[d.tiers.length - 1][1];
  const pct = d.booked != null && d.threshold ? Math.min(100, d.booked / d.threshold * 100) : null;
  return '<button class="dcard' + (full ? ' full' : '') + '" data-a="deal" data-id="' + esc(id) + '"><span class="dim"><img class="ph" src="' + esc(imgS(d.gal[0] || PLACEHOLDER, 500)) + '" alt="' + esc(p.name) + '" loading="lazy" decoding="async">' + verifyBtn() +
    (d.closeAt ? '<span class="cd">' + IC.clock + L('ปิดรอบใน ', 'Closes in ') + '<span data-cd="' + d.closeAt + '">' + cdText(d.closeAt) + '</span></span>' : d.close ? '<span class="cd">' + IC.clock + L('ปิดรอบ ', 'Closes ') + esc(d.close) + '</span>' : '') + '</span>' +
    '<span class="db"><span class="row"><span class="ps">' + esc(b.name) + ' · ' + esc(d.code) + '</span>' + (d.orig ? '<span class="pill">-' + Math.round((1 - min / d.orig) * 100) + '%</span>' : '') + '</span>' +
    '<b style="font-size:15px">' + esc(p.name) + '</b><span class="pr"><b style="color:var(--wine);font-size:18px">' + money(d.price) + '</b>' + (d.orig ? '<s>' + money(d.orig) + '</s>' : '') + '</span>' +
    '<span class="tiers">' + d.tiers.map((t, i) => '<span class="' + (i === d.tiers.length - 1 ? 'on' : '') + '">' + L('ครบ ' + t[0] + ' ชิ้น ', t[0] + '+ pcs ') + money(t[1]) + '</span>').join('') + '</span>' +
    (pct != null ? '<span class="bar"><i style="width:' + pct + '%"></i></span><span class="ps">' + L('จองแล้ว ' + d.booked + '/' + d.threshold + ' ชิ้น', d.booked + '/' + d.threshold + ' booked') + '</span>' : '') +
    (d.deposit ? '<span class="ps">' + L('มัดจำ ', 'Deposit ') + money(d.deposit) + '</span>' : '') + '</span></button>';
}

/* ---------- แบนเนอร์ (แอดมินอัปโหลดจากหน้าแอดมิน) ---------- */
const CONTENT_KEY = 'mera-content-v1';
const todayISO = () => { const d = new Date(Date.now() + 7 * 3600e3); return d.toISOString().slice(0, 10); };
// แบนเนอร์ชั่วคราว: ใช้เมื่อแอดมินยังไม่ได้เพิ่มแบนเนอร์ของตำแหน่งนั้น (เพิ่มแบนเนอร์จริงในหน้าแอดมินแล้วจะแทนที่ทันที)
const DEFAULT_BANNERS = [
  { id: 'D1', slot: 'top', title: 'รวมสินค้าแฟชั่น Clearance แบรนด์ออนไลน์', img: 'img/banners/b1-7d2abaaf.jpg', link: 'zone:shop', order: 1 },
  { id: 'D2', slot: 'top', title: 'ซื้อปลีก ในราคาส่ง', img: 'img/banners/b2-06da61c3.jpg', link: 'zone:gb', order: 2 },
  { id: 'D3', slot: 'top', title: 'Mera Verified', img: 'img/banners/b3-9b627026.jpg', link: 'zone:shop', order: 3 },
  { id: 'D4', slot: 'mid', title: 'แบรนด์ที่ Mera คัดมาให้', img: 'img/banners/m1-0fe9fe07.jpg', link: 'zone:shop', order: 1 },
];
function activeBanners(slot) {
  const t = todayISO();
  const mine = (S.banners || []).filter(b => b.slot === slot && b.img && (!b.start || b.start <= t) && (!b.end || b.end >= t)).sort((a, b) => (a.order || 0) - (b.order || 0));
  return mine.length ? mine : DEFAULT_BANNERS.filter(b => b.slot === slot);
}
function bannerEl(bn, cls, spec, idx) {
  if (!bn) return '<div class="bnr ' + cls + '"><b>' + L('พื้นที่แบนเนอร์', 'Banner slot') + '</b><small>' + spec + '</small><small class="muted">' + L('รอแอดมินอัปโหลดรูป', 'Waiting for the admin to upload') + '</small></div>';
  const img = '<img src="' + esc(imgW(bn.img, 1200)) + '" alt="' + esc(bn.title || '') + '" width="1200" height="' + (cls === 'mid' ? 580 : 625) + '"' + (cls === 'top' && !idx ? ' fetchpriority="high"' : ' loading="lazy"') + ' decoding="async">';
  const link = String(bn.link || '');
  if (/^url:https?:\/\//.test(link)) return '<a class="bnr has ' + cls + '" href="' + esc(link.slice(4)) + '" target="_blank" rel="noopener" data-a="bannerUrl">' + img + '</a>';
  return '<div class="bnr has ' + cls + '" role="button" tabindex="0" data-a="banner" data-v="' + esc(link) + '">' + img + '</div>';
}
function followLink(link) {
  const i = link.indexOf(':'), t = link.slice(0, i), v = link.slice(i + 1);
  if (t === 'zone') { if (S.view !== 'home') tab('home'); S.zone = v === 'shop' ? 'shop' : 'gb'; setTimeout(() => scrollToId(S.zone === 'gb' ? 'z-gb' : 'z-shop'), 30); render(); }
  else if (t === 'brand') { const id = brandIdOf(v); if (BRANDS.some(b => b.id === id)) go('brand', { id }); }
  else if (t === 'product') { const p = PRODUCTS.find(x => x.v.some(r => r[2] === v)); if (p) go('product', { id: p.id }); }
  else if (t === 'deal') { const id = dealIdByCode(v); if (id) go('deal', { id }); }
}
function scrollToId(id) { const el = document.getElementById(id); if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 60, behavior: 'smooth' }); }
function ckPost(action, extra) {
  const url = CK(); if (!/^https:/.test(url)) return Promise.reject(new Error('no api'));
  return fetch(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(Object.assign({ action }, extra || {})) }).then(r => r.json());
}
// เปลี่ยนชุดรูปของแอดมิน → คำนวณข้อมูลสินค้าใหม่จากข้อมูลล่าสุดที่มี
function setImgx(x) {
  const n = (x && typeof x === 'object') ? x : {};
  if (JSON.stringify(n) === JSON.stringify(IMGX)) return false;
  IMGX = n;
  if (lastRaw) { try { applyLive(JSON.parse(lastRaw)); } catch (_) {} }
  return true;
}
function loadContent() {
  let hasContent = false; try { hasContent = !!localStorage.getItem(CONTENT_KEY); } catch (_) {}
  if (!hasContent) {   // แบนเนอร์/ข้อความจากไฟล์บนเว็บก่อน
    fetch('data/content.json', { cache: 'no-cache' }).then(r => (r.ok ? r.json() : null)).then(j => {
      if (!j || !Array.isArray(j.banners) || (S.banners && S.banners.length)) return;
      S.banners = j.banners; S.pinfo = j.products || {}; if (!EDIT) TXT = j.texts || {}; setImgx(j.images); render();
    }).catch(() => {});
  }
  try { const c = JSON.parse(localStorage.getItem(CONTENT_KEY) || 'null'); if (c && Array.isArray(c.banners)) S.banners = c.banners; if (c && c.products) S.pinfo = c.products; } catch (_) {}
  ckPost('content').then(j => {
    if (!j || !j.ok || !Array.isArray(j.banners)) return;
    const texts = j.texts || {};
    const products = j.products || {};
    const images = j.images || {};
    const changed = JSON.stringify(j.banners) !== JSON.stringify(S.banners) || JSON.stringify(texts) !== JSON.stringify(TXT) || JSON.stringify(products) !== JSON.stringify(S.pinfo);
    S.banners = j.banners; S.pinfo = products; if (!EDIT) TXT = texts;
    const imgChanged = setImgx(images);
    try { localStorage.setItem(CONTENT_KEY, JSON.stringify({ banners: j.banners, texts: texts, products: products, images: images, t: Date.now() })); } catch (_) {}
    if (imgChanged && !changed) render();
    if (changed) render();
  }).catch(() => {});
}

/* ---------- หน้าแรก ---------- */
function vHome() {
  const dealIds = Object.keys(DEALS).filter(id => PRODUCTS.some(x => x.id === id));
  const cats = uniq(PRODUCTS.map(x => x.cat));
  const list = PRODUCTS.filter(p => S.cat === 'all' || p.cat === S.cat);
  const top = activeBanners('top'), mid = activeBanners('mid')[0];
  const cnt = typeof window.MeraCheckout !== 'undefined' && checkoutOn() ? window.MeraCheckout.cartCount() : 0;
  const collage = PRODUCTS.map(p => resolve(p).gal[0]).filter(x => x && x !== PLACEHOLDER).slice(0, 3);
  let h = '<section class="hero"><img class="wm" src="' + MERA_LOGO + '" alt=""><div class="collage">' + collage.map(src => '<img src="' + esc(imgS(src, 200)) + '" alt="">').join('') + '</div>' +
    '<div class="ht"><button class="burger" data-a="menu" aria-label="' + L('เมนู', 'Menu') + '">' + IC.burger + '</button>' +
    '<button class="icbtn" data-a="go" data-v="search" aria-label="' + L('ค้นหา', 'Search') + '">' + IC.search + '</button><span style="flex:1"></span>' +
    (checkoutOn() ? '<button class="icbtn" style="background:none;color:#fff" data-a="cart" aria-label="' + L('ตะกร้า', 'Cart') + '">' + IC.cart + (cnt ? '<span class="dot">' + cnt + '</span>' : '') + '</button>' : '') +
    (A.liffId && !A.idToken && !(readMember()) ? '<button class="hbtn" data-a="login">' + L('เข้าสู่ระบบ', 'Log in') + '</button>' : '') + langBtn() + '</div>' +
    '<h1>' + L('รวมสินค้าแฟชั่น Clearance แบรนด์ออนไลน์', 'Clearance fashion from online brands') + '</h1><p>' + L('มือหนึ่ง · ส่งตรงจากแบรนด์', 'Brand new · Shipped by the brand') + (maxOff() ? '<br><b>' + L('ลดสูงสุด ', 'Up to ') + maxOff() + '%' + L('', ' off') + '</b>' : '') + '</p></section>';
  h += '<div class="sec" style="margin-top:16px;gap:6px"><div class="hscroll" data-k="bn">' + (top.length ? top.map((b, i) => bannerEl(b, 'top', '', i)).join('') : bannerEl(null, 'top', '1200 × 625 px')) + '</div>' +
    '<div class="dots" data-dots="bn">' + (top.length ? top : [0]).map((b, i) => '<span class="' + (i === 0 ? 'on' : '') + '"></span>').join('') + '</div></div>';
  h += '<div class="zone"><button class="' + (S.zone === 'gb' ? 'on' : '') + '" data-a="zone" data-v="gb">Group Buy <span class="pill" style="background:rgba(255,255,255,.25);color:inherit">' + dealIds.length + '</span></button>' +
    '<button class="' + (S.zone === 'shop' ? 'on' : '') + '" data-a="zone" data-v="shop">' + L('สินค้าทั้งหมด', 'All products') + '</button></div>';
  h += '<section id="z-gb" class="sec" style="padding-top:16px"><div class="sec-h"><h2>' + L('ดีลราคาส่ง', 'Wholesale deals') + ' ✦</h2><button class="link" data-a="how">' + L('วิธีสั่งซื้อ', 'How to order') + '</button></div>' +
    dealPromo() +
    (dealIds.length ? '<div class="hscroll" data-k="deals">' + dealIds.map(id => dcard(id)).join('') + '</div>' : '<p class="muted" style="margin:0 16px">' + L('ยังไม่มีดีลที่เปิดอยู่ตอนนี้', 'No open deals right now') + '</p>') + '</section>' + whyMera();
  h += '<div style="padding:8px 16px">' + bannerEl(mid, 'mid', 'Mid month deal · 1200 × 580 px') + '</div>';
  h += '<section id="z-shop" class="sec" style="padding-top:12px"><div class="sec-h"><h2>' + L('สินค้าทั้งหมด', 'All products') + '</h2><small>' + L(PRODUCTS.length + ' สินค้า · ' + BRANDS.length + ' แบรนด์', PRODUCTS.length + ' products · ' + BRANDS.length + ' brands') + '</small></div>' +
    '<div class="tabs" role="tablist"><button class="' + (S.cat === 'all' ? 'on' : '') + '" data-a="cat" data-v="all">' + L('ทั้งหมด', 'All') + '</button>' +
    cats.map(c => '<button class="' + (S.cat === c ? 'on' : '') + '" data-a="cat" data-v="' + esc(c) + '">' + esc(catName(c)) + '</button>').join('') + '</div>' +
    '<div class="hscroll" data-k="brands" style="gap:14px;padding-top:10px">' + BRANDS.map(b => '<button data-a="brand" data-id="' + esc(b.id) + '" style="border:0;background:none;display:flex;flex-direction:column;align-items:center;gap:5px;width:70px;padding:0">' +
      '<span style="width:58px;height:58px;border-radius:50%;overflow:hidden;background:#fff;border:1px solid var(--line)"><img src="' + esc(imgS(b.logo, 200)) + '" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover"></span>' +
      '<span style="font-size:11px;text-align:center;line-height:1.2">' + esc(b.name) + '</span></button>').join('') + '</div>' +
    (list.length ? '<div class="grid2">' + list.map(p => pcard(p)).join('') + '</div>' : '<p class="muted" style="text-align:center;padding:30px">' + L('ไม่พบสินค้า', 'No products') + '</p>') + '</section>';
  h += '<p style="text-align:center;font-size:11px;color:var(--mut);margin:22px 0 30px">' + L('ไม่มีสินค้าเพิ่มแล้ว', 'No more products') + '</p>';
  return h;
}
function whyMera() {
  const it = [['✦', L('แบรนด์ที่คัดมาแล้ว', 'Curated brands')], ['➜', L('ส่งตรงจากแบรนด์', 'Shipped by the brand')],
    ['✓', L('มือหนึ่ง ไม่มีตำหนิ', 'Brand new, no defects')], ['฿', L('ซื้อทันที หรือรอดีลราคาส่ง', 'Buy now or wait for a wholesale deal')]];
  return '<section class="sec" style="padding:18px 16px 4px"><b style="font-size:17px">' + L('ทำไมต้อง Mera', 'Why Mera') + '</b><div class="why">' +
    it.map(x => '<div class="card"><span class="why-i" aria-hidden="true">' + x[0] + '</span><b>' + x[1] + '</b></div>').join('') + '</div></section>';
}
// ปุ่มเปลี่ยนภาษา (มุมบนขวา)
const IC_GLOBE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/></svg>';
function langBtn(dark) { return '<button class="langbtn' + (dark ? ' dark' : '') + '" data-a="lang" aria-label="' + (LANG === 'th' ? 'Switch to English' : 'เปลี่ยนเป็นภาษาไทย') + '">' + IC_GLOBE + '<b>' + (LANG === 'th' ? 'TH' : 'EN') + '</b></button>'; }
// ส่วนลดสูงสุดจากราคาในชีต
function maxOff() { let m = 0; Object.values(PRICE).forEach(x => { if (x.orig > x.price && x.price > 0) m = Math.max(m, Math.round((1 - x.price / x.orig) * 100)); }); return m; }
// กล่องดีลราคาส่ง: บอกเดือนและวันปิดรอบจากชีตดีล
const TH_MONTH = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
const EN_MONTH = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function dealPromo() {
  const ends = Object.values(DEALS).map(d => d.closeAt).filter(t => t > Date.now());
  const end = ends.length ? Math.max(...ends) : 0;
  let sub = '';
  if (end) {
    const d = new Date(end + 7 * 3600e3), day = d.getUTCDate(), mo = d.getUTCMonth(), left = Math.ceil((end - Date.now()) / 864e5);
    sub = L('ดีลพิเศษเดือน' + TH_MONTH[mo] + ' · ถึง ' + day + ' ' + TH_MONTH[mo].slice(0, 3) + '. เท่านั้น', EN_MONTH[mo] + ' special · until ' + day + ' ' + EN_MONTH[mo].slice(0, 3) + ' only') +
      ' <span class="pill" style="background:var(--wine);color:#fff">' + (left <= 1 ? L('วันสุดท้าย', 'Last day') : L('เหลือ ' + left + ' วัน', left + ' days left')) + '</span>';
  }
  return '<div class="promo"><b>' + L('ซื้อปลีก ในราคาส่ง', 'Retail buys at wholesale prices') + '</b>' + (sub ? '<span>' + sub + '</span>' : '') + '</div>';
}

/* ---------- ค้นหา / แบรนด์ ---------- */
function vSearch() {
  let h = '<div class="hdr" style="grid-template-columns:44px 1fr;gap:8px"><button class="back" data-a="back" aria-label="' + L('ย้อนกลับ', 'Back') + '">' + IC.back + '</button>' +
    '<label style="display:flex;align-items:center;gap:8px;background:#fff;border-radius:999px;padding:8px 14px;box-shadow:0 1px 4px rgba(0,0,0,.14)">' + IC.search +
    '<input id="sq" data-in="q" value="' + esc(S.q) + '" placeholder="' + L('ค้นหาสินค้า หรือแบรนด์…', 'Search products or brands…') + '" style="border:0;outline:0;background:none;flex:1;min-width:0;font-size:16px" autocomplete="off" enterkeyhint="search"></label></div>';
  return h + '<div id="sres">' + searchResults() + '</div><div style="height:30px"></div>';
}
function searchResults() {
  const q = S.q.trim().toLowerCase();
  const res = q ? PRODUCTS.filter(p => [p.name, brandById(p.brand).name, p.cat, catName(p.cat), ...p.v.map(x => x[0] + ' ' + x[2])].join(' ').toLowerCase().includes(q)) : [];
  let h = '';
  if (!q) {
    h += '<div class="pad sec">' + (RECENT.length ? '<div class="row"><b class="muted" style="font-weight:500">' + L('ค้นหาล่าสุด', 'Recent searches') + '</b><button class="link" data-a="clearRecent">' + L('ล้างทั้งหมด', 'Clear all') + '</button></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap">' + RECENT.map(r => '<button class="chip" data-a="recent" data-v="' + esc(r) + '">' + esc(r) + '</button>').join('') + '</div>' : '') +
      '<b class="muted" style="font-weight:500;margin-top:6px">' + L('แนะนำ', 'Recommended') + '</b></div><div class="hscroll" data-k="rec">' + PRODUCTS.slice(0, 8).map(p => pcard(p, 1)).join('') + '</div>';
  } else {
    h += '<p class="small muted" style="margin:12px 16px">' + L('พบ ' + res.length + ' รายการ', res.length + ' results') + '</p><div class="grid2">' + res.map(p => pcard(p)).join('') + '</div>' +
      (res.length ? '' : '<p class="muted" style="text-align:center;padding:30px">' + L('ไม่พบสินค้า', 'No products found') + '</p>');
  }
  return h;
}
function vBrands() {
  return hdr(L('แบรนด์', 'Brands')) + '<div class="pad sec">' + BRANDS.map(b => '<button class="card" data-a="brand" data-id="' + esc(b.id) + '" style="display:flex;gap:12px;align-items:center;border:0;text-align:left">' +
    '<span style="width:52px;height:52px;border-radius:50%;overflow:hidden;background:#f6eee8;flex:none"><img src="' + esc(imgS(b.logo, 200)) + '" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover"></span>' +
    '<span style="flex:1"><b>' + esc(b.name) + '</b><br><span class="small muted">' + PRODUCTS.filter(p => p.brand === b.id).length + L(' สินค้า', ' products') + '</span></span>' + IC.chev + '</button>').join('') + '</div>';
}
function vBrand() {
  const b = brandById(S.params.id), ps = PRODUCTS.filter(p => p.brand === b.id), cats = uniq(ps.map(p => p.cat));
  const bc = S.bcat, list = ps.filter(p => bc === 'all' || p.cat === bc);
  const cover = ps.map(p => resolve(p).gal[0]).find(x => x && x !== PLACEHOLDER);
  return '<div style="position:relative;height:150px;background:linear-gradient(135deg,#2a0a14,#841132 70%,#b8505f)">' + (cover ? '<img src="' + esc(imgW(cover, 600)) + '" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.28">' : '') +
    '<button class="back" data-a="back" style="position:absolute;left:14px;top:calc(14px + env(safe-area-inset-top,0px))" aria-label="' + L('ย้อนกลับ', 'Back') + '">' + IC.back + '</button></div>' +
    '<div class="bhead"><span class="blogo2"><img src="' + esc(imgS(b.logo, 300)) + '" alt=""></span>' +
    '<h1 class="bname">' + esc(b.name) + '</h1><span class="bmeta"><span class="pill vpill"><img src="' + VERIFY_SM + '" alt="">Mera Verified</span><span class="small muted">' + ps.length + L(' สินค้า', ' items') + '</span></span></div>' +
    (cats.length > 1 ? '<div class="chips" style="padding-top:12px"><button class="chip' + (bc === 'all' ? ' on' : '') + '" data-a="bcat" data-v="all">' + L('ทั้งหมด', 'All') + '</button>' + cats.map(c => '<button class="chip' + (bc === c ? ' on' : '') + '" data-a="bcat" data-v="' + esc(c) + '">' + esc(catName(c)) + '</button>').join('') + '</div>' : '') +
    '<div class="grid2" style="padding-top:12px">' + list.map(p => pcard(p)).join('') + '</div><div style="height:30px"></div>';
}

/* ---------- หน้าสินค้า ---------- */
function gallery(imgs, key, extraHTML) {
  const gi = Math.min(S.gi[key] || 0, Math.max(0, imgs.length - 1));
  return '<div class="pgal"><div class="gtrack" data-gal="' + esc(key) + '" data-k="gal-' + esc(key) + '">' + imgs.map((src, i) => '<img src="' + esc(imgW(src, 1000)) + '" alt=""' + (i ? ' loading="lazy"' : '') + ' decoding="async">').join('') + '</div>' + extraHTML +
    (imgs.length > 1 ? '<span class="cnt" data-cnt="' + esc(key) + '">' + (gi + 1) + ' / ' + imgs.length + '</span>' : '') + '</div>' +
    (imgs.length > 1 ? '<div class="gdots" data-dots="' + esc(key) + '">' + imgs.map((x, i) => '<span class="' + (i === gi ? 'on' : '') + '"></span>').join('') + '</div>' : '<div class="gdots"></div>');
}
const TRUST = () => [L('แบรนด์ที่คัดมาแล้ว', 'Curated brand'), L('ส่งตรงจากแบรนด์', 'Shipped by the brand'), L('มือหนึ่ง ไม่มีตำหนิ', 'Brand new, no defects')];
function accordion(k, title, body, open) {
  const isOpen = S.acc[k] === undefined ? open : S.acc[k];
  return '<div class="acc"><button data-a="acc" data-v="' + k + '" aria-expanded="' + isOpen + '">' + title + IC.down + '</button>' + (isOpen ? '<div class="ab">' + body + '</div>' : '') + '</div>';
}
/* ---------- ข้อมูลสินค้า: ตารางไซซ์ + รายละเอียด (จากชีต Product Responses / Product Details ผ่าน content) ---------- */
const pkey = (a, b) => [a, b].map(v => String(v || '').trim().toLowerCase().replace(/\s+/g, ' ')).join('|');
// คีย์จากชีต = ชื่อแบรนด์ในชีต|ชื่อสินค้า → แปลงชื่อแบรนด์เป็นรหัสแบรนด์แบบเดียวกับแค็ตตาล็อก (ชื่อที่แสดงบนเว็บอาจต่างจากในชีต)
let PIDX = null, PIDX_SRC = null;
function pdata(p) {
  if (PIDX_SRC !== S.pinfo) { PIDX = {}; PIDX_SRC = S.pinfo; Object.keys(S.pinfo || {}).forEach(k => { const i = k.indexOf('|'); PIDX[brandIdOf(k.slice(0, i)) + '|' + k.slice(i + 1)] = S.pinfo[k]; }); }
  return PIDX[p.brand + '|' + pkey('', p.name).slice(1)] || {};
}
// ชื่อสัดส่วน (เรียงคำยาวก่อน เช่น ยาวแขน ก่อน ยาว)
const MEAS = [
  ['sleeve', /^(ความยาวแขน|ยาวแขน|sleeve\s*length|sleeve)/i], ['arm', /^(รอบแขน|วงแขน|armhole|arm)/i], ['chest', /^(รอบอก|อก|chest|bust)/i],
  ['waist', /^(รอบเอว|เอว|waist)/i], ['hip', /^(รอบสะโพก|สะโพก|hips?)/i], ['shoulder', /^(ไหล่|บ่า|shoulder)/i], ['thigh', /^(ต้นขา|thigh)/i],
  ['inseam', /^(เป้า|inseam|rise)/i], ['strap', /^(ความยาวสาย|สายยาว|สาย|strap)/i], ['width', /^(กว้าง|width|w)/i], ['height', /^(สูง|height|h)/i], ['depth', /^(ลึก|หนา|depth|d)/i],
  ['length', /^(ความยาว|ยาว|length|long|l)(?![a-z])/i]];
const MEAS_N = () => ({ chest: L('อก', 'Chest'), waist: L('เอว', 'Waist'), hip: L('สะโพก', 'Hip'), length: L('ยาว', 'Length'), shoulder: L('ไหล่', 'Shoulder'), sleeve: L('ยาวแขน', 'Sleeve'),
  arm: L('รอบแขน', 'Arm'), thigh: L('ต้นขา', 'Thigh'), inseam: L('เป้า', 'Rise'), strap: L('สาย', 'Strap'), width: L('กว้าง', 'Width'), height: L('สูง', 'Height'), depth: L('ลึก', 'Depth') });
const SIZE_RE = /^\s*(?:size\s*)?(free\s*size|freesize|ฟรีไซ[สซ]์|one\s*size|[2-6]?x{0,3}[sml]|[2-6]xl|\d{1,2}(?:\s*(?:us|eu|uk))?)(?![a-z0-9ก-๙])\s*[-–—:>⸝/|.,\s]*/i;
const VAL_RE = /^[\s:=.]*(ไม่เกิน|ถึง|max|up\s*to|≤)?\s*(\d+(?:\.\d+)?)(?:\s*(?:-|–|—|~|ถึง|to)\s*(\d+(?:\.\d+)?))?\s*(นิ้ว|"|”|''|in(?:ch(?:es)?)?|ซม\.?|cm|เซน(?:ติเมตร|ต์)?|มม\.?|mm)?/i;
const normSize = z => String(z || '').toLowerCase().replace(/[\s-]+/g, '').replace(/^size/, '').replace(/^(freesize|ฟรีไซ[สซ]์|onesize)$/, 'free');
function parseMeas(text) {
  const out = {}; let s = String(text), unit = '';
  for (let guard = 0; s && guard < 40; guard++) {
    s = s.replace(/^(?:[\s,|;/>⸝·•x×*]|[lI](?=\s|$))+/, '');
    if (!s) break;
    const m = MEAS.find(x => x[1].test(s));
    if (m) {
      const rest = s.replace(m[1], ''), v = VAL_RE.exec(rest);
      if (v) { if (!out[m[0]]) out[m[0]] = { a: +v[2], b: v[3] ? +v[3] : null, max: !!v[1] }; if (v[4]) unit = /ซม|cm|เซน/i.test(v[4]) ? 'cm' : /มม|mm/i.test(v[4]) ? 'mm' : 'in'; s = rest.slice(v[0].length); continue; }
    }
    s = s.replace(/^\S+/, '');   // ข้ามคำที่อ่านไม่ออก
  }
  return { m: out, unit };
}
// แปลงข้อความไซซ์ (พิมพ์เองจากแบรนด์) เป็นตาราง · อ่านไม่ออกคืน null แล้วแสดงข้อความเดิมแทน
function sizeTable(lines, sizes) {
  const rows = [], notes = [], cols = []; let unit = '';
  lines.forEach(raw => {
    const t = String(raw).trim(); if (!t) return;
    const sm = SIZE_RE.exec(t), body = sm ? t.slice(sm[0].length) : t, pm = parseMeas(body);
    if (!Object.keys(pm.m).length) { notes.push(t); return; }
    if (pm.unit) unit = unit || pm.unit;
    Object.keys(pm.m).forEach(k => { if (cols.indexOf(k) < 0) cols.push(k); });
    let z = sm ? sm[1].trim() : (sizes.length === 1 ? sizes[0] : (sizes.length ? '' : L('ขนาด', 'Size')));
    if (/^(free\s*size|freesize|ฟรีไซ[สซ]์|one\s*size)$/i.test(z)) z = 'Free size';
    rows.push({ z: z || '—', m: pm.m, raw: t });
  });
  if (!rows.length) return null;
  const order = ['chest', 'waist', 'hip', 'shoulder', 'arm', 'sleeve', 'thigh', 'inseam', 'width', 'height', 'depth', 'strap', 'length'];
  cols.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  return { rows, notes, cols, unit: unit || 'in' };
}
function fmtMeas(x, unit, want) {
  if (!x) return '–';
  const k = unit === 'in' && want === 'cm' ? 2.54 : unit === 'cm' && want === 'in' ? 1 / 2.54 : 1;
  const r = n => { const v = n * k; return k === 1 ? String(n) : String(Math.round(v * (want === 'cm' ? 1 : 2)) / (want === 'cm' ? 1 : 2)); };
  return (x.max ? '≤' : '') + r(x.a) + (x.b != null ? '–' + r(x.b) : '');
}
function sizeLines(p, info) {
  if (info.size) return String(info.size).split(/\n+/).map(s => s.trim()).filter(Boolean);
  return (DETAIL[p.id] || []).filter(t => !/^เนื้อผ้า:/.test(t));
}
function sizeGuide(p, r, inSheet) {
  const info = pdata(p), lines = sizeLines(p, info);
  if (!lines.length) return '<span class="muted">' + L('สอบถามไซซ์ทาง LINE ได้เลย', 'Ask us about sizing on LINE') + '</span>';
  const sizes = uniq(p.v.map(x => x[1]).filter(Boolean)), T = sizeTable(lines, sizes);
  if (!T) return '<ul>' + lines.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul>';
  const want = S.unit || (T.unit === 'cm' ? 'cm' : 'in'), N = MEAS_N(), cur = normSize(r.size);
  const uLbl = u => u === 'cm' ? L('ซม.', 'cm') : u === 'mm' ? L('มม.', 'mm') : L('นิ้ว', 'in');
  let h = '<div class="szwrap">';
  if (T.unit !== 'mm') h += '<div class="szhead"><span class="small muted">' + L('หน่วย: ', 'Unit: ') + uLbl(want) + '</span><span class="seg"><button class="' + (want === 'in' ? 'on' : '') + '" data-a="unit" data-v="in">' + L('นิ้ว', 'in') + '</button><button class="' + (want === 'cm' ? 'on' : '') + '" data-a="unit" data-v="cm">' + L('ซม.', 'cm') + '</button></span></div>';
  h += '<div class="sztbl"><table><thead><tr><th>' + L('ไซซ์', 'Size') + '</th>' + T.cols.map(c => '<th>' + esc(N[c] || c) + '</th>').join('') + '</tr></thead><tbody>' +
    T.rows.map(row => '<tr' + (cur && normSize(row.z) === cur ? ' class="on"' : '') + '><th>' + esc(row.z) + (cur && normSize(row.z) === cur ? '<small>' + L('ที่เลือก', 'selected') + '</small>' : '') + '</th>' + T.cols.map(c => '<td>' + fmtMeas(row.m[c], T.unit, T.unit === 'mm' ? 'mm' : want) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
  if (T.notes.length) h += '<div class="sznote">' + T.notes.map(esc).join('<br>') + '</div>';
  if (!inSheet) h += '<button class="link2" data-a="sizeSheet" data-id="' + esc(p.id) + '">' + L('ดูแบบเต็มจอ', 'Full screen') + '</button>';
  return h + '</div>';
}
const SRC_EN = { 'คอลเลกชันก่อนหน้า': 'Previous collection', 'ไซส์ / สี เหลือ': 'Leftover sizes / colours', 'สินค้าค้างสต็อก': 'Overstock', 'ตัวอย่างสินค้า': 'Sample' };
const OCC_EN = { 'ใส่ทำงาน': 'Work', 'ทำงาน': 'Work', 'ใส่เที่ยว': 'Going out', 'ท่องเที่ยว': 'Travel', 'ใส่ทุกวัน': 'Everyday', 'ใช้ทุกวัน': 'Everyday', 'ออกงาน': 'Events' };
const splitList = v => String(v || '').split(/\s*[,،\n]\s*/).map(s => s.trim()).filter(Boolean);
function specList(p, r) {
  const info = pdata(p), b = brandById(p.brand), sizes = uniq(p.v.map(x => x[1]).filter(Boolean));
  const mat = info.material || ((DETAIL[p.id] || []).find(t => /^เนื้อผ้า:/.test(t)) || '').replace(/^เนื้อผ้า:\s*/, '');
  const tr = (k, v) => v ? '<tr><th>' + k + '</th><td>' + v + '</td></tr>' : '';
  const desc = [info.description, info.detail].filter(Boolean);
  let h = desc.length ? '<p class="pdesc">' + desc.map(esc).join('<br><br>').replace(/\n/g, '<br>') + '</p>' : '';
  h += '<table class="spec">' +
    tr(L('แบรนด์', 'Brand'), esc(b.name)) +
    tr(L('ประเภท', 'Type'), esc(catName(p.cat))) +
    tr(L('เนื้อผ้า', 'Material'), esc(mat)) +
    tr(L('ทรง', 'Fit'), esc(info.fit || '').replace(/\n/g, '<br>')) +
    tr(L('สี', 'Colour'), esc(r.colors.filter(Boolean).join(', '))) +
    tr(L('ไซซ์', 'Size'), esc(sizes.join(', '))) +
    tr(L('การดูแล', 'Care'), esc(info.care || '').replace(/\n/g, '<br>')) +
    tr(L('การจัดส่ง', 'Shipping'), info.ship ? L('จัดส่งภายใน 1–3 วันทำการ', 'Ships in 1–3 business days') : '') + '</table>';
  if (info.note) h += '<div class="sznote">' + esc(info.note).replace(/\n/g, '<br>') + '</div>';
  return h;
}
function sheetSize() {
  const p = PRODUCTS.find(x => x.id === S.params.id); if (!p) return '';
  const r = resolve(p, false);
  return '<div class="grab"></div><div class="row" style="align-items:center"><h3>' + L('ตารางไซซ์', 'Size chart') + ' · ' + esc(p.name) + '</h3><button class="icbtn" data-a="closeSheet" aria-label="' + L('ปิด', 'Close') + '">' + IC.x + '</button></div>' + sizeGuide(p, r, true);
}
function vProduct() {
  const p = PRODUCTS.find(x => x.id === S.params.id);
  if (!p) return hdr('') + '<p class="muted" style="text-align:center;padding:40px">' + L('ไม่พบสินค้านี้แล้ว', 'This product is no longer available') + '</p>';
  const d = DEALS[p.id], coming = COMING.has(p.id), r = resolve(p, false), b = brandById(p.brand), pr = priceOfSku(r.row[2]);
  const ready = r.stock > 0 && !coming;
  const extra = '<button class="back" data-a="back" aria-label="' + L('ย้อนกลับ', 'Back') + '">' + IC.back + '</button><button class="blogo" data-a="brand" data-id="' + esc(b.id) + '" aria-label="' + esc(b.name) + '"><img src="' + esc(imgS(b.logo, 120)) + '" alt=""></button>' + verifyBtn();
  let h = gallery(r.gal.length ? r.gal : [PLACEHOLDER], 'p-' + p.id + '-' + r.color, extra);
  h += '<div class="pad sec" style="gap:10px"><div class="row" style="align-items:center"><span class="pr">' + (pr ? '<span class="bigp">' + money(pr.price) + '</span>' + (pr.orig > pr.price ? '<s style="font-size:14px">' + money(pr.orig) + '</s>' : '') : '') + '</span>' +
    (pr && pr.orig > pr.price ? '<span class="pill">-' + Math.round((1 - pr.price / pr.orig) * 100) + '%</span>' : '') + '</div>' +
    '<span style="display:flex;align-items:center;gap:5px;font-size:13px;font-weight:600">' + IC.ok + esc(b.name) + ' · ' + esc(catName(p.cat)) + '</span>' +
    '<div class="row" style="align-items:center"><b style="font-size:20px">' + esc(p.name) + '</b>' + heartBtn(p.id) + '</div>' +
    '<div style="display:flex;gap:6px;flex-wrap:wrap">' + TRUST().map(t => '<span class="pill off" style="gap:4px">' + IC.ok + esc(t) + '</span>').join('') + '</div>';
  if (r.colors.filter(Boolean).length) h += '<b style="margin-top:4px">' + L('สี', 'Colour') + ': <span style="color:var(--wine)">' + esc(r.color) + '</span></b><div style="display:flex;gap:8px;flex-wrap:wrap">' +
    r.colors.filter(Boolean).map(c => '<button class="sw' + (c === r.color ? ' on' : '') + '" data-a="pickc" data-id="' + esc(p.id) + '" data-v="' + esc(c) + '"' + (r.colorOk(c) ? '' : ' disabled') + '><i style="background:' + hexOf(c) + '"></i>' + esc(c) + '</button>').join('') + '</div>';
  if (r.sizes.length) h += '<div class="row" style="align-items:center"><b>' + L('ไซซ์', 'Size') + '</b>' + (sizeLines(p, pdata(p)).length ? '<button class="link2" data-a="sizeSheet">' + IC.ruler + L('ตารางไซซ์', 'Size chart') + '</button>' : '') + '</div><div style="display:flex;gap:8px;flex-wrap:wrap">' + r.sizes.map(z => '<button class="opt' + (z === r.size ? ' on' : '') + '" data-a="picks" data-id="' + esc(p.id) + '" data-v="' + esc(z) + '"' + (r.sizeOk(z) ? '' : ' disabled') + '>' + esc(z) + '</button>').join('') + '</div>';
  if (ready) h += '<div class="row" style="align-items:center"><b>' + L('จำนวน', 'Quantity') + '</b><span class="qty"><button class="m" data-a="qty" data-id="' + esc(p.id) + '" data-v="-1" aria-label="-">−</button><b>' + r.qty + '</b><button data-a="qty" data-id="' + esc(p.id) + '" data-v="1" aria-label="+">+</button></span></div>';
  if (d) h += '<button class="card" data-a="deal" data-id="' + esc(p.id) + '" style="border:1.5px solid var(--wine);display:flex;justify-content:space-between;align-items:center;text-align:left"><span><b style="color:var(--wine)">' + L('ดีลราคาส่ง ', 'Wholesale deal ') + money(d.price) + '</b><br><span class="small muted">' + (d.close ? L('ปิดรอบ ', 'Closes ') + esc(d.close) : L('ซื้อปลีก ในราคาส่ง', 'Retail buys at wholesale prices')) + '</span></span>' + IC.chev + '</button>';
  h += accordion('size', L('ตารางไซซ์', 'Size chart'), sizeGuide(p, r), true) +
    accordion('spec', L('รายละเอียดสินค้า', 'Product details'), specList(p, r), true) +
    '<div class="card" style="display:flex;gap:10px;align-items:center;box-shadow:none;border:1px solid #cfc5c0"><span class="muted small">' + L('จัดส่งโดย', 'Ships from') + '</span><b>' + esc(b.name) + '</b></div></div>';
  h += '<div style="height:12px"></div>';
  if (coming) h += '<div class="stickybuy one"><button class="btn" disabled>Coming soon</button></div>';
  else if (!ready) h += '<div class="stickybuy one"><button class="btn" disabled>' + L('สินค้าหมด', 'Sold out') + '</button></div>';
  else if (checkoutOn()) h += '<div class="stickybuy"><button class="btn" data-a="buyNow" data-id="' + esc(p.id) + '">' + L('ซื้อทันที', 'Buy now') + '</button><button class="btn-o" data-a="addCart" data-id="' + esc(p.id) + '">' + L('เพิ่มลงตะกร้า', 'Add to cart') + '</button></div>';
  else h += '<div class="stickybuy"><a class="btn-line" href="' + esc(orderMsgHref(p, r)) + '" target="_blank" rel="noopener">' + IC.line + L('สั่งผ่าน LINE', 'Order in LINE') + '</a><button class="btn-o" data-a="copyMsg" data-id="' + esc(p.id) + '">' + L('คัดลอกข้อความ', 'Copy message') + '</button></div>';
  return h;
}
function orderMsg(p, r) {
  const b = brandById(p.brand), x = priceOfSku(r.row[2]);
  return ['สนใจสั่งซื้อ', `${b.name} – ${p.name}`, [r.size && 'ไซส์ ' + r.size, r.color && 'สี ' + r.color].filter(Boolean).join(' / '), `จำนวน ${r.qty} ชิ้น`, x ? `ราคา ${baht(x.price)}/ชิ้น` + (r.qty > 1 ? ` · รวม ${baht(x.price * r.qty)}` : '') : '', `รหัส ${r.row[2]}`].filter(Boolean).join('\n');
}
const orderMsgHref = (p, r) => `https://line.me/R/oaMessage/${encodeURIComponent(LINE_ID)}/?${encodeURIComponent(orderMsg(p, r))}`;
// รูปสินค้าในตะกร้า / ออเดอร์: หาจาก SKU หรือชื่อสินค้าในแค็ตตาล็อก (ใช้กับออเดอร์ที่สั่งจาก LINE หรือเครื่องอื่นด้วย)
function orderImg(x) {
  if (!x) return '';
  const list = [x].concat(Array.isArray(x.items) ? x.items : []);
  for (const it of list) {
    const sku = String(it.sku || '').trim().toUpperCase();
    let p = sku && PRODUCTS.find(q => q.v.some(v => v[2] === sku)), color = '';
    if (p) color = (p.v.find(v => v[2] === sku) || [])[0] || '';
    if (!p && it.name) { const n = norm(it.name); p = PRODUCTS.find(q => norm(q.name) === n) || PRODUCTS.find(q => n && (n.includes(norm(q.name)) || norm(q.name).includes(n))); }
    if (!p) continue;
    if (!color && it.color) color = it.color;
    const src = (p.imgs && p.imgs[color]) || p.img || (p.imgs && Object.values(p.imgs)[0]);
    if (src && src !== PLACEHOLDER) return abs(imgS(src, 200));
  }
  return '';
}
if (window.MERA_CHECKOUT) window.MERA_CHECKOUT.imgFor = orderImg;
function itemOf(p, r) {
  return { sku: r.row[2], qty: r.qty, name: p.name, brand: brandById(p.brand).name, color: r.color, size: r.size, img: r.gal[0] ? abs(imgW(r.gal[0], 400)) : '' };
}

/* ---------- Group Deal ---------- */
function vDeal() {
  const id = S.params.id, p = PRODUCTS.find(x => x.id === id), d = DEALS[id];
  if (!p || !d) return hdr('Group Deal') + '<p class="muted" style="text-align:center;padding:40px">' + L('ดีลนี้ปิดแล้ว', 'This deal has closed') + '</p>';
  const r = resolve(p, true), b = brandById(p.brand), ready = r.stock > 0, min = d.tiers[d.tiers.length - 1][1];
  const extra = '<button class="back" data-a="back" aria-label="' + L('ย้อนกลับ', 'Back') + '">' + IC.back + '</button>' + verifyBtn();
  let h = gallery(d.gal.length ? d.gal : [PLACEHOLDER], 'd-' + id, extra);
  h += '<div class="pad sec" style="gap:12px"><span class="pill" style="align-self:flex-start;background:var(--wine);color:#fff">' + L('ดีลราคาส่ง', 'Wholesale deal') + ' ✦ ' + esc(d.code) + '</span>' +
    '<b style="font-size:22px">' + esc(p.name) + '</b><span class="small" style="margin-top:-8px">' + esc(b.name) + '</span>' +
    (d.closeAt ? '<span class="cdbig">' + IC.clock + L('ปิดรอบใน ', 'Closes in ') + '<b data-cd="' + d.closeAt + '">' + cdText(d.closeAt) + '</b>' + (d.close ? '<small>' + esc(d.close) + '</small>' : '') + '</span>' : '') +
    '<span class="pr"><span class="bigp" style="color:var(--wine)">' + money(d.price) + '</span>' + (d.orig ? '<s style="font-size:14px">' + money(d.orig) + '</s><span class="pill">-' + Math.round((1 - min / d.orig) * 100) + '%</span>' : '') + '</span>' +
    '<div class="card sec" style="gap:8px">' + (d.orig ? '<div class="row"><span class="muted">' + L('ราคาปกติ', 'Regular price') + '</span><s>' + money(d.orig) + '</s></div>' : '') +
    d.tiers.map((t, i) => '<div class="row" style="' + (i === d.tiers.length - 1 ? 'color:var(--wine);font-weight:700' : '') + '"><span>' + L('ครบ ' + t[0] + ' ชิ้นขึ้นไป', t[0] + '+ pieces') + '</span><b>' + money(t[1]) + '</b></div>').join('') +
    (d.booked != null && d.threshold ? '<div class="bar" style="margin-top:4px"><i style="width:' + Math.min(100, d.booked / d.threshold * 100) + '%"></i></div><span class="small">' + L('จองแล้ว ' + d.booked + '/' + d.threshold + ' ชิ้น', d.booked + '/' + d.threshold + ' booked') + '</span>' : '') + '</div>' +
    '<div class="card sec" style="gap:6px;font-size:13px;line-height:1.55"><b>' + L('เงื่อนไขดีล', 'Deal terms') + '</b>' +
    (d.close ? '<span>• ' + L('ปิดรอบ ', 'Closes ') + esc(d.close) + '</span>' : '') + (d.deposit ? '<span>• ' + L('มัดจำ ', 'Deposit ') + money(d.deposit) + '</span>' : '') +
    '<span>• ' + L('คละสี คละไซซ์ นับรวมกัน', 'Colours and sizes count together') + '</span><span>• ' + L('ไม่ครบจำนวน คืนมัดจำเต็มจำนวน', 'Not reached: full deposit refund') + '</span>' +
    '<button class="link" data-a="how" style="align-self:flex-start">' + L('วิธีสั่งซื้อดีล', 'How to order a deal') + '</button></div>';
  if (r.colors.filter(Boolean).length) h += '<b>' + L('สี', 'Colour') + ': <span style="color:var(--wine)">' + esc(r.color) + '</span></b><div style="display:flex;gap:8px;flex-wrap:wrap">' +
    r.colors.filter(Boolean).map(c => '<button class="sw' + (c === r.color ? ' on' : '') + '" data-a="pickc" data-id="' + esc(id) + '" data-v="' + esc(c) + '"' + (r.colorOk(c) ? '' : ' disabled') + '><i style="background:' + hexOf(c) + '"></i>' + esc(c) + '</button>').join('') + '</div>';
  if (r.sizes.length) h += '<div class="row" style="align-items:center"><b>' + L('ไซซ์', 'Size') + '</b>' + (sizeLines(p, pdata(p)).length ? '<button class="link2" data-a="sizeSheet">' + IC.ruler + L('ตารางไซซ์', 'Size chart') + '</button>' : '') + '</div><div style="display:flex;gap:8px;flex-wrap:wrap">' + r.sizes.map(z => '<button class="opt' + (z === r.size ? ' on' : '') + '" data-a="picks" data-id="' + esc(id) + '" data-v="' + esc(z) + '"' + (r.sizeOk(z) ? '' : ' disabled') + '>' + esc(z) + '</button>').join('') + '</div>';
  if (ready) h += '<div class="row" style="align-items:center"><b>' + L('จำนวน', 'Quantity') + '</b><span class="qty"><button class="m" data-a="qty" data-id="' + esc(id) + '" data-v="-1" aria-label="-">−</button><b>' + r.qty + '</b><button data-a="qty" data-id="' + esc(id) + '" data-v="1" aria-label="+">+</button></span></div>';
  h += '<button type="button" class="btn-line' + (ready ? '' : ' dis') + '"' + (ready ? ' data-a="bookDeal" data-v="' + esc(dealLink(d)) + '"' : ' disabled') + '>' + IC.line + (ready ? L('จองดีลผ่าน LINE', 'Book via LINE') : L('สินค้าหมด', 'Sold out')) + '</button>' +
    '<button class="link" data-a="copyDeal" data-v="' + esc(d.code) + '" style="align-self:center">' + L('คัดลอกรหัสดีล ' + d.code, 'Copy deal code ' + d.code) + '</button>' +
    '<div>' + accordion('size', L('ตารางไซซ์', 'Size chart'), sizeGuide(p, r), true) + accordion('spec', L('รายละเอียดสินค้า', 'Product details'), specList(p, r), true) + '</div></div><div style="height:20px"></div>';
  return h;
}

/* ---------- โปรไฟล์ ---------- */
/* ---------- Wishlist (เก็บในเครื่องนี้) ---------- */
const WISH_KEY = 'mera-wish-v1';
let WISH = (() => { try { return JSON.parse(localStorage.getItem(WISH_KEY) || '{}') || {}; } catch (_) { return {}; } })();
const wishCount = () => Object.keys(WISH).filter(id => PRODUCTS.some(p => p.id === id)).length;
const IC_HEART = f => '<svg width="20" height="20" viewBox="0 0 24 24" fill="' + (f ? '#841132' : 'none') + '" stroke="#841132" stroke-width="2" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>';
const heartBtn = id => '<button class="heartbtn" data-a="wish" data-id="' + esc(id) + '" aria-pressed="' + !!WISH[id] + '" aria-label="' + L('บันทึกในรายการโปรด', 'Save to wishlist') + '">' + IC_HEART(!!WISH[id]) + '</button>';
function toggleWish(id) {
  const p = PRODUCTS.find(x => x.id === id); if (!p) return;
  if (WISH[id] != null) delete WISH[id]; else WISH[id] = prRange(p).min || 0;
  try { localStorage.setItem(WISH_KEY, JSON.stringify(WISH)); } catch (_) {}
  toast(WISH[id] != null ? L('บันทึกในรายการโปรดแล้ว', 'Saved to wishlist') : L('นำออกจากรายการโปรดแล้ว', 'Removed from wishlist'));
}
function vWishlist() {
  const ids = Object.keys(WISH).filter(id => PRODUCTS.some(p => p.id === id));
  let h = hdr(L('รายการโปรด', 'Wishlist')) + '<div class="pad sec"><span class="small muted">' + L(ids.length + ' ชิ้นที่ชอบ · บันทึกไว้ในเครื่องนี้', ids.length + ' saved · on this device') + '</span>';
  if (!ids.length) return h + '<p class="muted" style="text-align:center;padding:40px 10px">' + L('ยังไม่มีสินค้าที่ชอบ กด ♡ ที่หน้าสินค้าเพื่อเก็บไว้ที่นี่', 'Nothing saved yet — tap ♡ on a product') + '</p><button class="btn-o" data-a="tab" data-v="home">' + L('ดูสินค้าทั้งหมด', 'See all products') + '</button></div>';
  ids.forEach(id => {
    const p = PRODUCTS.find(x => x.id === id), pr = prRange(p), st = totalStock(p), b = brandById(p.brand), d = DEALS[id], saved = WISH[id], r = resolve(p);
    const note = !st ? [L('สินค้าหมดแล้ว', 'Sold out'), 'var(--bad)'] : saved && saved > pr.min ? [L('ราคาลดลงจากที่บันทึกไว้ ', 'Price dropped ') + money(saved - pr.min), 'var(--ok)'] : d ? [L('มีดีลราคาส่ง · ', 'Deal · ') + money(d.price), 'var(--wine)'] : null;
    h += '<div class="card" style="display:flex;gap:12px"><img src="' + esc(imgS(r.gal[0] || PLACEHOLDER, 200)) + '" alt="" style="width:92px;height:92px;border-radius:10px;object-fit:cover;' + (st ? '' : 'opacity:.5') + '">' +
      '<div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:3px"><span class="small" style="color:var(--wine);font-weight:600">' + esc(b.name) + '</span><b>' + esc(p.name) + '</b>' +
      '<span class="pr"><b style="color:var(--wine)">' + money(pr.min) + '</b>' + (pr.orig > pr.min ? '<s>' + money(pr.orig) + '</s>' : '') + '</span>' + (note ? '<span class="small" style="color:' + note[1] + '">' + note[0] + '</span>' : '') +
      '<div style="display:flex;gap:8px;margin-top:4px;align-items:center"><button class="btn" style="min-height:36px;font-size:13px" data-a="product" data-id="' + esc(id) + '">' + L('ดูสินค้า', 'View') + '</button>' + heartBtn(id) + '</div></div></div>';
  });
  return h + '</div>';
}

/* ---------- รูปโปรไฟล์สมาชิก: ค่าเริ่มต้นใช้รูปจาก LINE · อัปโหลดรูปเองได้ (เก็บในเครื่องนี้) ---------- */
const AVATAR_KEY = 'mera-avatar-v1';
const IC_CAM = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>';
function readAvatar() { try { const a = JSON.parse(localStorage.getItem(AVATAR_KEY) || 'null'); return a && (!A.sub || !a.sub || a.sub === A.sub) ? a.img : ''; } catch (_) { return ''; } }
const myAvatar = () => readAvatar() || A.pic || '';
function setAvatar(file) {
  if (!file || !/^image\//.test(file.type || 'image/')) return;
  const url = URL.createObjectURL(file), img = new Image();
  img.onload = () => {
    const n = 320, k = Math.min(img.naturalWidth, img.naturalHeight), c = document.createElement('canvas'); c.width = c.height = n;
    c.getContext('2d').drawImage(img, (img.naturalWidth - k) / 2, (img.naturalHeight - k) / 2, k, k, 0, 0, n, n);
    URL.revokeObjectURL(url);
    try { localStorage.setItem(AVATAR_KEY, JSON.stringify({ sub: A.sub || '', img: c.toDataURL('image/jpeg', 0.86) })); toast(L('เปลี่ยนรูปโปรไฟล์แล้ว', 'Profile photo updated')); }
    catch (_) { toast(L('บันทึกรูปไม่สำเร็จ ลองรูปที่เล็กลง', 'Could not save — try a smaller photo')); }
    render();
  };
  img.onerror = () => { URL.revokeObjectURL(url); toast(L('เปิดรูปนี้ไม่ได้ ลองรูป JPG/PNG', 'Could not open this image — try JPG/PNG')); };
  img.src = url;
}
function vProfile() {
  const m = readMember(), name = A.name || '';
  let h = '<div style="padding:calc(26px + env(safe-area-inset-top,0px)) 16px 10px;text-align:center"><b style="font-size:20px">' + L('โปรไฟล์', 'Profile') + '</b></div>';
  if (A.idToken || m) {
    const pic = myAvatar();
    h += '<div style="display:flex;flex-direction:column;align-items:center;gap:6px"><label class="avatar" aria-label="' + L('เปลี่ยนรูปโปรไฟล์', 'Change profile photo') + '">' +
      (pic ? '<img src="' + esc(pic) + '" alt="">' : '<span>' + esc((name || 'M')[0]) + '</span>') +
      '<i aria-hidden="true">' + IC_CAM + '</i><input type="file" accept="image/*" data-in="avatar" hidden></label>' +
      '<button class="link" data-a="avatarPick">' + L(pic ? 'เปลี่ยนรูปโปรไฟล์' : 'เพิ่มรูปโปรไฟล์', pic ? 'Change photo' : 'Add a photo') + '</button>' +
      (readAvatar() ? '<button class="link" data-a="avatarReset" style="margin-top:-6px;color:var(--mut)">' + L('ใช้รูปจาก LINE', 'Use my LINE photo') + '</button>' : '') +
      '<b style="font-size:20px">' + esc(name || L('สมาชิก Mera', 'Mera member')) + '</b><span class="pill">Mera Member</span></div>';
  }
  else h += '<div class="pad sec" style="align-items:center;text-align:center"><img src="' + MERA_LOGO + '" alt="" style="width:96px"><span class="muted" style="max-width:280px;line-height:1.6">' + L('เข้าสู่ระบบด้วย LINE เพื่อสั่งซื้อและดูออเดอร์ของคุณ', 'Log in with LINE to order and see your orders') + '</span>' +
    (A.liffId ? '<button class="btn-line" data-a="login" style="max-width:300px">' + IC.line + L('เข้าสู่ระบบด้วย LINE', 'Log in with LINE') + '</button>' : '') + '</div>';
  const row = (a, label, right, href) => href ? '<a class="prow" href="' + esc(href) + '" target="_blank" rel="noopener"><span>' + label + '</span>' + (right ? '<small class="muted">' + right + '</small>' : '') + IC.chev + '</a>'
    : '<button class="prow" data-a="' + a + '"><span>' + label + '</span>' + (right ? '<small class="muted">' + right + '</small>' : '') + IC.chev + '</button>';
  const cnt = checkoutOn() ? window.MeraCheckout.cartCount() : 0;
  h += '<div class="pad sec"><b style="font-size:18px">' + L('ทั่วไป', 'General') + '</b><div class="card" style="padding:2px 14px">' +
    (checkoutOn() ? row('orders', L('ออเดอร์ของฉัน', 'My orders')) + row('cart', L('ตะกร้า', 'Cart'), cnt + L(' ชิ้น', ' items')) : '') + row('wishgo', L('รายการโปรด', 'Wishlist'), wishCount() + L(' ชิ้น', ' items')) +
    row('lang', L('ภาษา', 'Language'), LANG === 'th' ? 'ไทย' : 'English') + row('how', L('วิธีสั่งซื้อดีล', 'How to order a deal')) + row('verify', 'Mera Verified') +
    row('', L('นโยบายความเป็นส่วนตัว', 'Privacy policy'), '', 'privacy.html') + row('', L('ติดต่อแอดมิน (LINE ' + LINE_ID + ')', 'Help & support (LINE ' + LINE_ID + ')'), '', 'https://line.me/R/ti/p/' + encodeURIComponent(LINE_ID)) +
    (S.admin ? row('', L('หน้าแอดมิน', 'Admin'), L('แบนเนอร์', 'Banners'), 'admin.html') : '') + '</div></div>';
  return h;
}

/* ---------- แผ่นล่าง / เมนู / สมัครสมาชิก ---------- */
function sheetHow() {
  const i = Math.min(S.how || 0, HOW.length - 1);
  return '<div class="grab"></div><div class="row" style="align-items:center"><h3>' + L('วิธีสั่งซื้อดีล', 'How to order a deal') + '</h3><button class="icbtn" data-a="closeSheet" aria-label="' + L('ปิด', 'Close') + '">' + IC.x + '</button></div>' +
    '<div class="hscroll" data-gal="how" data-k="how" style="padding:0;gap:0">' + HOW.map(([src, alt], k) => '<img class="howimg" src="' + esc(src) + '" alt="' + esc(alt) + '"' + (k ? ' loading="lazy"' : '') + ' style="width:100%">').join('') + '</div>' +
    '<div class="dots" data-dots="how">' + HOW.map((_, k) => '<span class="' + (k === i ? 'on' : '') + '"></span>').join('') + '</div>';
}
function sheetVerify() {
  return '<div class="grab"></div><div style="display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center"><img src="' + VERIFY_LG + '" alt="" style="width:108px;height:108px"><h3 style="font-size:20px">Mera Verified</h3><span class="muted">' + L('สินค้าทุกชิ้นบน Mera ผ่านการคัดเลือกตามนี้', 'Every item on Mera meets these standards') + '</span></div>' +
    '<div class="card sec" style="gap:9px">' + TRUST().map(t => '<span style="display:flex;gap:8px;align-items:center;font-size:14px"><span style="width:20px;height:20px;border-radius:50%;background:var(--wine);color:#fff;font-size:11px;display:flex;align-items:center;justify-content:center;flex:none">✓</span><b>' + esc(t) + '</b></span>').join('') + '</div>' +
    '<span class="small muted" style="line-height:1.6;text-align:center">' + L('ได้รับสินค้าไม่ตรงตามที่สั่ง แจ้งเราทาง LINE ได้เลย', 'Item not as ordered? Tell us on LINE') + '</span>' +
    '<button class="btn" data-a="closeSheet">' + L('เข้าใจแล้ว', 'Got it') + '</button>';
}
function vMenu() {
  return '<div class="menu" role="dialog" aria-modal="true"><div class="mi"><button class="icbtn" data-a="menu" aria-label="' + L('ปิด', 'Close') + '" style="background:none">' + IC.x + '</button><nav>' +
    '<button data-a="mtab" data-v="home">' + L('หน้าแรก', 'Home') + '</button><button data-a="mzone" data-v="shop">' + L('สินค้าทั้งหมด', 'All products') + '</button><button data-a="mzone" data-v="gb">' + L('ดีลราคาส่ง', 'Wholesale deals') + '</button>' +
    '<button data-a="mgo" data-v="brands">' + L('แบรนด์', 'Brands') + '</button><button data-a="wishgo">' + L('รายการโปรด', 'Wishlist') + '</button><button data-a="how">' + L('วิธีสั่งซื้อ', 'How to order') + '</button><button data-a="verify">Mera Verified</button>' +
    (checkoutOn() ? '<button data-a="orders">' + L('ออเดอร์ของฉัน', 'My orders') + '</button>' : '') +
    '<a href="https://line.me/R/ti/p/' + encodeURIComponent(LINE_ID) + '" target="_blank" rel="noopener">' + L('ติดต่อเรา', 'Contact us') + ' · LINE ' + LINE_ID + '</a>' + (S.admin ? '<a href="admin.html">' + L('หน้าแอดมิน', 'Admin') + '</a>' : '') + '</nav>' +
    '<div class="lang" role="group" aria-label="Language"><button class="' + (LANG === 'th' ? 'on' : '') + '" data-a="setLang" data-v="th">ไทย</button><button class="' + (LANG === 'en' ? 'on' : '') + '" data-a="setLang" data-v="en">English</button></div>' +
    '<span style="flex:1"></span>' + (A.liffId && !A.idToken && !readMember() ? '<button class="btn-line" data-a="login" style="max-width:300px;align-self:center">' + IC.line + L('เข้าสู่ระบบด้วย LINE', 'Log in with LINE') + '</button>' : '') + '</div></div>';
}
function vGate() {
  const g = S.gate; if (!g || g.mode === 'off') return '';
  const demo = g.demoOnly, step = g.step || 0, Q = GATE_Q[step], ans = g.ans || {};
  const n0 = demo ? DEMO_START : 0, n = GATE_Q.length - n0;
  let body = '';
  if (g.mode === 'loading') body = '<span class="spin"></span><span class="gsub" style="text-align:center">' + L('กำลังโหลด...', 'Loading...') + '</span>';
  else if (g.mode === 'saving') body = '<span class="spin"></span><span class="gsub" style="text-align:center">' + L('กำลังบันทึก...', 'Saving...') + '</span>';
  else if (g.mode === 'login') {
    const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    body = '<img src="' + MERA_LOGO + '" alt="MERA" style="height:38px;width:auto;align-self:flex-start"><h3>' + L('รวมสินค้าแฟชั่น Clearance แบรนด์ออนไลน์', 'Clearance fashion from online brands') + '</h3><p class="gsub">' + L('เข้าสู่ระบบด้วย LINE แล้วตอบคำถามสั้นๆ 4 ข้อ', 'Log in with LINE and answer 4 quick questions') + '</p>' +
      (mobile && !A.inLine ? '<button class="btn-line" data-a="gOpenApp">' + IC.line + L('เข้าสู่ระบบด้วยแอป LINE', 'Log in with the LINE app') + '</button><span class="small muted" style="text-align:center">' + L('ระบบจะเปิดแอป LINE ให้ แค่กด “อนุญาต” ไม่ต้องกรอกรหัส', 'Opens the LINE app — just tap “Allow”, no password') + '</span>' : '') +
      (!mobile ? '<div class="gqr"><img src="' + MERA_QR + '" alt="QR code" width="140" height="140"><div style="display:flex;flex-direction:column;gap:6px;font-size:13px;line-height:1.55;color:var(--ink2)"><b style="font-size:15px;color:var(--wine)">' + L('สแกนด้วยกล้องมือถือ', 'Scan with your phone') + '</b><span>' + L('เปิดในแอป LINE แล้วกด “อนุญาต” ก็เข้าดูสินค้าได้ทันที', 'Open in LINE and tap “Allow” to start browsing') + '</span></div></div>' +
        '<button class="link" data-a="login" style="align-self:center">' + L('ดูบนคอมนี้แทน (สแกน QR ในหน้า LINE)', 'Use this computer instead (scan the QR on the LINE page)') + '</button>' : '') +
      '<button class="btn-o" data-a="gBrowse">' + L('ดูสินค้าก่อน', 'Browse first') + '</button>';
  } else if (g.mode === 'quiz') {
    const sel = ans[Q.key], list = Q.multi ? (sel || []) : [];
    body = '<h3>' + esc(Q.q) + '</h3><p class="gsub">' + esc(Q.sub || '') + '</p>';
    // จังหวัด: ใช้รายการให้แตะเลือก + ช่องค้นหา แทน <select> (แก้บัคกดเลือกจังหวัดไม่ได้ในเบราว์เซอร์ของ LINE)
    if (Q.select) body += '<input class="gsearch" id="gq" data-in="gq" value="' + esc(S.gq || '') + '" placeholder="' + L('พิมพ์ค้นหาจังหวัด', 'Search province') + '" autocomplete="off" enterkeyhint="search">' +
      '<div class="glist" id="glist" role="listbox" aria-label="' + esc(Q.q) + '">' + gateList(Q, sel) + '</div>' +
      '<button class="btn" data-a="gSelNext"' + (sel ? '' : ' disabled') + '>' + (sel ? L('ถัดไป', 'Next') + ' · ' + esc(sel) : L('ถัดไป', 'Next')) + '</button>';
    else body += '<div class="gopts" style="grid-template-columns:repeat(' + (Q.cols || 2) + ',minmax(0,1fr))">' + Q.opts.map(o => '<button class="gopt' + ((Q.multi ? list.includes(o) : sel === o) ? ' on' : '') + '" data-a="gAns" data-v="' + esc(o) + '">' + esc(o) + '</button>').join('') + '</div>';
    if (Q.all) body += '<button class="btn-o" data-a="gAns" data-v="__all">' + esc(Q.all) + '</button>';
    if (Q.multi) body += '<button class="btn" data-a="gDone"' + (list.length ? '' : ' disabled') + '>' + L('เสร็จแล้ว', 'Done') + '</button>';
    body += '<div class="gfoot">' + (step > n0 ? '<button class="link" data-a="gBack">← ' + L('ย้อนกลับ', 'Back') + '</button>' : '') + (Q.skip ? '<button class="link" data-a="gSkip">' + L('ข้ามข้อนี้', 'Skip') + ' →</button>' : '') + '</div>';
  } else if (g.mode === 'done') body = '<div style="display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center">' + IC.star + '<h3>' + esc(A.name ? L('ยินดีต้อนรับค่ะ คุณ ' + A.name, 'Welcome, ' + A.name) : L('ยินดีต้อนรับค่ะ', 'Welcome')) + '</h3><p class="gsub">' + L('สมัครสมาชิกเรียบร้อย พร้อมเลือกไอเทมที่ชอบแล้ว', 'You are a member now — find something you love') + '</p></div><button class="btn" data-a="gEnter">' + L('ดูสินค้าทั้งหมด', 'See all products') + '</button>';
  else if (g.mode === 'error') body = '<h3>' + L('ขออภัยค่ะ', 'Sorry') + '</h3><p class="gsub">' + esc(g.err || '') + '</p><button class="btn" data-a="gRetry">' + L('ลองอีกครั้ง', 'Try again') + '</button>';
  const bars = GATE_Q.slice(n0).map((_, i) => '<i class="' + (g.mode === 'quiz' && i + n0 <= step ? 'on' : '') + '"></i>').join('');
  return '<div class="gate"><div class="gc" role="dialog" aria-modal="true" aria-label="' + L('สมัครสมาชิก Mera', 'Join Mera') + '"><div class="gh"><div class="row"><b style="font-size:15px">' + L('สมัครสมาชิก Mera', 'Join Mera') + '</b>' +
    (g.mode === 'quiz' ? '<b style="font-size:18px">' + (step - n0 + 1) + '/' + n + '</b>' : langBtn()) + '</div><div class="gbars" style="grid-template-columns:repeat(' + n + ',1fr)">' + bars + '</div></div><div class="gb">' + body + '</div></div></div>';
}

/* ---------- วาดหน้าจอ ---------- */
function render() {
  const app = document.getElementById('app'); if (!app) return;
  if (ED) endEdit();
  const keep = {}; app.querySelectorAll('[data-k]').forEach(el => { keep[el.getAttribute('data-k')] = el.scrollLeft; });
  const fid = document.activeElement && document.activeElement.id, fsel = fid && document.activeElement.selectionStart;
  const v = S.view;
  const body = { home: vHome, search: vSearch, brands: vBrands, brand: vBrand, product: vProduct, deal: vDeal, profile: vProfile, wishlist: vWishlist }[v] || vHome;
  const navOn = ['home', 'profile'].includes(v);
  app.innerHTML = '<main class="main">' + body() + '</main>' + (navOn ? '<nav class="bnav" aria-label="' + L('เมนูหลัก', 'Main menu') + '">' +
    [['home', IC.home, L('หน้าแรก', 'Home')], ['orders', IC.box, L('ออเดอร์', 'Orders')], ['profile', IC.user, L('โปรไฟล์', 'Profile')]].map(x => '<button class="' + (v === x[0] ? 'on' : '') + '" data-a="' + (x[0] === 'orders' ? 'orders' : 'tab') + '" data-v="' + x[0] + '"' + (v === x[0] ? ' aria-current="page"' : '') + '>' + x[1](v === x[0]) + x[2] + '</button>').join('') + '</nav>' : '');
  decorate(app);
  app.querySelectorAll('[data-k]').forEach(el => { const k = el.getAttribute('data-k'); if (keep[k]) el.scrollLeft = keep[k]; });
  if (fid) { const el = document.getElementById(fid); if (el) { el.focus(); try { el.setSelectionRange(fsel, fsel); } catch (_) {} } }
  document.documentElement.lang = LANG;
  renderOverlay();
}
function renderOverlay() {
  let ov = document.getElementById('ov'); if (!ov) { ov = document.createElement('div'); ov.id = 'ov'; document.body.appendChild(ov); }
  let h = '';
  if (S.sheet) h += '<div class="dim-bg" data-a="closeSheet"></div><div class="sheet" role="dialog" aria-modal="true">' + ({ how: sheetHow, verify: sheetVerify, size: sheetSize }[S.sheet] || (() => ''))() + '</div>';
  if (S.menu) h += vMenu();
  h += vGate();
  if (S.toast) h += '<div id="toast" role="status">' + esc(S.toast) + '</div>';
  if (ov._h !== h) { ov._h = h; ov.innerHTML = h; decorate(ov); }
  document.body.style.overflow = (S.sheet || S.menu || (S.gate && S.gate.mode !== 'off')) ? 'hidden' : '';
}

/* ---------- ปุ่มต่าง ๆ ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-a]'); if (!el) return;
  const a = el.getAttribute('data-a'), id = el.getAttribute('data-id'), v = el.getAttribute('data-v');
  if (a === 'bannerUrl') return;   // ลิงก์ภายนอกเปิดเอง
  if (el.tagName !== 'A') e.preventDefault();
  if (a === 'verify') { e.stopPropagation(); S.menu = false; S.sheet = 'verify'; renderOverlay(); track('verify', S.view === 'product' || S.view === 'deal' ? pinfo(S.params.id) : {}); return; }
  switch (a) {
    case 'back': return back();
    case 'go': return go(v);
    case 'tab': return tab(v);
    case 'mtab': S.menu = false; return tab(v);
    case 'mgo': S.menu = false; return go(v);
    case 'wish': toggleWish(id); return render();
    case 'avatarPick': { const f = document.querySelector('[data-in=avatar]'); if (f) f.click(); return; }
    case 'avatarReset': try { localStorage.removeItem(AVATAR_KEY); } catch (_) {} return render();
    case 'wishgo': S.menu = false; return go('wishlist');
    case 'mzone': S.menu = false; return followLink('zone:' + v);
    case 'product': return go('product', { id });
    case 'deal': return go('deal', { id });
    case 'brand': S.bcat = 'all'; return go('brand', { id });
    case 'cat': S.cat = v; return render();
    case 'bcat': S.bcat = v; return render();
    case 'zone': S.zone = v; render(); return scrollToId(v === 'gb' ? 'z-gb' : 'z-shop');
    case 'banner': return followLink(v);
    case 'menu': S.menu = !S.menu; return renderOverlay();
    case 'how': S.menu = false; S.sheet = 'how'; S.how = 0; return renderOverlay();
    case 'closeSheet': S.sheet = null; return renderOverlay();
    case 'acc': { const p = S.acc[v]; S.acc[v] = p === undefined ? !(v === 'size' || v === 'spec') : !p; return render(); }
    case 'unit': S.unit = v; return S.sheet ? (renderOverlay(), render()) : render();
    case 'sizeSheet': S.sheet = 'size'; return renderOverlay();
    case 'pickc': pick(id, { color: v }); S.gi = {}; return render();
    case 'picks': pick(id, { size: v }); return render();
    case 'qty': { const p = PRODUCTS.find(x => x.id === id), r = resolve(p, S.view === 'deal'); pick(id, { qty: Math.max(1, Math.min(r.stock, r.qty + Number(v))) }); return render(); }
    case 'buyNow': case 'addCart': if (EDIT) return toast('โหมดแก้ข้อความ: ปุ่มสั่งซื้อปิดไว้');
    {
      const p = PRODUCTS.find(x => x.id === id), r = resolve(p, false);
      if (!(r.stock > 0) || !checkoutOn()) return;
      track('buy', Object.assign(pinfo(p.id), { detail: [r.color, r.size, r.row[2], 'x' + r.qty].filter(Boolean).join(' / ') }));
      const item = itemOf(p, r);
      if (a === 'buyNow') window.MeraCheckout.open(item);
      else { const n = window.MeraCheckout.add(item, { open: false }); toast(L('เพิ่มลงตะกร้าแล้ว · ในตะกร้า ', 'Added to cart · ') + n + L(' ชิ้น', ' in cart')); render(); }
      return;
    }
    case 'copyMsg': { const p = PRODUCTS.find(x => x.id === id); return copyText(orderMsg(p, resolve(p, false)), () => toast(L('คัดลอกแล้ว วางในแชท LINE ได้เลย', 'Copied — paste it in LINE'))); }
    case 'bookDeal':   // สมัครสมาชิก (ครั้งแรกครั้งเดียว) ก่อนไปจองดีล
      if (!checkoutOn() || !window.MeraCheckout.requireMember) { location.href = v; return; }
      toast(L('กำลังตรวจสอบสมาชิก…', 'Checking membership…'));
      window.MeraCheckout.requireMember(() => { location.href = v; }, v);
      return;
    case 'copyDeal': return copyText('ดีล ' + v, () => toast(L('คัดลอกแล้ว วางในแชท LINE ได้เลย', 'Copied — paste it in LINE')));
    case 'cart': if (checkoutOn()) { if (window.MeraCheckout.cartCount()) window.MeraCheckout.openCart(); else toast(L('ยังไม่มีสินค้าในตะกร้า', 'Your cart is empty')); } return;
    case 'orders': S.menu = false; renderOverlay(); if (checkoutOn()) window.MeraCheckout.openOrders(); else window.open('https://line.me/R/ti/p/' + encodeURIComponent(LINE_ID), '_blank'); return;
    case 'lang': LANG = LANG === 'th' ? 'en' : 'th'; try { localStorage.setItem('mera-lang', LANG); } catch (_) {} return render();
    case 'setLang': LANG = v; try { localStorage.setItem('mera-lang', LANG); } catch (_) {} return render();
    case 'recent': S.q = v; return render();
    case 'clearRecent': RECENT = []; try { localStorage.removeItem('mera-recent'); } catch (_) {} return render();
    case 'login': S.menu = false; renderOverlay(); return gateLogin();
    case 'gOpenApp': location.href = 'https://liff.line.me/' + A.liffId; return;
    case 'gAns': return gateAnswer(v);
    case 'gDone': { const g = S.gate, Q = GATE_Q[g.step || 0]; if ((g.ans[Q.key] || []).length) setGate({ step: (g.step || 0) + 1 }); return; }
    case 'gProv': {
      const g = S.gate, Q = GATE_Q[g.step || 0]; g.ans = Object.assign({}, g.ans || {}, { [Q.key]: v });
      document.querySelectorAll('.gprov').forEach(b => { const on = b.getAttribute('data-v') === v; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); });
      const nb = document.querySelector('[data-a=gSelNext]'); if (nb) { nb.disabled = false; nb.textContent = Lraw('ถัดไป', 'Next') + ' · ' + v; }
      return;
    }
    case 'gSelNext': { S.gq = ''; const g = S.gate, Q = GATE_Q[g.step || 0]; if ((g.ans || {})[Q.key]) gateNext(g.ans); return; }
    case 'gBack': return setGate({ step: (S.gate.step || 0) - 1 });
    case 'gSkip': return gateSkip();
    case 'gEnter': return setGate({ mode: 'off' });
    case 'gBrowse': A.browse = true; try { sessionStorage.setItem('mera-browse', '1'); } catch (_) {} return setGate({ mode: 'off' });
    case 'gRetry': return S.gate.retry ? gateSubmit(S.gate.retry) : location.reload();
  }
});
document.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role=button][data-a]')) { e.preventDefault(); e.target.click(); } if (e.key === 'Escape' && (S.sheet || S.menu)) { S.sheet = null; S.menu = false; renderOverlay(); } });
document.addEventListener('input', e => {
  const k = e.target.getAttribute && e.target.getAttribute('data-in');
  if (k === 'gq') { S.gq = e.target.value; const g = S.gate, box = document.getElementById('glist'); if (box && g) { box.innerHTML = gateList(GATE_Q[g.step || 0], (g.ans || {})[GATE_Q[g.step || 0].key]); decorate(box); } return; }
  if (k === 'q') { S.q = e.target.value; const box = document.getElementById('sres'); if (box) { box.innerHTML = searchResults(); decorate(box); } else render(); }
});
document.addEventListener('change', e => {
  const k = e.target.getAttribute && e.target.getAttribute('data-in');
  if (k === 'q' && S.q.trim()) { RECENT = [S.q.trim(), ...RECENT.filter(x => x !== S.q.trim())].slice(0, 8); try { localStorage.setItem('mera-recent', JSON.stringify(RECENT)); } catch (_) {} }
  if (k === 'avatar') { setAvatar(e.target.files && e.target.files[0]); return; }
  if (k === 'gsel') { const g = S.gate, Q = GATE_Q[g.step || 0]; setGate({ ans: Object.assign({}, g.ans || {}, { [Q.key]: e.target.value }) }); }
});
// แกลเลอรี: อัปเดตจุด / ตัวนับโดยไม่วาดใหม่ทั้งหน้า
document.addEventListener('scroll', e => {
  const el = e.target; if (!el || !el.getAttribute) return;
  const key = el.getAttribute('data-gal') || (el.getAttribute('data-k') === 'bn' ? 'bn' : null); if (!key) return;
  const w = key === 'bn' ? (el.firstElementChild ? el.firstElementChild.getBoundingClientRect().width + 12 : el.clientWidth) : el.clientWidth;
  const i = Math.round(el.scrollLeft / Math.max(1, w));
  if (key === 'how') S.how = i; else if (key !== 'bn') S.gi[key] = i;
  document.querySelectorAll('[data-dots="' + key + '"] span').forEach((s, k) => s.classList.toggle('on', k === i));
  const c = document.querySelector('[data-cnt="' + key + '"]'); if (c) c.textContent = (i + 1) + ' / ' + document.querySelectorAll('[data-dots="' + key + '"] span').length;
}, true);
document.addEventListener('mera:cart', () => render());

/* =====================================================================
 * สมัครสมาชิกด้วย LINE (ตรรกะเดียวกับเว็บเดิม · _gateBoot / _initGate / _gateSubmit)
 * ===================================================================== */
function gateList(Q, sel) {
  const q = String(S.gq || '').trim();
  const list = Q.opts.filter(o => !q || o.includes(q));
  return list.length ? list.map(o => '<button type="button" role="option" aria-selected="' + (sel === o) + '" class="gprov' + (sel === o ? ' on' : '') + '" data-a="gProv" data-v="' + esc(o) + '">' + esc(o) + '</button>').join('') : '<span class="small muted">' + L('ไม่พบจังหวัด', 'No province found') + '</span>';
}
function setGate(patch) { S.gate = Object.assign({}, S.gate || {}, patch); renderOverlay(); }
const apiUrl = () => String(API_URL || '').trim();
function gateBoot() {
  let cached = null; try { cached = JSON.parse(localStorage.getItem(LIVE_CACHE) || 'null'); } catch (_) {}
  const id = LIFF_ID || (cached && cached.config && cached.config.liffId);
  if (id) { initGate(id); return; }
  if (!readMember() && /^https:/.test(apiUrl())) {
    S.gate = { mode: 'loading', step: 0, ans: {} }; renderOverlay();
    A.gateTimer = setTimeout(gateNoConfig, 8000);
  }
}
function gateFromData(d) { const id = LIFF_ID || (d && d.config && d.config.liffId); if (id) initGate(id); else gateNoConfig(); }
function gateNoConfig() { clearTimeout(A.gateTimer); if (!A.gateStarted && S.gate && S.gate.mode === 'loading') setGate({ mode: 'off' }); }
async function initGate(liffId) {
  if (A.gateStarted || !/^\d{6,}-\w+$/.test(String(liffId))) return;
  A.gateStarted = true; A.liffId = liffId; clearTimeout(A.gateTimer);
  window.__gateRetry = () => { A.gateStarted = false; initGate(liffId); };
  A.api = (action, extra) => fetch(apiUrl(), { method: 'POST', body: JSON.stringify(Object.assign({ action, idToken: A.idToken }, extra || {})) }).then(r => r.json());
  const cached = readMember();
  S.gate = { mode: 'off', step: 0, ans: {} }; render();
  try {
    const liff = await loadLiff();
    await liff.init({ liffId });
    A.liff = liff;
    A.inLine = !!(liff.isInClient && liff.isInClient());
    if (!liff.isLoggedIn()) {
      if (A.inLine) { liff.login(); return; }
      let browse = false; try { browse = sessionStorage.getItem('mera-browse') === '1'; } catch (_) {}
      setGate({ mode: 'off' });   // ดูสินค้าได้เลย · สมัครสมาชิกตอนกดซื้อ/จองดีล (checkout.js)
      render(); return;
    }
    const tok = liff.getDecodedIDToken() || {};
    A.idToken = liff.getIDToken();
    trackFriend();
    A.sub = tok.sub; A.name = tok.name || ''; A.pic = tok.picture || '';
    try { liff.getProfile().then(pf => { if (pf) { A.pic = pf.pictureUrl || A.pic; A.name = pf.displayName || A.name; render(); } }).catch(() => {}); } catch (_) {}
    checkAdmin(); render();
    if (cached && cached.sub === tok.sub && (cached.v || 0) >= PROFILE_VERSION) return;
    const r = await A.api('me');
    if (r.ok && r.member && (r.member.v || 0) >= PROFILE_VERSION) { writeMember(Object.assign({ sub: tok.sub }, r.member)); setGate({ mode: 'off' }); }
    else if (r.error === 'login_expired') { liff.logout(); }
    setGate({ mode: 'off' });   // คำถามสมาชิกถามครั้งเดียวในหน้าสั่งซื้อ/จองดีล
  } catch (e) {
    console.warn('[mera] gate', e);
    setGate({ mode: 'off' });
  }
}
function gateLogin() { loadLiff().then(l => l.login({ redirectUri: location.href.split('#')[0] })); }
function gateAnswer(o) {
  const g = S.gate, step = g.step || 0, Q = GATE_Q[step];
  const ans = Object.assign({}, g.ans || {});
  if (Q.multi) {
    if (o === '__all') { ans[Q.key] = [Q.all]; setGate({ ans, step: step + 1 }); return; }
    const cur = (ans[Q.key] || []).filter(x => x !== Q.all);
    ans[Q.key] = cur.includes(o) ? cur.filter(x => x !== o) : cur.concat([o]);
    setGate({ ans }); return;
  }
  ans[Q.key] = o;
  gateNext(ans);
}
function gateNext(ans) { const step = S.gate.step || 0; if (step + 1 < GATE_Q.length) setGate({ ans, step: step + 1 }); else { setGate({ ans }); gateSubmit(ans); } }
function gateSkip() { const g = S.gate, Q = GATE_Q[g.step || 0]; gateNext(Object.assign({}, g.ans || {}, { [Q.key]: '' })); }
async function gateSubmit(ans) {
  setGate({ mode: 'saving' });
  const fail = () => setGate({ mode: 'error', err: L('บันทึกไม่สำเร็จ ลองใหม่อีกครั้งนะคะ', 'Could not save. Please try again'), retry: ans });
  try {
    const src = (S.gate && S.gate.demoOnly) ? Object.fromEntries(Object.entries(ans).filter(([k]) => GATE_Q.some(q => q.demo && q.key === k))) : ans;
    const payload = Object.assign({}, src, { v: PROFILE_VERSION });
    if (src.notify !== undefined) payload.notify = src.notify === 'รับแจ้งเตือน';
    try { localStorage.setItem('mera-gate-ans', JSON.stringify(Object.assign(JSON.parse(localStorage.getItem('mera-gate-ans') || '{}'), src))); } catch (_) {}
    const r = await A.api('register', { answers: payload });
    if (r.ok) { writeMember(Object.assign({ sub: A.sub }, r.member)); setGate({ mode: 'done' }); }
    else if (r.error === 'login_expired') { window.liff && window.liff.logout(); setGate({ mode: 'login' }); }
    else fail();
  } catch (e) { fail(); }
}
// ปุ่มแอดมิน: โผล่เฉพาะบัญชี LINE ที่อยู่ในรายชื่อ ADMIN_LINE_IDS (ตรวจที่ Apps Script)
function checkAdmin() {
  if (!A.idToken) return;
  ckPost('adminCheck', { idToken: A.idToken }).then(j => { if (j && j.ok && j.admin && !S.admin) { S.admin = true; render(); } }).catch(() => {});
}

/* =====================================================================
 * เก็บพฤติกรรมลูกค้า (ตรรกะเดียวกับเว็บเดิม · _track / _flush)
 * ===================================================================== */
function pinfo(id) { const p = PRODUCTS.find(x => x.id === id) || {}; const b = BRANDS.find(x => x.id === p.brand) || {}; return { brand: b.name || '', product: p.name || '' }; }
function trackView() {
  if (S.view === 'product') track('view', Object.assign(pinfo(S.params.id), { deal: '' }));
  if (S.view === 'deal' && DEALS[S.params.id]) track('deal_view', Object.assign(pinfo(S.params.id), { deal: DEALS[S.params.id].code }));
}
function trackFriend() { try { const l = A.liff; if (l && l.getFriendship) l.getFriendship().then(f => { A.friend = !!(f && f.friendFlag); flushSoon(); }).catch(() => {}); } catch (_) {} }
function track(e, extra) { if (!A.idToken) return; (A.tq = A.tq || []).push(Object.assign({ e, t: Date.now() }, extra || {})); if (A.tq.length >= 10) flush(); else flushSoon(); }
function flushSoon() { clearTimeout(A.ft); A.ft = setTimeout(flush, 8000); }
function flush() {
  clearTimeout(A.ft);
  const events = (A.tq || []).splice(0), friend = A.friend; A.friend = undefined;
  if (!events.length && friend === undefined) return;
  let tok = A.idToken; try { tok = (A.liff && A.liff.getIDToken()) || tok; } catch (_) {}
  const url = apiUrl(); if (!tok || !/^https:/.test(url)) return;
  try { fetch(url, { method: 'POST', keepalive: true, body: JSON.stringify({ action: 'track', idToken: tok, events, friend }) }).catch(() => {}); } catch (_) {}
}
document.addEventListener('click', ev => {
  const a = ev.target && ev.target.closest && ev.target.closest('a[href]'); if (!a) return;
  const href = a.getAttribute('href') || '';
  if (/oaMessage/.test(href) && S.view === 'product') {
    const p = PRODUCTS.find(x => x.id === S.params.id); if (!p) return; const r = resolve(p, false);
    track('order', Object.assign(pinfo(p.id), { detail: [r.color, r.size, r.row && r.row[2], 'x' + r.qty].filter(Boolean).join(' / ') }));
    return;
  }
  const id = Object.keys(DEALS).find(k => dealLink(DEALS[k]) === href);
  if (id) { const p = PRODUCTS.find(x => x.id === id); const r = p && S.view === 'deal' && S.params.id === id ? resolve(p, true) : null; track('book', Object.assign(pinfo(id), { deal: DEALS[id].code, detail: r ? [r.color, r.size, 'x' + r.qty].filter(Boolean).join(' / ') : '' })); }
}, true);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
window.addEventListener('pagehide', flush);

/* =====================================================================
 * โหลดข้อมูลสินค้า (เหมือนเว็บเดิม: แสดงจากแคชก่อน แล้วดึงใหม่ทุก 60 วินาที)
 * ===================================================================== */
/* ---------- แก้ข้อความบนหน้า (เฉพาะโหมดแก้ข้อความ) ---------- */
let ED = null;   // { span, key, bar }
function editBoot() {
  TXT = ADMIN.texts() || {}; LANG = ADMIN.lang && ADMIN.lang() === 'en' ? 'en' : 'th';
  document.body.classList.toggle('tk-edit', ADMIN.mode() === 'edit');
  window.meraEdit = {
    setTexts(t) { TXT = t || {}; endEdit(); render(); },
    setLang(l) { LANG = l === 'en' ? 'en' : 'th'; endEdit(); render(); },
    setMode(m) { document.body.classList.toggle('tk-edit', m === 'edit'); endEdit(); },
  };
  render();
  document.addEventListener('click', e => {
    if (!document.body.classList.contains('tk-edit')) return;
    const bar = e.target.closest('.tkbar'); if (bar) return;
    if (ED && e.target.closest('.tk') === ED.span) { e.preventDefault(); e.stopPropagation(); return; }
    const sp = e.target.closest('.tk'); if (!sp) { if (ED) { e.preventDefault(); e.stopPropagation(); endEdit(); } return; }
    e.preventDefault(); e.stopPropagation(); startEdit(sp);
  }, true);
  document.addEventListener('keydown', e => {
    if (!ED || e.target !== ED.span) return;
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); saveEdit(); }
    if (e.key === 'Escape') { e.preventDefault(); endEdit(); render(); }
    e.stopPropagation();
  }, true);
  window.addEventListener('scroll', placeBar, true); window.addEventListener('resize', placeBar);
}
function startEdit(sp) {
  endEdit();
  const key = EK[+sp.getAttribute('data-tk')], o = TXT[key] || {}, en = ADMIN.en(key);
  const other = LANG === 'en' ? 'th' : 'en';
  sp.contentEditable = 'true'; sp.classList.add('tk-act'); sp.spellcheck = false; sp.focus();
  try { const r = document.createRange(); r.selectNodeContents(sp); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); } catch (_) {}
  const bar = document.createElement('div'); bar.className = 'tkbar';
  bar.innerHTML = '<div class="tkr"><small>' + (LANG === 'en' ? 'English (กำลังแก้บนหน้า)' : 'ภาษาไทย (กำลังแก้บนหน้า)') + ' · ค่าเดิม: ' + esc(LANG === 'en' ? en : key) + '</small></div>' +
    '<label class="tkr"><small>' + (other === 'en' ? 'English' : 'ภาษาไทย') + '</small><input class="tkin" value="' + esc(o[other] || '') + '" placeholder="' + esc(other === 'en' ? en : key) + '"></label>' +
    '<div class="tkb"><button type="button" data-x="save">บันทึก</button><button type="button" data-x="reset"' + (o.th || o.en ? '' : ' disabled') + '>คืนค่าเดิม</button><button type="button" data-x="cancel">ยกเลิก</button></div>';
  document.body.appendChild(bar);
  bar.addEventListener('click', e => { const x = e.target.getAttribute('data-x'); if (x === 'save') saveEdit(); if (x === 'cancel') { endEdit(); render(); } if (x === 'reset') saveEdit(true); });
  bar.querySelector('.tkin').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); saveEdit(); } if (e.key === 'Escape') { endEdit(); render(); } });
  ED = { span: sp, key, bar, other };
  placeBar();
}
function placeBar() {
  if (!ED) return;
  const r = ED.span.getBoundingClientRect(), b = ED.bar, h = b.offsetHeight || 150, vh = innerHeight;
  b.style.left = Math.max(8, Math.min(innerWidth - b.offsetWidth - 8, r.left)) + 'px';
  b.style.top = (r.bottom + h + 12 < vh ? r.bottom + 8 : Math.max(8, r.top - h - 8)) + 'px';
}
function endEdit() { if (!ED) return; ED.bar.remove(); ED.span.contentEditable = 'false'; ED.span.classList.remove('tk-act'); ED = null; }
function saveEdit(reset) {
  if (!ED) return;
  const { span, key, bar, other } = ED, cur = LANG;
  const defCur = cur === 'en' ? ADMIN.en(key) : key, defOther = other === 'en' ? ADMIN.en(key) : key;
  let vCur = reset ? '' : span.innerText.replace(/\s+/g, ' ').trim(), vOther = reset ? '' : bar.querySelector('.tkin').value.replace(/\s+/g, ' ').trim();
  if (vCur === defCur) vCur = ''; if (vOther === defOther) vOther = '';
  const th = cur === 'th' ? vCur : vOther, en = cur === 'en' ? vCur : vOther;
  bar.querySelectorAll('button').forEach(x => { x.disabled = true; }); bar.querySelector('[data-x=save]').textContent = 'กำลังบันทึก…';
  ADMIN.save(key, th, en).then(t => { TXT = t || TXT; endEdit(); render(); toast(reset ? 'คืนค่าเดิมแล้ว' : 'บันทึกแล้ว'); })
    .catch(err => { bar.querySelectorAll('button').forEach(x => { x.disabled = false; }); bar.querySelector('[data-x=save]').textContent = 'บันทึก'; toast(err.message || 'บันทึกไม่สำเร็จ'); });
}

let lastRaw = '';
function load() {
  const url = apiUrl(); if (!/^https:/.test(url)) return;
  fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now())
    .then(r => r.text())
    .then(t => {
      const d = JSON.parse(t);
      if (!applyLive(d)) return;
      try { localStorage.setItem(LIVE_CACHE, t); } catch (_) {}
      gateFromData(d);
      if (t !== lastRaw) { lastRaw = t; S.live = d.updatedAt; render(); }
    })
    .catch(e => { console.warn('[mera] live data failed', e); gateNoConfig(); });
}
(function boot() {
  document.addEventListener('error', e => { const el = e.target; if (el && el.tagName === 'IMG' && /^https?:/.test(el.currentSrc || el.src) && !el.dataset.fb) { el.dataset.fb = '1'; el.src = PLACEHOLDER; } }, true);
  try { const raw = localStorage.getItem(LIVE_CACHE); const c = JSON.parse(raw || 'null'); if (applyLive(c)) { S.live = c.updatedAt; lastRaw = raw; } } catch (_) {}
  try { history.replaceState({ mv: 0 }, ''); } catch (_) {}
  render();
  if (!lastRaw) {   // ลูกค้าใหม่: ใช้ไฟล์ข้อมูลบนเว็บก่อน (เร็ว) แล้วค่อยอัปเดตจาก Apps Script
    fetch('data/catalog.json', { cache: 'no-cache' })
      .then(r => (r.ok ? r.text() : null))
      .then(t => {
        if (!t || lastRaw) return;
        const d = JSON.parse(t);
        if (applyLive(d)) { lastRaw = t; S.live = d.updatedAt; render(); }
      })
      .catch(() => {});
  }
  load();
  if (EDIT) { editBoot(); loadContent(); return; }
  setInterval(() => { if (document.visibilityState !== 'hidden') load(); }, LIVE_REFRESH_MS);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') load(); });
  gateBoot();
  loadContent();
})();
