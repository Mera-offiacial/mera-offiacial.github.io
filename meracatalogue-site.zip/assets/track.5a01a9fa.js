/*!
 * Mera — ที่มาของคนเข้าเว็บ (21 พ.ย. 2026)
 * ------------------------------------------------------------
 * เก็บว่าคนเข้าเว็บมาจากไหน (ลิงก์ utm / เว็บที่ส่งต่อมา / พิมพ์เข้าเอง) แม้ยังไม่ล็อกอิน
 * แล้วส่งไปบันทึกที่แท็บ Traffic ใน KPI Tracker ผ่าน Apps Script "Mera Traffic" (Traffic.gs)
 *
 * ตั้งค่าใน index.html (ก่อนไฟล์นี้):
 *   <script>window.MERA_TRACK = { api: 'https://script.google.com/macros/s/xxxx/exec' };</script>
 *   api ว่าง = ยังจำที่มาไว้ในเครื่อง แต่ไม่ส่งไปชีต
 *
 * ลิงก์: https://meraofficial.co/?utm_source=instagram&utm_medium=social&utm_campaign=zensation
 *   อ่านได้ทั้งใน ?… , #… และ ?liff.state=… (ตอนเปิดผ่าน LINE)
 *
 * เหตุการณ์ที่ส่ง: visit (เข้าเว็บ 1 ครั้งต่อรอบ หรือเข้าด้วยลิงก์ utm ใหม่) · view (ดูสินค้า/ดีล)
 *   · login (ล็อกอิน LINE → ผูกเครื่องนี้กับ LINE ID) · order (สั่งซื้อสำเร็จ)
 * ทุกเหตุการณ์มีที่มาครั้งแรก (first) และล่าสุด (last) ของเครื่องนี้ติดไปด้วย
 *
 * ใช้จากไฟล์อื่น: MeraTrack.view({ kind, id, brand, product, deal }) · MeraTrack.login(idToken)
 *   คำสั่งซื้อ: ฟัง event 'mera:order' ที่ checkout.js ส่งอยู่แล้ว
 */
(function () {
  'use strict';
  var CFG = Object.assign({ api: '' }, window.MERA_TRACK || {});
  var FIRST = 'mt_first', LAST = 'mt_last', SID = 'mt_sid', DEV = 'mc_dev';
  var LAST_DAYS = 30, SESSION_MIN = 30;
  var OWN = /(^|\.)meraofficial\.co$|(^|\.)mera-offiacial\.github\.io$|^localhost$|^127\.0\.0\.1$/;
  // เว็บที่ไม่นับเป็นที่มา (หน้าล็อกอิน LINE / LIFF เด้งกลับมา)
  var SKIP = /(^|\.)(access\.line\.me|liff\.line\.me|liff-gateway\.lineml\.jp|api\.line\.me)$/;
  // ชื่อเว็บ → ชื่อช่องทาง (ให้ตรงกับ utm_source ที่ใช้ในลิงก์)
  var HOSTS = [
    [/(^|\.)(instagram\.com|l\.instagram\.com)$/, 'instagram', 'social'],
    [/(^|\.)(facebook\.com|fb\.com|fb\.me|messenger\.com)$/, 'facebook', 'social'],
    [/(^|\.)(tiktok\.com|tiktokv\.com)$/, 'tiktok', 'social'],
    [/(^|\.)(line\.me|line-apps\.com)$/, 'line', 'social'],
    [/(^|\.)(t\.co|twitter\.com|x\.com)$/, 'x', 'social'],
    [/(^|\.)(threads\.net|threads\.com)$/, 'threads', 'social'],
    [/(^|\.)(youtube\.com|youtu\.be)$/, 'youtube', 'social'],
    [/(^|\.)(pinterest\.[a-z.]+)$/, 'pinterest', 'social'],
    [/(^|\.)(google\.[a-z.]+)$/, 'google', 'organic'],
    [/(^|\.)(bing\.com)$/, 'bing', 'organic'],
    [/(^|\.)(linktr\.ee|lit\.link|beacons\.ai)$/, 'linkinbio', 'referral'],
  ];

  function ls(k, v) {
    try {
      if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null');
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) { return null; }
  }
  function ss(k, v) {
    try {
      if (v === undefined) return sessionStorage.getItem(k);
      sessionStorage.setItem(k, v);
    } catch (e) { return null; }
  }
  function uuid() {
    try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
    });
  }
  function clean(s, n) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n || 100); }
  function low(s, n) { return clean(s, n).toLowerCase(); }

  /** รหัสเครื่อง: ใช้ตัวเดียวกับที่ checkout.js ใช้นับคนรับโค้ด (mc_dev) */
  function deviceId() {
    var d = '';
    try { d = localStorage.getItem(DEV) || ''; if (!d) { d = uuid(); localStorage.setItem(DEV, d); } } catch (e) { d = d || ss('mt_dev') || uuid(); ss('mt_dev', d); }
    return d;
  }

  /** อ่านค่า utm จาก ?… #… และ liff.state */
  function readParams() {
    var out = {}, parts = [location.search.replace(/^\?/, ''), (location.hash || '').replace(/^#/, '')];
    var st = /[?&]liff\.state=([^&]+)/.exec(location.search);
    if (st) { try { var s = decodeURIComponent(st[1]); parts.push(s.replace(/^[^?#]*[?#]?/, '')); } catch (e) {} }
    parts.join('&').split(/[&?#]/).forEach(function (kv) {
      var i = kv.indexOf('='); if (i < 1) return;
      var k = kv.slice(0, i).toLowerCase(), v = kv.slice(i + 1);
      try { v = decodeURIComponent(v.replace(/\+/g, ' ')); } catch (e) {}
      if (/^utm_(source|medium|campaign|content|term)$/.test(k) && !out[k]) out[k] = v;
      if ((k === 'fbclid' || k === 'ttclid' || k === 'gclid' || k === 'igshid') && !out.click) out.click = k;
      if ((k === 'code' || k === 'coupon' || k === 'promo') && !out.code) out.code = v;
    });
    return out;
  }

  /** ที่มาของการเข้าครั้งนี้ · null = มาจากหน้าเว็บเราเอง / หน้าล็อกอิน (ไม่เปลี่ยนที่มาเดิม) */
  function detect() {
    var p = readParams(), ref = '', host = '';
    try { ref = document.referrer || ''; host = ref ? new URL(ref).hostname.toLowerCase() : ''; } catch (e) {}
    if (p.utm_source || p.utm_campaign) {
      return {
        source: low(p.utm_source || 'unknown', 60), medium: low(p.utm_medium, 60), campaign: low(p.utm_campaign, 80),
        content: clean(p.utm_content, 80), term: clean(p.utm_term, 80), ref: host, code: clean(p.code, 40).toUpperCase(),
      };
    }
    if (host && (OWN.test(host) || SKIP.test(host))) return null;
    if (host) {
      for (var i = 0; i < HOSTS.length; i++) if (HOSTS[i][0].test(host)) return { source: HOSTS[i][1], medium: HOSTS[i][2], campaign: '', content: '', term: '', ref: host, code: clean(p.code, 40).toUpperCase() };
      return { source: host.replace(/^www\./, ''), medium: 'referral', campaign: '', content: '', term: '', ref: host, code: clean(p.code, 40).toUpperCase() };
    }
    // ไม่มี referrer: แอปที่ตัด referrer ทิ้ง (เช่น เบราว์เซอร์ในแอป) ยังพอเดาได้จาก user agent / click id
    var ua = navigator.userAgent || '';
    var inApp = /Instagram/i.test(ua) ? 'instagram' : /FBAN|FBAV|FB_IAB/i.test(ua) ? 'facebook' : /musical_ly|BytedanceWebview|TikTok/i.test(ua) ? 'tiktok' : /\bLine\//i.test(ua) ? 'line' : '';
    if (!inApp && p.click) inApp = p.click === 'fbclid' ? 'facebook' : p.click === 'ttclid' ? 'tiktok' : p.click === 'gclid' ? 'google' : p.click === 'igshid' ? 'instagram' : '';
    if (inApp) return { source: inApp, medium: 'social', campaign: '', content: '', term: '', ref: '', code: clean(p.code, 40).toUpperCase(), guess: 1 };
    return { source: 'direct', medium: '', campaign: '', content: '', term: '', ref: '', code: clean(p.code, 40).toUpperCase(), direct: 1 };
  }

  function device() {
    var ua = navigator.userAgent || '';
    var kind = /iPad|Tablet/i.test(ua) ? 'tablet' : /Mobi|Android|iPhone/i.test(ua) ? 'mobile' : 'desktop';
    var app = /Instagram/i.test(ua) ? 'ig-app' : /FBAN|FBAV|FB_IAB/i.test(ua) ? 'fb-app' : /musical_ly|BytedanceWebview|TikTok/i.test(ua) ? 'tiktok-app' : /\bLine\//i.test(ua) ? 'line-app' : '';
    var pwa = false; try { pwa = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; } catch (e) {}
    return [kind, app, pwa ? 'pwa' : ''].filter(Boolean).join(' ');
  }

  /* ---------- ที่มาครั้งแรก / ล่าสุด ---------- */
  var now = Date.now(), hit = detect();
  var first = ls(FIRST), last = ls(LAST);
  if (last && now - (last.at || 0) > LAST_DAYS * 864e5) last = null;
  var fresh = false;   // เข้าด้วยที่มาใหม่ (ไม่ใช่ direct / ไม่ใช่หน้าเราเอง)
  if (hit) {
    hit.at = now;
    if (!first) { first = hit; ls(FIRST, first); }
    // direct ไม่ทับที่มาล่าสุดที่รู้แล้ว (คนกดลิงก์ IG แล้ววันหลังพิมพ์ชื่อเว็บเข้ามาเอง = ยังนับให้ IG)
    if (!hit.direct || !last) {
      fresh = !last || last.source !== hit.source || last.campaign !== hit.campaign || last.content !== hit.content;
      last = hit; ls(LAST, last);
    }
  }
  if (!last) last = first;

  /* ---------- รอบการเข้า (session): หมดเมื่อไม่ได้ใช้งาน 30 นาที ---------- */
  var sess = null; try { sess = JSON.parse(ss(SID) || 'null'); } catch (e) {}
  var newSession = !sess || now - (sess.at || 0) > SESSION_MIN * 6e4;
  if (newSession) sess = { id: uuid().slice(0, 8), at: now };
  function touch() { sess.at = Date.now(); ss(SID, JSON.stringify(sess)); }
  touch();

  /* ---------- ส่ง ---------- */
  var Q = [], timer = 0, token = '';
  function base() {
    return {
      vid: deviceId(), sid: sess.id, page: clean(location.pathname, 80), dev: device(), lang: clean(navigator.language, 10),
      src: last ? last.source : '', med: last ? last.medium : '', cmp: last ? last.campaign : '', cnt: last ? last.content : '',
      fsrc: first ? first.source : '', fcmp: first ? first.campaign : '', fat: first ? first.at : 0,
    };
  }
  function push(e, extra) {
    if (!CFG.api || !/^https:\/\//.test(CFG.api)) return;
    Q.push(Object.assign({ e: e, t: Date.now() }, base(), extra || {}));
    touch();
    clearTimeout(timer);
    if (Q.length >= 10 || e === 'order' || e === 'login') flush(); else timer = setTimeout(flush, 4000);
  }
  function flush() {
    clearTimeout(timer);
    if (!Q.length || !CFG.api) return;
    var body = JSON.stringify({ action: 'traffic', events: Q.splice(0, 20), idToken: token || undefined });
    try {
      if (navigator.sendBeacon && navigator.sendBeacon(CFG.api, new Blob([body], { type: 'text/plain;charset=utf-8' }))) return;
    } catch (e) {}
    try { fetch(CFG.api, { method: 'POST', mode: 'no-cors', keepalive: true, headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: body }).catch(function () {}); } catch (e) {}
    if (Q.length) setTimeout(flush, 500);
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  // เข้าเว็บ: ส่ง 1 ครั้งต่อรอบ หรือทุกครั้งที่กดลิงก์ utm / ที่มาใหม่
  if (newSession || fresh) {
    push('visit', {
      via: hit ? hit.source : 'internal', ref: hit ? hit.ref : '', code: hit ? hit.code : '', term: hit ? hit.term : '', guess: hit && hit.guess ? 1 : 0,
      land: clean(location.search.replace(/([?&](liff\.state|idToken|access_token|code_verifier|state)=)[^&]*/g, '$1…'), 300),
    });
  }

  var seenOrders = {};
  document.addEventListener('mera:order', function (ev) {
    var o = (ev && ev.detail) || {}; if (!o.id || seenOrders[o.id]) return;
    if (o.createdAt && Date.now() - Number(new Date(o.createdAt)) > 10 * 6e4) return;   // แนบสลิปใหม่ของออเดอร์เก่า ไม่นับซ้ำ
    seenOrders[o.id] = 1;
    var items = (o.items && o.items.length ? o.items : [o]).map(function (x) { return [x.brand, x.name, x.sku, 'x' + (x.qty || 1)].filter(Boolean).join(' · '); });
    push('order', { order: clean(o.id, 20), total: Number(o.total) || 0, items: clean(items.join(' | '), 400), coupon: clean(o.coupon || o.couponCode || '', 40) });
  });

  window.MeraTrack = {
    /** ดูสินค้า / ดีล */
    view: function (info) {
      info = info || {};
      var k = (info.kind || 'product') + ':' + (info.id || '');
      if (window.__mtLastView === k) return; window.__mtLastView = k;
      push('view', { kind: clean(info.kind || 'product', 20), pid: clean(info.id, 40), brand: clean(info.brand, 60), product: clean(info.product, 120), deal: clean(info.deal, 40) });
    },
    /** ล็อกอิน LINE แล้ว: ส่ง 1 ครั้งต่อรอบ เพื่อผูกเครื่องนี้กับ LINE ID (หลังบ้านตรวจ token เอง) */
    login: function (idToken) {
      if (!idToken) return; token = idToken;
      if (ss('mt_login') === sess.id) return; ss('mt_login', sess.id);
      push('login', {});
    },
    source: function () { return { first: first, last: last }; },
    flush: flush,
  };
})();
