/* Mera Admin — แบนเนอร์หน้าแรก (หน้าตาตาม Prototype v2 ฝั่งแอดมิน) */
(function () {
  'use strict';
  var CFG = window.MERA_ADMIN || {};
  var API = CFG.api, CAT_API = CFG.catalogApi;
  var esc = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var SPEC = { top: { w: 1200, h: 625, th: 'โปสเตอร์ด้านบน (เลื่อนได้หลายรูป)', note: '1200 × 625 px' }, mid: { w: 1200, h: 580, th: 'Mid month deal (รูปเดียว)', note: '1200 × 580 px' } };
  var A = { page: 'banners', tview: 'visual', tmode: 'edit', tlang: 'th', texts: null, tEdit: {}, tq: '', token: '', by: '', banners: [], drafts: {}, cat: null, err: '', msg: '', busy: '', sheetUrl: '', notAdmin: null, liffId: '' };
  try { var t = JSON.parse(sessionStorage.getItem('mera-adm') || 'null'); if (t && t.exp > Date.now()) { A.token = t.token; A.by = t.by; } } catch (e) {}

  function post(action, extra) {
    return fetch(API, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(Object.assign({ action: action, token: A.token }, extra || {})) })
      .then(function (r) { return r.text(); })
      .then(function (t) { var j; try { j = JSON.parse(t); } catch (e) { throw new Error('หลังบ้านตอบกลับไม่ถูกต้อง · ตรวจว่า Deploy เวอร์ชันใหม่แล้ว'); } return j; })
      .then(function (j) {
        if (j && j.code === 'ADMIN_AUTH' && action !== 'adminAuth') { logout('เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'); throw new Error(j.error); }
        if (j && j.error === 'ไม่รู้จักคำสั่งนี้') throw new Error('หลังบ้านยังไม่มีระบบแอดมิน · เพิ่มไฟล์ Web_Admin.gs แล้ว Deploy เวอร์ชันใหม่');
        return j;
      });
  }
  function logout(msg) { A.token = ''; A.banners = []; A.err = msg || ''; try { sessionStorage.removeItem('mera-adm'); } catch (e) {} render(); }
  function saveSession(j) { A.token = j.token; A.by = j.by; try { sessionStorage.setItem('mera-adm', JSON.stringify({ token: j.token, by: j.by, exp: Date.now() + (j.ttl || 21600) * 1000 - 60000 })); } catch (e) {} }

  /* ---------- ข้อมูลสินค้า (ใช้ทำตัวเลือกลิงก์) ---------- */
  function loadCatalog() {
    try { var c = JSON.parse(localStorage.getItem('mera-catalog-live-v1') || 'null'); if (c) useCat(c); } catch (e) {}
    if (!CAT_API) return;
    fetch(CAT_API + '?t=' + Date.now()).then(function (r) { return r.json(); }).then(function (d) { useCat(d); render(); }).catch(function () {});
  }
  function useCat(d) {
    if (!d || !Array.isArray(d.products)) return;
    var hidden = ['manitui'];
    var products = d.products.filter(function (p) { return p.variants && p.variants.length && hidden.indexOf(String(p.brand).trim().toLowerCase()) < 0; });
    var brands = {}; products.forEach(function (p) { brands[p.brand] = (d.brands || []).filter(function (b) { return b.name === p.brand; }).map(function (b) { return b.display; })[0] || p.brand; });
    A.cat = { brands: brands, products: products.map(function (p) { return { sku: p.variants[0].sku, name: p.name, brand: brands[p.brand] }; }), deals: (d.deals || []).map(function (x) { return x.code; }).filter(Boolean) };
    if (d.config && d.config.liffId) A.liffId = d.config.liffId;
  }

  /* ---------- เข้าสู่ระบบ ---------- */
  function loginPassword(pw) {
    A.busy = 'login'; A.err = ''; render();
    post('adminAuth', { password: pw }).then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error || 'เข้าสู่ระบบไม่สำเร็จ'; return render(); }
      saveSession(j); loadBanners();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function loadLiff() {
    if (window.liff) return Promise.resolve(window.liff);
    return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = 'https://static.line-scdn.net/liff/edge/2/sdk.js'; s.onload = function () { res(window.liff); }; s.onerror = function () { rej(new Error('โหลด LINE ไม่สำเร็จ')); }; document.head.appendChild(s); });
  }
  function loginLine(auto) {
    if (!A.liffId) { if (!auto) { A.err = 'ยังไม่พบ LIFF ID (เปิดหน้า Catalog ก่อน 1 ครั้ง)'; render(); } return; }
    if (!auto) { A.busy = 'line'; A.err = ''; render(); }
    loadLiff().then(function (liff) { return liff.init({ liffId: A.liffId }).then(function () { return liff; }); }).then(function (liff) {
      if (!liff.isLoggedIn()) { if (auto && !(liff.isInClient && liff.isInClient())) { A.busy = ''; return render(); } return liff.login({ redirectUri: location.href.split('#')[0] }); }
      return post('adminAuth', { idToken: liff.getIDToken() }).then(function (j) {
        A.busy = '';
        if (j.code === 'NOT_ADMIN') { A.notAdmin = { userId: j.userId, name: j.name }; return render(); }
        if (!j.ok) { A.err = j.error || 'เข้าสู่ระบบไม่สำเร็จ'; return render(); }
        saveSession(j); loadBanners();
      });
    }).catch(function (e) { A.busy = ''; if (!auto) A.err = e.message; render(); });
  }

  /* ---------- แบนเนอร์ ---------- */
  function loadBanners() {
    A.busy = 'load'; render();
    post('adminBanners').then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; return render(); }
      A.banners = j.banners; A.sheetUrl = j.sheetUrl || ''; A.drafts = {}; render();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function rowOf(id) { return A.drafts[id] || A.banners.filter(function (b) { return b.id === id; })[0]; }
  function edit(id) { if (!A.drafts[id]) A.drafts[id] = Object.assign({}, rowOf(id)); A.drafts[id]._dirty = true; return A.drafts[id]; }
  function saveRow(id) {
    var b = rowOf(id); if (!b) return;
    if (!b.img) { A.err = 'ใส่รูปแบนเนอร์ก่อนบันทึก'; return render(); }
    A.busy = 'save:' + id; A.err = ''; render();
    var body = { id: b.id && b.id.indexOf('new') !== 0 ? b.id : '', slot: b.slot, title: b.title, img: b.img, link: b.link, start: b.start, end: b.end, active: !!b.active, order: b.order };
    post('adminBannerSave', { banner: body }).then(function (j) {
      A.busy = '';
      if (!j.ok) { A.err = j.error; return render(); }
      delete A.drafts[id]; A.banners = j.banners; A.msg = 'บันทึกแล้ว · หน้า Catalog จะเห็นภายใน 5 นาที'; render(); flash();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function delRow(id) {
    if (id.indexOf('new') === 0) { delete A.drafts[id]; return render(); }
    if (A.confirmDel !== id) { A.confirmDel = id; return render(); }
    A.confirmDel = ''; A.busy = 'del:' + id; render();
    post('adminBannerDelete', { id: id }).then(function (j) { A.busy = ''; if (!j.ok) { A.err = j.error; return render(); } delete A.drafts[id]; A.banners = j.banners; A.msg = 'ลบแล้ว'; render(); flash(); })
      .catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function move(id, dir) {
    var b = rowOf(id), list = listOf(b.slot), i = list.map(function (x) { return x.id; }).indexOf(id), j = i + dir;
    if (j < 0 || j >= list.length) return;
    list.forEach(function (x, k) { var e = edit(x.id); e.order = (k === i ? j : k === j ? i : k) + 1; });
    render();
  }
  function listOf(slot) {
    var saved = A.banners.filter(function (b) { return b.slot === slot; }).map(function (b) { return A.drafts[b.id] || b; });
    var news = Object.keys(A.drafts).filter(function (k) { return k.indexOf('new') === 0 && A.drafts[k].slot === slot; }).map(function (k) { return A.drafts[k]; });
    return saved.concat(news).sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
  }
  function addRow(slot) {
    var id = 'new' + Date.now().toString(36), n = listOf(slot).length;
    A.drafts[id] = { id: id, slot: slot, title: '', img: '', link: 'zone:gb', start: '', end: '', active: true, order: n + 1, _dirty: true };
    render();
  }
  function upload(id, file) {
    if (!file) return;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { A.err = 'รองรับเฉพาะไฟล์ JPG / PNG / WEBP'; return render(); }
    A.busy = 'up:' + id; A.err = ''; render();
    resize(file, 1600).then(function (out) {
      var b = edit(id); b._preview = out.dataUrl; b._ratio = out.ratio; render();
      return post('adminUpload', { data: out.dataUrl, mime: out.mime }).then(function (j) {
        A.busy = '';
        if (!j.ok) { A.err = j.error; return render(); }
        edit(id).img = j.url; A.msg = 'อัปโหลดรูปแล้ว กด "บันทึก" เพื่อใช้บนหน้า Catalog'; render(); flash();
      });
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function resize(file, maxW) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = function () { rej(new Error('อ่านไฟล์ไม่ได้')); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { rej(new Error('ไฟล์รูปเสีย หรือไม่รองรับ')); };
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, maxW / w);
          var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
          var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
          res({ dataUrl: c.toDataURL('image/jpeg', 0.86), mime: 'image/jpeg', ratio: w / h });
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  var flashT; function flash() { clearTimeout(flashT); flashT = setTimeout(function () { A.msg = ''; render(); }, 2600); }

  /* ---------- ตัวเลือกลิงก์ ---------- */
  function linkOptions(cur) {
    var o = [['zone:gb', 'โซน Mera Group Deal'], ['zone:shop', 'โซนซื้อเลย (รายการสินค้า)']];
    if (A.cat) {
      Object.keys(A.cat.brands).forEach(function (k) { o.push(['brand:' + k, 'แบรนด์ · ' + A.cat.brands[k]]); });
      A.cat.deals.forEach(function (c) { o.push(['deal:' + c, 'ดีล · ' + c]); });
      A.cat.products.forEach(function (p) { o.push(['product:' + p.sku, 'สินค้า · ' + p.brand + ' – ' + p.name]); });
    }
    o.push(['url:', 'ลิงก์ภายนอก (URL)…']);
    var isUrl = /^url:/.test(cur || ''), known = o.some(function (x) { return x[0] === cur; });
    if (cur && !known && !isUrl) o.splice(2, 0, [cur, cur + ' (ไม่พบในข้อมูลล่าสุด)']);
    return o.map(function (x) { var sel = isUrl ? x[0] === 'url:' : x[0] === cur; return '<option value="' + esc(x[0]) + '"' + (sel ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join('');
  }

  /* ---------- วาดหน้า ---------- */
  function vLogin() {
    var h = '<div class="lg"><div class="lgc"><img src="' + esc(CFG.logo || '') + '" alt="MERA" style="height:40px;width:auto;align-self:flex-start"><h1>Mera Admin</h1><p class="sub">จัดการแบนเนอร์หน้าแรกของ Catalog</p>';
    if (A.notAdmin) h += '<div class="note"><b>บัญชี LINE นี้ยังไม่อยู่ในรายชื่อแอดมิน</b><br>LINE User ID: <code class="mono">' + esc(A.notAdmin.userId) + '</code><br>ให้ผู้ดูแลเพิ่ม ID นี้ใน Script Properties → <b>ADMIN_LINE_IDS</b> แล้วกลับมาเข้าใหม่<div style="margin-top:8px"><button class="abtn o" data-a="copyId">คัดลอก ID</button></div></div>';
    h += '<form id="pwf" class="f"><label for="pw">รหัสแอดมิน (ใช้บนคอม)</label><input id="pw" type="password" autocomplete="current-password" required minlength="1"><button class="abtn" type="submit"' + (A.busy ? ' disabled' : '') + '>' + (A.busy === 'login' ? 'กำลังเข้า…' : 'เข้าสู่ระบบ') + '</button></form>' +
      '<div class="or"><span>หรือ</span></div><button class="lbtn" data-a="line"' + (A.busy ? ' disabled' : '') + '>' + (A.busy === 'line' ? 'กำลังเชื่อม LINE…' : 'เข้าด้วย LINE (บัญชีในรายชื่อแอดมิน)') + '</button>' +
      (A.err ? '<div class="err" role="alert">' + esc(A.err) + '</div>' : '') + '<a class="small" href="./">← กลับไปหน้า Catalog</a></div></div>';
    return h;
  }
  function vRow(b, i, n) {
    var sp = SPEC[b.slot], id = b.id, busy = A.busy.indexOf(':' + id) > 0;
    var src = b._preview || (/^https:\/\/lh3\.googleusercontent\.com\/d\//.test(b.img || '') ? b.img.replace(/=w\d+$/, '') + '=w800' : (b.img || ''));
    var ratioWarn = b._ratio && Math.abs(b._ratio - sp.w / sp.h) / (sp.w / sp.h) > 0.06;
    var isUrl = /^url:/.test(b.link || '');
    return '<div class="brow' + (b._dirty ? ' dirty' : '') + '">' +
      '<label class="bprev" style="aspect-ratio:' + sp.w + '/' + sp.h + '">' + (src ? '<img src="' + esc(src) + '" alt="">' : '<small>แตะเพื่อใส่รูป<br>' + sp.note + '</small>') +
      (A.busy === 'up:' + id ? '<span class="upl">กำลังอัปโหลด…</span>' : '') + '<input type="file" accept="image/jpeg,image/png,image/webp" hidden data-file="' + esc(id) + '"></label>' +
      '<div class="bf"><div class="grid">' +
      '<label class="f">ชื่อ (ไว้จำ / คำอธิบายรูป)<input class="inp" data-k="title" data-id="' + esc(id) + '" value="' + esc(b.title) + '" maxlength="120"></label>' +
      '<label class="f">กดแล้วไปที่<select class="inp" data-k="link" data-id="' + esc(id) + '">' + linkOptions(b.link) + '</select></label>' +
      (isUrl ? '<label class="f full">ลิงก์ภายนอก (ขึ้นต้นด้วย https://)<input class="inp" data-k="url" data-id="' + esc(id) + '" value="' + esc((b.link || '').slice(4)) + '" placeholder="https://"></label>' : '') +
      '<label class="f">เริ่มแสดง<input class="inp" type="date" data-k="start" data-id="' + esc(id) + '" value="' + esc(b.start) + '"></label>' +
      '<label class="f">หยุดแสดง<input class="inp" type="date" data-k="end" data-id="' + esc(id) + '" value="' + esc(b.end) + '"></label></div>' +
      (ratioWarn ? '<div class="note">สัดส่วนรูปไม่ตรง ' + sp.note + ' ขอบรูปบางส่วนจะถูกตัดบนหน้า Catalog</div>' : '') +
      '<div class="toolbar"><label class="chk"><input type="checkbox" data-k="active" data-id="' + esc(id) + '"' + (b.active ? ' checked' : '') + '> เปิดใช้</label>' +
      '<button class="abtn o" data-a="up" data-id="' + esc(id) + '"' + (i ? '' : ' disabled') + ' aria-label="เลื่อนขึ้น">↑</button><button class="abtn o" data-a="down" data-id="' + esc(id) + '"' + (i < n - 1 ? '' : ' disabled') + ' aria-label="เลื่อนลง">↓</button>' +
      '<span style="flex:1"></span><button class="abtn r" data-a="del" data-id="' + esc(id) + '"' + (busy ? ' disabled' : '') + '>' + (A.confirmDel === id ? 'กดอีกครั้งเพื่อลบ' : 'ลบ') + '</button>' +
      '<button class="abtn" data-a="save" data-id="' + esc(id) + '"' + (busy || !b._dirty ? ' disabled' : '') + '>' + (A.busy === 'save:' + id ? 'กำลังบันทึก…' : b._dirty ? 'บันทึก' : 'บันทึกแล้ว') + '</button></div></div></div>';
  }
  function vBanners() {
    var h = '<div><h1>แบนเนอร์และโปรโมชัน</h1><div class="sub">รูปที่เปิดใช้และอยู่ในช่วงวันที่จะขึ้นหน้าแรกของ Catalog ภายใน 5 นาทีหลังบันทึก · ช่องที่ยังไม่มีรูปจะแสดงเป็นกรอบว่างระบุขนาด' +
      (A.sheetUrl ? ' · <a href="' + esc(A.sheetUrl) + '" target="_blank" rel="noopener">เปิดชีต Mera Admin</a>' : '') + '</div></div>';
    if (A.busy === 'load') return h + '<div class="panel" style="padding:20px">กำลังโหลด…</div>';
    ['top', 'mid'].forEach(function (slot) {
      var list = listOf(slot);
      h += '<div class="panel"><h3>' + SPEC[slot].th + ' <span class="small muted">' + SPEC[slot].note + '</span><button class="abtn o" data-a="add" data-v="' + slot + '">+ เพิ่ม</button></h3><div class="plist">' +
        (list.length ? list.map(function (b, i) { return vRow(b, i, list.length); }).join('') : '<div class="note blue">ยังไม่มีแบนเนอร์ของตำแหน่งนี้ · ตอนนี้หน้า Catalog ใช้<b>แบนเนอร์ชั่วคราว</b>ด้านล่าง กด "+ เพิ่ม" แล้วอัปโหลดรูปจริง แบนเนอร์ชั่วคราวจะหายไปเอง</div><div class="defs">' +
          ((CFG.defaultBanners || {})[slot] || []).map(function (src) { return '<img src="' + esc(src) + '" alt="แบนเนอร์ชั่วคราว" style="aspect-ratio:' + SPEC[slot].w + '/' + SPEC[slot].h + '">'; }).join('') + '</div>') + '</div></div>';
    });
    return h;
  }
  /* ---------- ข้อความบนหน้าเว็บ ---------- */
  var REG = CFG.texts || [];
  function loadTexts() {
    A.busy = 'texts'; render();
    post('adminTexts').then(function (j) { A.busy = ''; if (!j.ok) { A.err = j.error; return render(); } A.texts = j.texts || {}; A.tEdit = {}; render(); })
      .catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  function tVal(k, lang) { var e = A.tEdit[k]; if (e && e[lang] !== undefined) return e[lang]; var o = (A.texts || {})[k]; return o ? (o[lang] || '') : ''; }
  function tSet(k, lang, v) { A.tEdit[k] = A.tEdit[k] || {}; A.tEdit[k][lang] = v; }
  function tDirty() { return Object.keys(A.tEdit).filter(function (k) { var o = (A.texts || {})[k] || {}; return tVal(k, 'th') !== (o.th || '') || tVal(k, 'en') !== (o.en || ''); }); }
  function saveTexts() {
    var keys = tDirty(); if (!keys.length) return;
    A.busy = 'tsave'; A.err = ''; render();
    post('adminTextSave', { items: keys.map(function (k) { return { key: k, th: tVal(k, 'th').trim(), en: tVal(k, 'en').trim() }; }) }).then(function (j) {
      A.busy = ''; if (!j.ok) { A.err = j.error; return render(); }
      A.texts = j.texts || {}; A.tEdit = {}; A.msg = 'บันทึกข้อความแล้ว · หน้า Catalog จะเห็นภายใน 5 นาที'; render(); flash();
    }).catch(function (e) { A.busy = ''; A.err = e.message; render(); });
  }
  // ให้หน้า Catalog ใน iframe (index.html?edit=1) เรียกใช้ตอนกดแก้ข้อความบนหน้า
  var REN = {}; REG.forEach(function (t) { REN[t.k] = t.en; });
  window.meraAdmin = {
    keys: function () { return REG.map(function (t) { return t.k; }); },
    en: function (k) { return REN[k] || ''; },
    texts: function () { return A.texts || {}; },
    mode: function () { return A.tmode; },
    lang: function () { return A.tlang; },
    save: function (k, th, en) {
      return post('adminTextSave', { items: [{ key: k, th: th, en: en }] }).then(function (j) {
        if (!j.ok) throw new Error(j.error || 'บันทึกไม่สำเร็จ');
        A.texts = j.texts || {}; updateTbar(); return A.texts;
      });
    },
  };
  function frameApi() { var f = document.getElementById('tframe'); try { return f && f.contentWindow && f.contentWindow.meraEdit; } catch (e) { return null; } }
  function tbarHTML() {
    var n = Object.keys(A.texts || {}).length;
    return '<div class="seg2" role="group" aria-label="โหมด"><button class="' + (A.tmode === 'edit' ? 'on' : '') + '" data-a="tmode" data-v="edit">✎ กดที่ข้อความเพื่อแก้</button><button class="' + (A.tmode === 'browse' ? 'on' : '') + '" data-a="tmode" data-v="browse">เลื่อนดู / กดไปหน้าอื่น</button></div>' +
      '<div class="seg2" role="group" aria-label="ภาษา"><button class="' + (A.tlang === 'th' ? 'on' : '') + '" data-a="tlang" data-v="th">ไทย</button><button class="' + (A.tlang === 'en' ? 'on' : '') + '" data-a="tlang" data-v="en">English</button></div>' +
      '<span class="small muted">แก้แล้ว ' + n + ' ข้อความ</span><span style="flex:1"></span><button class="abtn o" data-a="tview" data-v="list">ดูเป็นรายการทั้งหมด</button>';
  }
  function updateTbar() { var t = document.getElementById('tbar'); if (t) t.innerHTML = tbarHTML(); }
  function vTextsVisual() {
    return '<div><h1>ข้อความบนหน้าเว็บ</h1><div class="sub">นี่คือหน้า Catalog จริง · กดที่ข้อความที่มีเส้นประเพื่อพิมพ์แก้ตรงนั้น แล้วกด Enter หรือ "บันทึก" · ช่องอีกภาษาแก้ได้ในกล่องที่เด้งขึ้น · ข้อความที่แก้แล้วมีกรอบสีชมพู · สลับเป็น "เลื่อนดู" เพื่อกดเข้าหน้าสินค้า/ดีล/โปรไฟล์ แล้วสลับกลับมาแก้ · ข้อความที่ไม่อยู่บนหน้า (เช่น ตอนสมัครสมาชิก) แก้ได้ใน "ดูเป็นรายการทั้งหมด"</div></div>' +
      '<div class="toolbar" id="tbar">' + tbarHTML() + '</div>' +
      (A.texts === null ? '<div class="panel" style="padding:20px">กำลังโหลด…</div>' : '<div class="phonewrap"><iframe id="tframe" src="index.html?edit=1" title="หน้า Catalog โหมดแก้ข้อความ"></iframe></div>');
  }
  function vTexts() {
    if (A.tview !== 'list') return vTextsVisual();
    var h = '<div><h1>ข้อความบนหน้าเว็บ</h1><div class="toolbar" style="margin-top:6px"><button class="abtn o" data-a="tview" data-v="visual">← แก้บนหน้าเว็บ</button></div><div class="sub">แก้ข้อความบนหน้า Catalog ได้ทั้งภาษาไทยและอังกฤษ · ช่องที่ปล่อยว่างจะใช้ข้อความเดิมของเว็บ (ตัวสีเทา) · ข้อความที่มีตัวเลข/ราคาในประโยค และข้อความในขั้นตอนสั่งซื้อ-ชำระเงิน แก้ที่นี่ไม่ได้ · ข้อความเดียวกันที่อยู่หลายที่จะเปลี่ยนพร้อมกัน</div></div>';
    if (A.texts === null) return h + '<div class="panel" style="padding:20px">กำลังโหลด…</div>';
    var q = A.tq.trim().toLowerCase(), dirty = tDirty();
    h += '<div class="toolbar tbar"><input class="inp" data-t="q" value="' + esc(A.tq) + '" placeholder="ค้นหาข้อความ" style="flex:1;min-width:180px"><span class="small muted">แก้แล้ว ' + Object.keys(A.texts).length + ' ข้อความ</span>' +
      '<button class="abtn" data-a="tsave"' + (dirty.length && !A.busy ? '' : ' disabled') + '>' + (A.busy === 'tsave' ? 'กำลังบันทึก…' : 'บันทึก' + (dirty.length ? ' (' + dirty.length + ')' : '')) + '</button></div>';
    var groups = {};
    REG.forEach(function (t) { if (q && (t.k + ' ' + t.en + ' ' + tVal(t.k, 'th') + ' ' + tVal(t.k, 'en')).toLowerCase().indexOf(q) < 0) return; (groups[t.s] = groups[t.s] || []).push(t); });
    Object.keys(groups).forEach(function (sec) {
      h += '<div class="panel"><h3>' + esc(sec) + ' <span class="small muted">' + groups[sec].length + '</span></h3><div class="plist tl">' + groups[sec].map(function (t, i) {
        var th = tVal(t.k, 'th'), en = tVal(t.k, 'en'), ch = th || en, d = dirty.indexOf(t.k) >= 0, id = sec + '|' + i;
        return '<div class="trow' + (d ? ' dirty' : '') + '"><div class="grid"><label class="f">ไทย' + (ch ? ' <span class="pill">แก้แล้ว</span>' : '') + '<input class="inp" data-t="th" data-key="' + esc(t.k) + '" data-id="' + esc(id) + '" value="' + esc(th) + '" placeholder="' + esc(t.k) + '" maxlength="400"></label>' +
          '<label class="f">English<input class="inp" data-t="en" data-key="' + esc(t.k) + '" data-id="' + esc(id) + 'e" value="' + esc(en) + '" placeholder="' + esc(t.en) + '" maxlength="400"></label></div>' +
          (ch ? '<button class="link2" data-a="treset" data-key="' + esc(t.k) + '">คืนค่าเดิม</button>' : '') + '</div>';
      }).join('') + '</div></div>';
    });
    if (!Object.keys(groups).length) h += '<p class="muted">ไม่พบข้อความ</p>';
    return h;
  }

  function render() {
    var app = document.getElementById('adm'); if (!app) return;
    // หน้าแก้ข้อความบนหน้าเว็บ: ไม่วาดใหม่ทั้งหน้า (ไม่ให้ iframe โหลดใหม่)
    if (A.token && A.page === 'texts' && A.tview !== 'list' && A.texts !== null && document.getElementById('tframe')) {
      updateTbar();
      var er = document.getElementById('aerr'); if (er) { er.hidden = !A.err; er.textContent = A.err || ''; }
      var tb = document.getElementById('toast'); if (A.msg) { if (!tb) { tb = document.createElement('div'); tb.id = 'toast'; tb.setAttribute('role', 'status'); document.body.appendChild(tb); } tb.textContent = A.msg; } else if (tb) tb.remove();
      return;
    }
    var ae = document.activeElement, fid = ae && ae.getAttribute && (ae.getAttribute('data-k') || ae.getAttribute('data-t')) ? [ae.getAttribute('data-k') ? 'data-k' : 'data-t', ae.getAttribute('data-k') || ae.getAttribute('data-t'), ae.getAttribute('data-id')] : null;
    if (!A.token) { app.className = 'adm-login'; app.innerHTML = vLogin(); return; }
    app.className = 'adm';
    app.innerHTML = '<aside class="side"><div class="who"><img src="' + esc(CFG.logo || '') + '" alt=""><div><b>Mera Admin</b><small>' + esc(A.by) + '</small></div></div>' +
      '<button class="' + (A.page === 'banners' ? 'on' : '') + '" data-a="page" data-v="banners">▣ แบนเนอร์และโปรโมชัน</button><button class="' + (A.page === 'texts' ? 'on' : '') + '" data-a="page" data-v="texts">✎ ข้อความบนหน้าเว็บ</button><span style="flex:1"></span><a class="sbtn" href="./" target="_blank" rel="noopener">เปิดหน้า Catalog ↗</a><button class="sbtn" data-a="logout">ออกจากระบบ</button></aside>' +
      '<section class="main"><div class="mtop"><b>Mera Admin</b><span style="flex:1"></span><a class="abtn o" href="./" target="_blank" rel="noopener">Catalog ↗</a><button class="abtn o" data-a="logout">ออก</button></div><div class="mtabs2"><button class="' + (A.page === 'banners' ? 'on' : '') + '" data-a="page" data-v="banners">แบนเนอร์</button><button class="' + (A.page === 'texts' ? 'on' : '') + '" data-a="page" data-v="texts">ข้อความ</button></div>' + (A.page === 'texts' ? vTexts() : vBanners()) +
      '<div class="err" role="alert" id="aerr"' + (A.err ? '' : ' hidden') + '>' + esc(A.err) + '</div></section>' + (A.msg ? '<div id="toast" role="status">' + esc(A.msg) + '</div>' : '');
    if (fid) { var el = app.querySelector('[' + fid[0] + '="' + fid[1] + '"]' + (fid[2] ? '[data-id="' + fid[2].replace(/"/g, '\\"') + '"]' : '')); if (el && el.type !== 'checkbox') { el.focus(); try { var n = el.value.length; el.setSelectionRange(n, n); } catch (e) {} } }
  }

  document.addEventListener('submit', function (e) { if (e.target.id === 'pwf') { e.preventDefault(); var pw = document.getElementById('pw').value; if (pw) loginPassword(pw); } });
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-a]'); if (!el) return;
    var a = el.getAttribute('data-a'), id = el.getAttribute('data-id'), v = el.getAttribute('data-v');
    if (a !== 'del' && A.confirmDel) A.confirmDel = '';
    switch (a) {
      case 'line': return loginLine(false);
      case 'copyId': try { navigator.clipboard.writeText(A.notAdmin.userId).then(function () { A.msg = 'คัดลอกแล้ว'; render(); flash(); }, function () {}); } catch (x) {} return;
      case 'logout': return logout('');
      case 'page': var fr0 = document.getElementById('tframe'); if (fr0 && v !== 'texts') fr0.remove(); A.page = v; A.err = ''; if (v === 'texts' && A.texts === null) loadTexts(); else render(); return;
      case 'tsave': return saveTexts();
      case 'tview': A.tview = v; if (v === 'list') A.tEdit = {}; var host = document.getElementById('tframe'); if (host) host.remove(); return render();
      case 'tmode': { A.tmode = v; var fa = frameApi(); if (fa) fa.setMode(v); return updateTbar(); }
      case 'tlang': { A.tlang = v; var fb = frameApi(); if (fb) fb.setLang(v); return updateTbar(); }
      case 'treset': { var k = el.getAttribute('data-key'); tSet(k, 'th', ''); tSet(k, 'en', ''); return render(); }
      case 'add': return addRow(v);
      case 'save': return saveRow(id);
      case 'del': return delRow(id);
      case 'up': return move(id, -1);
      case 'down': return move(id, 1);
    }
  });
  document.addEventListener('input', function (e) {
    var tt = e.target.getAttribute && e.target.getAttribute('data-t');
    if (tt === 'q') { A.tq = e.target.value; return render(); }
    if (tt === 'th' || tt === 'en') {
      tSet(e.target.getAttribute('data-key'), tt, e.target.value);
      var n = tDirty().length, b = document.querySelector('[data-a="tsave"]'); if (b) { b.disabled = !n; b.textContent = 'บันทึก' + (n ? ' (' + n + ')' : ''); }
      var row = e.target.closest('.trow'); if (row) row.classList.add('dirty');
      return;
    }
    var k = e.target.getAttribute && e.target.getAttribute('data-k'), id = e.target.getAttribute && e.target.getAttribute('data-id'); if (!k || !id) return;
    var b = edit(id);
    if (k === 'title') b.title = e.target.value;
    else if (k === 'url') b.link = 'url:' + e.target.value.trim();
    else return;
    var btn = document.querySelector('[data-a="save"][data-id="' + id + '"]'); if (btn) { btn.disabled = false; btn.textContent = 'บันทึก'; }
    var row = btn && btn.closest('.brow'); if (row) row.classList.add('dirty');
  });
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.getAttribute && t.getAttribute('data-file')) return upload(t.getAttribute('data-file'), t.files && t.files[0]);
    var k = t.getAttribute && t.getAttribute('data-k'), id = t.getAttribute && t.getAttribute('data-id'); if (!k || !id) return;
    var b = edit(id);
    if (k === 'link') b.link = t.value === 'url:' ? 'url:https://' : t.value;
    else if (k === 'start' || k === 'end') b[k] = t.value;
    else if (k === 'active') b.active = t.checked;
    else if (k === 'title' || k === 'url') return;
    render();
  });

  loadCatalog();
  render();
  if (A.token) loadBanners(); else loginLine(true);
})();
